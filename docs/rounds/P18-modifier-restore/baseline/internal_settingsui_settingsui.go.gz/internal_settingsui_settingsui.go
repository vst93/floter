// Package settingsui draws the settings surface: a sidebar of pages beside
// a body.
//
// The General page's controls bind to the settings store, which writes
// every change back to the same JSON file while preserving the keys this
// build does not own (see internal/settings); the terminal group drives the
// terminal surface's appearance (see internal/terminalui). The other pages
// route but say they arrive later.
package settingsui

import (
	"encoding/json"
	"fmt"
	"maps"
	"math"
	"runtime"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/egoist/mygo/plugins/glass"
	"github.com/egoist/mygo/ui"

	"floter/internal/ansi"
	"floter/internal/control"
	"floter/internal/deadline"
	"floter/internal/extensions"
	"floter/internal/glassmap"
	"floter/internal/i18n"
	"floter/internal/launcher"
	"floter/internal/scriptlang"
	"floter/internal/settings"
	"floter/internal/shortcuts"
	"floter/internal/terminalui"
	"floter/internal/textlines"
	"floter/internal/theme"
	"floter/internal/valuedomain"
)

// The settings pages, in sidebar order.
//
// The built-in plugins have no page: their configuration is the launcher's own
// sheet, rendered from the schema a plugin declares (see `PluginSheet`). The
// old build retired its plugin pages for the same reason in R33 — 「配置页面通用
// 化：点击设置之后，弹出一个基于通用规则的配置页面，而不是一个新的完全独立的
// 页面」 — and a page here would be a second form of the same settings, free to
// drift from the first.
const (
	PageGeneral = iota
	PageSessions
	PageShortcuts
	PageIntegrations
	PageAbout

	pageCount
)

// pageNames are the ids the `last_settings_page` setting stores, in the same
// order as the pages: reopening the settings surface returns to the page the
// user last looked at. A file that still names `plugins` (a build that had the
// page) resolves to the first page, since `PageByName` refuses what it does not
// know.
var pageNames = [pageCount]string{"general", "sessions", "shortcuts", "integrations", "about"}

// PageByName resolves a stored page id, reporting whether it is one this build
// knows.
func PageByName(name string) (int, bool) {
	for i, page := range pageNames {
		if page == name {
			return i, true
		}
	}
	return PageGeneral, false
}

// IntegrationsPage is the page index for a caller outside the package.
func IntegrationsPage() int { return PageIntegrations }

// PageName is the stored id of a page index.
func PageName(page int) string {
	if page < 0 || page >= pageCount {
		return pageNames[PageGeneral]
	}
	return pageNames[page]
}

// Actions are the shell's callbacks.
type Actions struct {
	// Close leaves the settings surface (Escape, the header's close button),
	// and Quit leaves the application.
	Close func()
	Quit  func()
	// CloseSession ends the running terminal session, from the Sessions
	// page.
	CloseSession func()
	// SelectSession shows the session at an index, and CloseSessionAt ends
	// it: the sessions list is a list of the terminal's own sessions, not a
	// single one, so a click has to name which.
	SelectSession  func(index int)
	CloseSessionAt func(index int)
	// NewSession starts another terminal session.
	NewSession func()
	// SetIntegrationEnabled turns an installed extension on or off.
	//
	// done reports the write back to the confirmation band that asked, on the
	// main thread: a nil error closes it (the reference's
	// `setDisableTarget(null)` after `await runMutation`), and a non-nil error
	// leaves the band open with its answer pill usable again, exactly as the
	// reference's `runMutation` `finally` did (`src/ExtensionsPanel.tsx:1274-1283`).
	// It may be nil for the enable direction, which asks nothing.
	SetIntegrationEnabled func(id string, enabled bool, done func(error))
	// UninstallIntegration removes an installed extension. The kind is the
	// same `removalKind` the confirmation bar spoke in, so the shell's
	// completion notification can be the kind's own word rather than one
	// generic "removed" (`src/ExtensionsPanel.tsx:1286-1340`).
	//
	// done reports the removal back to the band that asked, on the main thread:
	// a nil error closes it (the reference's `setRemovalTarget(null)` after
	// `await runMutation`), and a non-nil error leaves it open with its answer
	// pill usable again (`src/ExtensionsPanel.tsx:1296-1304`). It may be nil, in
	// which case the band closes at once.
	UninstallIntegration func(id string, name string, kind string, done func(error))
	// UninstallComponents removes the parts of an installed extension the
	// checkboxes name. Nil falls back to UninstallIntegration. The kind is
	// passed for the same reason as above: custom is "deleted", npm is
	// "uninstalled".
	//
	// done reports the removal back to the dialog that asked, on the main
	// thread: a nil error closes it (the reference's
	// `setUninstallDialogTarget(null)` after `await`), and a non-nil error
	// leaves it open with its answer buttons usable again, exactly as the
	// reference's `runMutation` `finally` did (`src/ExtensionsPanel.tsx:1314-1341`).
	// It may be nil, in which case the caller closes the dialog at once.
	UninstallComponents func(id string, name string, kind string, components UninstallComponents, done func(error))
	// DiagnoseIntegration asks an integration's provider to check itself.
	DiagnoseIntegration func(id string)
	// RepairIntegration re-checks an installed package and repairs it when the
	// record drifted from what is on disk: the old host's `extensions_repair`,
	// behind the Wrench a broken row shows. Nil hides the button.
	//
	// done reports the re-check back to the row that asked, on the main thread:
	// the row's button leaves its in-flight face on the answer, whatever it
	// was, exactly as the reference's `runMutation` cleared `busy` in `finally`
	// (`src/ExtensionsPanel.tsx:1190-1210`). It may be nil, in which case the
	// row settles itself.
	RepairIntegration func(id string, done func(error))
	// ReconnectIntegration re-derives a system integration's runtime binding
	// from the search path: the old host's `extensions_reconnect_system`, and
	// the only repair a row whose program moved can offer. Nil hides the
	// button. done is the same in-flight hand-off as RepairIntegration's.
	ReconnectIntegration func(id string, done func(error))
	// OpenHomepage sends the user to an integration's own page — the
	// reference's `installTool` arm for a row whose runtime floter does not
	// own and cannot look for. Nil hides that button.
	OpenHomepage func(url string)
	// ReprobeCommands re-runs the connect-time help derivation of a
	// generated custom integration and rebuilds its command list. Nil
	// hides the button.
	ReprobeCommands func(id string)
	// ReprobeHealth re-runs an integration's stored lifecycle probes and
	// writes the new report back to the repository: the reference's
	// `extensions_reprobe` (`ExtensionsPanel.tsx:1139-1155`, `handleReprobe`),
	// which the Health block's own refresh button calls
	// (`:2908-2918`). Nil hides that button, exactly as the reference draws
	// it only when a report is on screen.
	ReprobeHealth func(id string)
	// SetShortcut records a new accelerator for an action id.
	SetShortcut func(id, accelerator string)
	// ShortcutRefused reports whether the shell's last attempt to bind id was
	// refused by the system (another app holds the chord). Nil means nothing
	// can tell, and the recorder keeps its optimistic reading.
	ShortcutRefused func(id string) bool
	// InstallFromRegistry installs a package from the npm registry.
	InstallFromRegistry func(name, constraint string)
	// SetCommandEnabled turns one of an integration's commands on or off: a
	// command only appears in the launcher while its switch is on.
	SetCommandEnabled func(extensionID, commandID string, enabled bool)
	// SetCommandAlias records one command's alias (an empty alias removes
	// the entry) and re-hands the launcher its command list.
	SetCommandAlias func(extensionID, commandID, alias string)
	// AdoptIntegration grafts an orphan package into the repository, and
	// DeleteOrphan removes an orphan package directory.
	AdoptIntegration func(id string)
	DeleteOrphan     func(id string)
	// InstallUpdate downloads and installs the update the last check found,
	// re-checking first the way the old build's `downloadAndInstallUpdate`
	// did. Nil hides the update row's control.
	InstallUpdate func()
	// ExportIntegrations writes the installed integrations to a file the user
	// picks, and ImportIntegrations applies one they pick.
	ExportIntegrations func()
	ImportIntegrations func()
	// RunWithParams runs an integration's command with the answers to its
	// declared inputs; the host turns them into argv and refuses an illegal
	// combination with a `run_param_*` key, which the form words under itself.
	// Nil hides the form.
	RunWithParams func(id string, values map[string]string) *extensions.ParamFailure
	// OpenConfiguration runs a tool-owned configuration's `openCommand` argv:
	// the reference's `onOpenCommand(plan, …)` arm for a `tool` owner, which
	// spawns the provider's own editor (`ExtensionsPanel.tsx:2982`). Nil
	// leaves the card's "Open configuration" button disabled.
	OpenConfiguration func(id string, argv []string)
	// InstallFromFolder installs a package directory the user picks, and
	// ChooseFolder asks them for one. Nil hides the row.
	InstallFromFolder func(dir string)
	ChooseFolder      func() (string, error)
	// Detected lists the programs the machine has that are not yet connected,
	// and ConnectDetected connects the one the user picked. Nil hides the
	// section.
	Detected        func() []DetectedTool
	ConnectDetected func(tool DetectedTool)
	// InstallDetected opens a terminal on the install command of a detected
	// tool that has a recipe but is not runnable yet — the reference's
	// `installInTerminal` arm, which hands the command to the user's own shell
	// (`src/ExtensionsPanel.tsx:2562-2574`). Nil leaves that button disabled.
	InstallDetected func(command string)
	// Freshness reports what is known about one integration's command list
	// (the help-probe sidecar and the health report); nil hides the row.
	Freshness func(id string) (extensions.Freshness, bool)
	// CopyText puts text on the clipboard, for the About page's deep links.
	CopyText func(text string)
	// ExportScript writes the local-tool form's script to a file the user
	// picks: the reference's `extensions_custom_export_script`, behind the
	// "Export script" button beside "Copy script"
	// (`CustomIntegrationDrawer.tsx:145`, `ExtensionsPanel.tsx:1951-1964`).
	// name is the file name the save dialog offers (the integration's id, the
	// word "script", and the language's extension); the host owns the dialog,
	// the write, and the success toast. Nil hides the button.
	ExportScript func(name, content string)
	// ExportScriptAsync is the same operation with a completion signal. The
	// host calls done once after success, failure or cancellation. Older
	// synchronous embedders may keep using ExportScript.
	ExportScriptAsync func(name, content string, done func())
	// EditCustomTool rewrites a generated integration from the same form the
	// connect flow uses (the id names it, so its identity is kept), and
	// ScriptRuntime answers what this machine has for a script language: the
	// interpreter on PATH and its version, or nothing. Nil means the form
	// cannot say, and shows the toolchain's name alone.
	ScriptRuntime func(language string) scriptlang.Check
	// Invalidate asks for another frame, from whatever goroutine the probe
	// finished on: mygo allows it from any goroutine, and the shell wires it to
	// the window. Nil just means no redraw is requested, so a headless test
	// drives its own frames.
	Invalidate func()
	// NotifyWarning reports a warning the form cannot draw for itself: the old
	// panel's `onNotify("warning", …)`, which reached the app's own notice
	// stack rather than the form — the message is about the machine, not about
	// a row the user is editing. The integration form raises one when it saves
	// a script whose toolchain this machine does not have; the save goes
	// through either way, so it is advice, never a refusal. Nil drops the
	// message.
	NotifyWarning func(text string)
	// NotifySuccess reports a confirmation the panel cannot draw for itself:
	// the old panel's `onNotify("success", …)`. The About page's deep-link
	// copy raises one — the reference's `DeepLinkRow.onCopied` reached the
	// app's toast stack, and a clipboard write is otherwise silent. Nil drops
	// the message.
	NotifySuccess func(text string)
	// ToolForEdit hands the form what that integration declares now. Both nil
	// hides the button.
	EditCustomTool func(id string, tool CustomTool)
	ToolForEdit    func(id string) (CustomTool, bool)
	// ConnectRecommended installs one of the shipped tool packages, and
	// ConnectLocalTool connects a program already on this machine.
	ConnectRecommended func(id string)
	ConnectLocalTool   func(tool CustomTool)
	// ChooseProgram asks the user to point at a program; nil hides the picker.
	ChooseProgram func() (string, error)
	// SaveConfiguration validates and stores an integration's configuration
	// values, moving its password fields into the secrets file. `done` reports
	// the write back on the main thread, whatever it did — the reference's
	// `runMutation` cleared `busy` in `finally`
	// (`ExtensionsPanel.tsx:1993-2007`) — so the Save's in-flight face is
	// swapped for the reference's `configSaving` word until the answer lands.
	// It is called exactly once, synchronously or from a goroutine.
	SaveConfiguration func(id string, values map[string]any, done func(error))
	// ExportConfiguration asks for a path and writes one integration's
	// host-owned configuration there, as the reference's
	// `extensions_config_export` did (`ExtensionsPanel.tsx:2036-2048`): the
	// toolbar's export icon-button. Values are the form's current draft, so a
	// user can export an unsaved edit. The host owns the document, the dialog
	// and the write, so the schema it validates against is the real one, never
	// a copy the form made. `done` is the same in-flight hand-off as
	// SaveConfiguration's; nil hides the button.
	ExportConfiguration func(id string, values map[string]any, done func(error))
	// CopyConfiguration puts one integration's host-owned configuration on the
	// clipboard as the reference's `extensions_config_copy` did
	// (`ExtensionsPanel.tsx:2019-2031`): the toolbar's copy icon-button. Like
	// `ExportConfiguration`, the host builds the document from the real schema
	// and raises the success notice; `done` is the same in-flight hand-off. Nil
	// turns the button into a no-op.
	CopyConfiguration func(id string, values map[string]any, done func(error))
	// ClearClipboardHistory drops every clipboard entry that is not a
	// favourite.
	ClearClipboardHistory func()
	// OpenPluginConfig opens one built-in plugin's declarative configuration
	// in the launcher — the same sheet the mode's own gear opens. Nil hides
	// the Configure buttons on the base-plugin rows.
	OpenPluginConfig func(id string)
	// SetPluginEnabled turns one built-in plugin's own switch on or off (the
	// clipboard history and the browser search; the calculator has none).
	// Nil hides the switches.
	SetPluginEnabled func(id string, enabled bool)
	// ResetShortcuts restores the shipped bindings, and
	// SetShortcutsSuspended releases the global shortcuts while a recorder
	// waits for a key (so pressing the current one is recorded rather than
	// acted on).
	ResetShortcuts        func()
	SetShortcutsSuspended func(suspended bool)
	// CustomShortcuts reports the user-defined global shortcuts, and
	// SetCustomShortcuts persists a new list and registers it, returning the
	// keys the system refused.
	CustomShortcuts    func() []settings.CustomShortcut
	SetCustomShortcuts func([]settings.CustomShortcut) []CustomShortcutRejection
	// SetPage records the page the user switched to (the
	// `last_settings_page` setting).
	SetPage func(name string)
}

// Integration is one installed extension, as the Integrations page lists it.
type Integration struct {
	ID          string
	Name        string
	Description string
	Publisher   string
	Version     string
	ToolVersion string

	Enabled bool
	// Running means it contributes commands; Broken that its runtime is
	// unusable; Error why its provider could not be asked.
	Running bool
	Broken  bool
	Error   string
	// FailureCode and FailureDetail are the failure the repository recorded
	// on the entry (R11): the code is a dictionary key and the detail is
	// usually a keyed payload. They stay raw so a language switch re-renders
	// the reason, and `failureReason` owns the words.
	FailureCode   string
	FailureDetail string
	// Orphan is a package directory no repository entry names.
	Orphan bool
	// Permissions are the ids the package declares, and Enforced which of
	// them the host itself decides.
	Permissions []string
	Enforced    map[string]bool
	// Diagnosis is what the last health check said, empty when none ran.
	Diagnosis string
	// DiagnosisFailed marks a check that reported a problem.
	DiagnosisFailed bool
	// DiagnosisLifecycleFailed keeps a prior probe failure visible alongside
	// the provider's independent verdict, without replacing that raw status.
	DiagnosisLifecycleFailed bool
	// DiagnosisChecks is what the last check looked at, in the provider's own
	// order: each check's id, the provider's status word for it and its
	// sentence. The reference's `.extension-diagnostics` grid prints one row
	// per check, so the status a single `Diagnosis` string could only
	// summarise is readable fact by fact
	// (`main:src/ExtensionsPanel.tsx:2895-2901`).
	DiagnosisChecks []DiagnosisCheck
	// DiagnosisStatus is the provider's own overall verdict for that check
	// (`diagnose.status`, `ExtensionsPanel.tsx:2896`), which the grid's summary
	// line prints in the provider's vocabulary. Empty when the provider named
	// none.
	DiagnosisStatus string
	// Health is the stored lifecycle probe report's status, empty when the
	// manifest declares no probes. It survives across runs (the repository
	// keeps it), so a row shows how the tool was last found to be.
	Health string
	// HealthStatus is the **raw** status word `Health` was printed from
	// (`extensions.HealthHealthy` &c.), which is what the chip's own face is
	// keyed on: the reference writes the modifier class straight from the
	// report (`className={`extension-health__status
	// extension-health__status--${healthReport.status}`}`,
	// `main:src/ExtensionsPanel.tsx:2924`), never from the translated word.
	// Reading the localized word back meant a word-table change — or a status
	// the four-word ladder does not name — silently dropped the chip to the
	// transparent `unknown` face. Empty when the row carries no report.
	HealthStatus string
	// HealthReport is that same stored report's detail: every probe with its
	// duration, the failed ones with their exit code and stderr, and when the
	// run happened. Nil when nothing has ever probed the integration.
	HealthReport *HealthReport
	// HealthReprobeUnavailable keeps historical reports readable when the
	// current manifest no longer declares executable lifecycle checks.
	HealthReprobeUnavailable bool
	// Approval is the recorded permission approval, as the card draws it: what
	// was approved, when, and against which manifest — with the on-disk
	// digest beside it, so "what I approved" and "what is here now" are two
	// readable facts (the old host's R7-8/R7-8b block). Nil when no approval
	// has ever been recorded.
	Approval *ApprovalRecord
	// Commands are the commands the integration declares, each with the
	// switch state the launcher reads.
	Commands []Command
	// Config is the schema the integration declares for its host-owned
	// configuration, and ConfigValues the values this machine holds (a
	// password's real value, which the form hides as it is typed). Both are
	// empty when the integration declares none.
	Config       []ConfigField
	ConfigValues map[string]any
	// ConfigOwner is the provider's own word for who holds the values: the
	// reference's `configuration.descriptor.owner` (`ExtensionsPanel.tsx:2975`).
	// Only a `host`-owned configuration is the form's to draw — a tool's own
	// configuration is opened where the tool keeps it — so a `tool` owner
	// hides the form's section (see configOwnerIsHost).
	ConfigOwner string
	// ConfigOpenCommand is the tool-owned configuration's open command: the
	// provider's `openCommand` argv, carried so the card can offer the
	// reference's "Open configuration" button
	// (`ExtensionsPanel.tsx:2977-2986`). Empty when there is nothing to open,
	// in which case the button is drawn disabled — the reference's
	// `disabled={!configuration.openPlan}`.
	ConfigOpenCommand []string
	// ConfigVersion is the schema generation the stored values were written
	// against, carried so a copied or exported configuration names it (the
	// reference's `ConfigurationExportDocument.config_version`,
	// `src-tauri/src/extensions/config.rs:88-93`). Zero when nothing is known.
	ConfigVersion int
	// Generated marks an integration the host itself created from a local
	// tool's own help: only these can be re-probed, so only these get the
	// button.
	Generated bool
	// DistributionSource and RuntimeOwnership are the repository's own kind
	// fields (`npm`/`local`/`built-in`, and `bundled`/`system`). Together with
	// Generated they are what the card's removal verb is derived from, exactly
	// as the reference's `removalKind` read them
	// (`src/extensions/ExtensionRow.tsx:109-114`).
	DistributionSource string
	RuntimeOwnership   string
	// RuntimeSource is where the runtime lives, the reference's own
	// `runtimeSource` projection (`managed`/`system`/`bundled`,
	// `src-tauri/src/commands/extensions.rs:540-550`): a package that bundles
	// its runtime is `bundled`, an executable or descriptor runtime is
	// `managed` when Floter owns it and `system` when the machine does. It is
	// the meta line's third fact, beside the package identity and the kind.
	RuntimeSource string
	// Highlighted marks the integration a `floter://register` link named, so
	// its card wears the link's mark
	// (`src/extensions/ExtensionRow.tsx:196-205,290`). It is a status mark,
	// not a control: nothing about the card's actions changes.
	Highlighted bool
	// RuntimeAvailable says the runtime the entry was bound to still
	// resolves: the program is on disk, or the interpreter a script needs is
	// installed. A row whose runtime is gone offers the reference's repair
	// action instead of a run it could not perform
	// (`src/extensions/ExtensionRow.tsx:345-370`).
	RuntimeAvailable bool
	// Homepage is the project's own page when the manifest names one. It is
	// where the repair sends a user when floter has no runtime of its own to
	// look for, the reference's `installTool` arm.
	Homepage string
	// Params are the declared inputs a run needs: the card renders a form for
	// them, and the answers become argv.
	Params []Param
	// OutputMode is the manifest's declared route for a run: `terminal` (a
	// live session on the terminal page) or `background` (a captured run
	// that reports through a notice). The run form states it up front, as the
	// reference's `RunParamForm` did with `extension.output`
	// (`src/extensions/ExtensionRow.tsx:465-467`).
	OutputMode string
}

// DiagnosisCheck is one thing a provider's last health check looked at, as
// the `.extension-diagnostics` grid draws it: the provider's own status word
// (never translated — it is the vocabulary the provider answered in) and its
// message.
type DiagnosisCheck struct {
	ID      string
	Status  string
	Message string
}

// HealthReport is the stored lifecycle probe report's detail, as the card
// draws it: when the run happened and what each probe did.
type HealthReport struct {
	// CheckedAt is the run's RFC 3339 timestamp, as the repository stored it.
	CheckedAt string
	Probes    []HealthProbe
}

// ApprovalRecord is the repository's stored approval, projected for the
// card: when it happened, the permission ids it covered (tiered by the same
// host-enforced vocabulary the permission audit uses), and the manifest
// digest it is bound to — beside the digest of the manifest on disk now, so
// a post-approval change is two rows the user can read, not a boolean.
type ApprovalRecord struct {
	// At is the approval's Unix seconds, as the repository recorded them.
	At uint64
	// ApprovedDigest is the manifest digest the approval is bound to
	// (`sha256-…`), empty when the record predates the field.
	ApprovedDigest string
	// CurrentDigest is the digest of the manifest on disk now, empty when it
	// could not be read. "Unknown" stays distinguishable from "changed".
	CurrentDigest string
	// Permissions are the approved ids, split into the two tiers by the
	// host's own classifier (an unknown permission is disclosure, never
	// enforced: over-claiming enforcement is the failure mode that would
	// make the UI lie). Each group preserves the record's own order.
	Enforced   []string
	Disclosure []string
}

// HealthProbe is one probe record of a stored report.
type HealthProbe struct {
	ID         string
	Passed     bool
	DurationMs uint64
	// ExitCode is -1 when the probe never ran to an exit.
	ExitCode int
	Stderr   string
	// Retryable is true for an optional probe: a failed required probe is a
	// broken tool, not a transient one. It is projected from the manifest's
	// own `required`, so it never has to be persisted twice.
	Retryable bool
}

// Param is one declared input, as the form renders it.
type Param struct {
	ID          string
	Label       string
	Kind        string // text, number, boolean, select, path
	Default     string
	Required    bool
	Placeholder string
	Options     []string
	Flag        string
}

// ConfigField is one field of an integration's host-owned configuration, as
// the settings form renders it.
type ConfigField struct {
	Key         string
	Label       string
	Type        string // text, password, path, select, multiSelect, boolean, number
	Description string
	Required    bool
	Default     any
	Options     []string
	Minimum     *float64
	Maximum     *float64
	MinLength   *int
	MaxLength   *int
}

// Command is one of an integration's commands, as the switch list shows it.
type Command struct {
	ID          string
	Name        string
	Description string
	// Aliases are the descriptor's own declared aliases, which together with
	// the id and the name form the summon vocabulary the panel prints — the
	// reference's `pluginCommandTriggers(command)` reads exactly these three
	// sources (`plugins/external.ts:86-97`), so the words the panel shows are
	// the words that enter the mode.
	Aliases []string
	// Enabled is whether the command may be summoned from the launcher.
	Enabled bool
	// Declared is whether the provider's descriptor declared this command, as
	// opposed to one the host synthesized (the tool-owned configuration
	// editor). The reference prints the summon words only for a command its
	// registry knows (`ExtensionsPanel.tsx:2824-2829`), and the synthesized
	// command is never in it (`main:src-tauri/src/extensions/catalog.rs:427-449`).
	Declared bool
	// Available is whether the integration's runtime resolves right now: a
	// command whose runtime is missing is still listed, and says so.
	Available bool
	// Alias is what the user types to summon this command. Taken marks an
	// alias another command claimed first — the conflict policy is first
	// come first served, so the field keeps the user's text but the row says
	// it is not live.
	Alias string
	Taken bool
}

// UninstallComponents says which parts of an installed integration to remove.
// The program always goes; the three data categories are the user's choice.
type UninstallComponents struct {
	// RemoveHostConfig removes the host-owned configuration (config.json and
	// the secrets generations).
	RemoveHostConfig bool
	// RemoveToolData removes the tool's own data (sessions, completions,
	// health).
	RemoveToolData bool
	// RemoveArtifacts removes generated artifacts (logs, caches,
	// user-generated files).
	RemoveArtifacts bool
}

// Session is one running session, as the Sessions page shows it.
type Session struct {
	// ID is the session's stable identity, the key the close control arms on:
	// the sessions list can shrink while a question is up, and the armed
	// session has to stay the same one (the reference's `killArmedId`),
	// `src/settings/SessionsPage.tsx:54`). Zero never arms.
	ID      uint64
	Title   string
	Running bool
	// Failed marks a program that ended with a non-zero code, and it is what
	// lets the state word say *how* it ended rather than only *that* it did
	// (P13-cm). The word already carries the code (`Note`: "Exited · exit 3"),
	// so this bit answers one question only — whether the ending is painted in
	// the warning hue. It is the list's arm of the same rule the terminal
	// surface's resident note follows (`terminalui.residentNote`: `ExitCode !=
	// 0` → `t.Warning`), and of the one P13-bg pinned for the captured-output
	// page (`docs/liquid-glass.md` §6.26: a hue is semantics, not emphasis).
	// Meaningless while `Running`: a program still running has no ending.
	Failed bool
	// Active marks the session on screen: the one the terminal surface is
	// showing, and the one "close" would end without asking which.
	Active bool
	// Index is the session's own position, which a click hands back.
	Index int
	// Note is the session's state line: how the program went, when it did.
	Note string
	// Dir is the working directory the shell reported (empty when it has not
	// said), and Size the screen's size in cells, as "80×24".
	Dir  string
	Size string
	// Created is when the session started: the list's own order axis, newest
	// first by default as the old page listed them.
	Created time.Time
}

// About is what the About page shows: the identity of the build and where
// its files live.
type About struct {
	Name         string
	Version      string
	Framework    string
	Scheme       string
	SettingsPath string
	RepoURL      string
}

// UpdateProgress is the bytes a running update download has and the total it
// expects. Total is 0 when the feed did not report one, which is the state the
// old build's progress label drew as a bare downloaded count.
type UpdateProgress struct {
	Downloaded int64
	Total      int64
}

// UpdateState is the About page's update row, as the last check and the running
// download left it: the old build's `updateInfo` / `updateDownloading` /
// `updateProgress` / `updateFailed` quartet, plus the no-feed state this build
// can be in.
type UpdateState struct {
	// Checked is true once a check has answered (found, up to date, or
	// disabled); a failed check is also an answer and sets Failed.
	Checked bool
	// Available is true when the check found a newer version, named by
	// Version.
	Available bool
	Version   string
	// Downloading is true from the moment the download starts until it
	// finishes or fails; Progress is set while the bytes are moving.
	Downloading bool
	Failed      bool
	// Disabled is true when the build has no update feed at all.
	Disabled bool
	Progress *UpdateProgress
}

// App is the settings surface's state.
type App struct {
	sidebarMotion  bool
	sidebarMarker  ui.Handle
	integrationNav integrationNavigation

	Store   *settings.Store
	Actions Actions
	About   About

	// tokensStore and tokensMemo are the frame's card language (see `tokens`):
	// the memo the rows read their colors from, and the store it was built
	// for. Built once per change rather than once per row, which is where most
	// of a settings frame's CPU went before P11-bs.
	tokensStore *settings.Store
	tokensMemo  theme.Memo

	// settingsMemo is this surface's copy of the settings value (P11-co). A
	// frame read it fifteen times on the General page and fifty-three on the
	// Integrations page — once per card, once per row, once per word — and
	// `Store.Snapshot` deep-copies the whole value, the carried-through keys
	// included (`settings.clone` was 9.31% of a General frame's allocated
	// objects). Readers that run off the render thread keep asking the store
	// directly: a Memo belongs to one reader and is not safe for concurrent use.
	settingsMemo settings.Memo

	// Now is the panel's time source, injectable so the save-failure banner's
	// window can be exercised without waiting for it; nil means the wall
	// clock.
	Now func() time.Time

	// cardRows counts the rows the card being built has drawn, so each row
	// after the first draws the rule above itself. It is the build's own
	// cursor, reset by card and never read outside it.
	cardRows    int
	cardCompact bool

	// cardRowInset, cardTitleFloor and cardLineGap are the row geometry the
	// card being built wears when it is not the settings default: zero means
	// the settings card's own 14u inset, 44u floor and 1px line gap. The
	// integration card is the one caller that sets them (cardGeometry),
	// because it draws the reference's `.extension-row` — an 8u padding, a 66u
	// floor and a 4px line gap (`extensions.css:15-16,733-744,879-880`) — so
	// its title row and every row under it line up on the extension row's own
	// text column. `card` resets them to the default, so a card nested inside
	// the integration card (the run form, the config fields) keeps the
	// settings geometry.
	cardRowInset   float32
	cardTitleFloor float32
	cardLineGap    float32

	// cardUnit is the metric unit the surface being drawn uses when its
	// reference CSS is *not* written in `--u`: zero keeps the theme's own
	// `Space` (4·scale), and a positive value is the literal unit the surface
	// pins instead (4 for the extension panel, whose `extensions.css` is
	// written in literal px — a 66px row, a 30px chip, an 8px padding — and so
	// does not follow the interface step). It is set for the duration of a
	// draw by extensionMetrics and read through cardSpace/cardTheme, so a
	// helper that sizes its own metrics follows the surface it is drawn on.
	cardUnit float32

	// cardNoRules suppresses the row separator for the duration of a draw.
	// The reference's `.extension-run-params` is a grid whose rows are spaced
	// 6px apart and never ruled (`extensions.css:1224-1233` — only `gap`, no
	// hairline), so the run form must not read as a settings card's ruled rows.
	// runParamsBox sets it while its rows are drawn and restores it after; zero
	// means the ordinary settings behaviour, where every row but the first
	// draws the rule.
	cardNoRules bool

	// disableConfirm marks the integrations whose switch was turned off and
	// is waiting for the user's answer. removeConfirm marks the ones whose
	// destructive button was pressed and is likewise waiting — the old
	// panel's removal bar (`RemovalConfirmation`), asked inline rather than
	// through a native dialog. runValues holds the run form's
	// answers and last refusals per integration. runOpen is
	// which integrations have their run form unfolded: the row's Run
	// button is the disclosure (the reference's `runFormOpen`), so an
	// integration that declares inputs does not wear the form until it is
	// asked for. runOutputs holds each integration's last background run and
	// outputOpen which of those blocks are unfolded (the old panel's
	// `runOutputs` / `outputOpen`), with outputScroll the fixed-height
	// scroller's offset.
	disableConfirm map[string]bool
	removeConfirm  map[string]bool
	// disableConfirmAt and removeConfirmAt are when each question was asked:
	// the reference armed both bars with `useTimedReset(removalTarget, …)` /
	// `useTimedReset(disableTarget, …)` and its default 3000 ms window
	// (`src/hooks/useTimedReset.ts:3`, `src/ExtensionsPanel.tsx:864-865`), so an
	// ask left unanswered withdraws instead of staying armed on a later glance.
	disableConfirmAt map[string]time.Time
	removeConfirmAt  map[string]time.Time
	// disableBusy and removeBusy mark the bands whose answer is in flight, so
	// the confirm pill holds the reference's disabled face (`disabled={busy}`,
	// `opacity: 0.4`, no hover/press) until the shell reports back; the error
	// maps carry the failure that left a band open, exactly as the uninstall
	// dialog's busy/error pair does (`ComponentizedUninstallDialog.tsx:126`).
	disableBusy  map[string]bool
	disableError map[string]string
	removeBusy   map[string]bool
	removeError  map[string]string
	// repairBusy marks the integrations whose re-check or reconnect is in
	// flight, so the row's own button wears the reference's turning LoaderCircle
	// and its `disabled={busy}` face until the shell reports back
	// (`src/extensions/ExtensionRow.tsx:313-330,345-372`).
	repairBusy map[string]bool
	// healthBusy is the Health block's own refresh, separate from repair so
	// the re-check/reconnect pill does not pretend to own that operation.
	healthBusy map[string]bool
	// diagnosisBusy covers both lifecycle probes and the provider check.
	diagnosisBusy map[string]bool
	// orphanOperation holds the same row lock while adoption asks for
	// permissions or a package directory is being deleted.
	orphanOperation map[string]string
	// packageInstallBusy belongs to the visible install outlet, before the
	// package has an installed integration row of its own.
	packageInstallBusy map[string]bool
	// toggleBusy marks the integrations whose enable write is in flight, so
	// the row's switch swaps its thumb for the reference's turning LoaderCircle
	// and holds its `disabled` face until the shell reports back
	// (`src/extensions/ExtensionRow.tsx:443-455`). A disable write rides
	// disableBusy: its answer comes from the confirmation band, not the switch.
	toggleBusy   map[string]bool
	runValues    map[string]map[string]string
	runError     map[string]string
	runRefusals  map[string]runRefusal
	runOpen      map[string]bool
	runOutputs   map[string]RunResult
	outputOpen   map[string]bool
	outputScroll map[string]*ui.ScrollState
	outputKeys   map[string]*int // each completed run owns its selectable document

	// The local-tool form's draft: what the user has typed, and the
	// permissions they have ticked. It lives on the panel so a keystroke
	// survives the rebuild, and it is cleared once the tool is connected.
	toolOpen bool
	// Each editing session owns the toolkit's field histories and selections.
	toolFormKey     *int
	toolRecover     func()
	toolDisclosure  uint64
	toolReturnToAdd *int
	// Leaving integrations retires content callbacks, independently of the
	// connection recovery and the editable draft that survive navigation.
	toolPageEpoch uint64
	// toolAdvanced is whether the form's declaration/audit switches are
	// unfolded: they sit behind a default-closed Advanced disclosure (R161),
	// so a brand-new integration does not open on a list of permission rows.
	toolAdvanced bool
	// toolMode is the kind of tool the form is building: "" (a program on
	// this machine) or "script".
	toolMode string
	// toolLanguage and toolScript are a script's own draft.
	toolLanguage    string
	toolScript      string
	toolName        string
	toolProgram     string
	toolCommand     string
	toolArgs        string
	toolVersionArgs string
	toolVersion     string
	toolDescription string
	toolOutput      string
	// toolPlatforms is which operating systems the connection is limited to,
	// keyed by the platform ids the manifest carries (see customPlatforms).
	// Nil means the form has not touched the row yet, so it starts on the
	// current platform alone (R7-5).
	toolPlatforms   map[string]bool
	toolPermissions map[string]bool
	// A native save dialog belongs to the shared export outlet, including
	// when its originating form is folded or replaced. Only the UI thread
	// consumes this completion channel.
	toolExportDone <-chan struct{}
	// toolParams is the declared inputs the form is editing, one per row.
	toolParams []toolParam
	// scriptRuntime is the script form's own probe state, one entry per
	// language: the old panel's `runtimeChecks` mirror. A probe runs off the
	// render thread, so the muted line can say "checking" instead of blocking
	// the frame on a `--version` subprocess; `scriptRuntimeMu` guards the map
	// because the probe lands on its own goroutine. `scriptRuntimeEpoch` is the
	// old drawer's `runtimeChecksEpoch`: a form that closed and reopened in
	// between must not inherit the previous session's verdict, so a stale
	// result is dropped rather than cached.
	scriptRuntime      map[string]*runtimeProbe
	scriptRuntimeMu    sync.Mutex
	scriptRuntimeEpoch int
	// scriptEditor is the form's script box, kept across frames so its buffer,
	// undo history and caret survive the rebuild; nil until a script form is
	// first drawn. See scripteditor.go.
	scriptEditor *scriptEditor
	// toolEditing is the integration the form is rewriting, empty when it is
	// connecting something new.
	toolEditing string
	// toolIssue is whether the form has been submitted and refused: the rows
	// name what they still need only after the user asked, so a form that just
	// opened is not already covered in red.
	toolIssue bool

	// armedSession is the session whose close control has been pressed once,
	// named by its stable ID, and armedSessionAt when it was asked: the second
	// press ends the session's program, and the question answers itself with
	// "keep" after sessionCloseWindow. A zero ID is "nothing armed" and never
	// matches a real session (the reference's `killArmedId` was a
	// `string | null`, `src/settings/SessionsPage.tsx:54`); the two fields are
	// only ever set together, so the clock drives the expiry and the ID drives
	// the match.
	armedSession   uint64
	armedSessionAt time.Time
	// sessionsSortOldest is the sessions list's order: false (the shipped
	// state) lists the newest session first, as the old page's own default,
	// and the heading's control flips it.
	sessionsSortOldest bool

	// residencyInit, residencyCustomOpen and residencyDraft are the
	// page-residency control's own state: whether the inline custom field has
	// been seeded yet, whether it is open, and what it drafts. residencyInit
	// seeds the other two once from the stored value on the first frame, so a
	// stored custom duration opens the field it came from — the reference's
	// `useState` initializers in `SurfaceResidencyControl`.
	residencyInit       bool
	residencyEditing    bool // an explicitly opened or edited custom draft owns its value
	residencyCustomOpen bool
	residencyDraft      string

	// saveFailed is set when one of the page's own controls could not write
	// its change back, with saveFailedAt the moment it failed: the banner over
	// the page says so and clears itself after a few seconds (see
	// savealert.go).
	saveFailed   bool
	saveFailedAt time.Time
	// saveAlertShown is whether the current banner has drawn its first frame,
	// and saveAlertProgress/saveAlertAnimating where its enter animation is:
	// see savealert.go.
	saveAlertShown     bool
	saveAlertProgress  float32
	saveAlertAnimating bool

	// entered marks that the panel's first frame has been drawn. The shell
	// asks for the sidebar's focus when it opens the surface, but on the very
	// first open the list has no state to take the request yet; View delivers
	// it once the list is built, and entered keeps that to once.
	entered bool
	// sidebarEntryFocus is the reference's `data-entry-focus` (R152): as the
	// panel opens the sidebar takes the keyboard, but the chosen pill already
	// marks the keyboard position, so the list's `:focus-visible` ring is
	// withheld until the first interaction. entryFocusArmed records that the
	// focus really landed, so a later loss of it can drop the mark.
	sidebarEntryFocus bool
	entryFocusArmed   bool

	// debouncing marks a slider preview or alias edit that has been shown but
	// not written yet, with debounceAt the moment the window closes;
	// pendingAliases holds the latest alias per command while it runs. See
	// debounce.go for the reference's 180ms rule.
	debouncing     bool
	debounceAt     time.Time
	pendingAliases map[string]aliasEdit

	// Sessions reports the running sessions; nil when the shell has none
	// (tests).
	Sessions func() []Session
	// Recommended reports the shipped tool packages and whether each is
	// installed; nil when the shell has none (tests).
	Recommended func() []RecommendedTool
	// Integrations reports the installed extensions; nil when the shell has
	// none (tests).
	Integrations func() []Integration
	// Shortcut is the global summon key the shell registered, and
	// ShortcutID the action it belongs to.
	Shortcut   string
	ShortcutID string
	// recording is set while the recorder waits for a key combination.
	recording bool

	// Page is the chosen page, an index into the sidebar.
	Page int

	// Update is the About page's update state: what the last check found,
	// whether a download is running, and the bytes it has so far.
	Update UpdateState
	// copiedLink is the deep-link value the About page's copy button last put
	// on the clipboard, and copiedLinkUntil when its confirmation expires. The
	// button reads "Link copied" while it holds (the old build's 1.6s), so a
	// press that landed reads differently from one that did not.
	copiedLink      string
	copiedLinkUntil time.Time
	// copiedContent is which of the local-tool form's content actions last put
	// something on the clipboard ("script", "command", "plan"), and
	// copiedContentUntil when that button's confirmation expires. Keying by the
	// action rather than by the copied text keeps two buttons that happen to
	// copy the same bytes from lighting up together (the reference's
	// `customContentOperation` plus one `showSuccess` per press).
	copiedContent      string
	copiedContentUntil time.Time
	copiedContentValue string
	// uninstallOpen is which integrations have the componentized uninstall
	// dialog open, and uninstallDraft its checkboxes.
	uninstallOpen  map[string]bool
	uninstallDraft map[string]UninstallComponents
	// uninstallBusy is which integrations have a componentized removal in
	// flight, so the dialog's two pills hold the reference's disabled face
	// (`ComponentizedUninstallDialog.tsx:126,142`) until the answer lands, and
	// uninstallError the last failure on a dialog that stayed open.
	uninstallBusy  map[string]bool
	uninstallError map[string]string
	// auditOpen is which integrations have their permission audit unfolded,
	// configOpen which configuration forms are open, configDrafts their form
	// state, and configError the last save's error.
	auditOpen    map[string]bool
	configOpen   map[string]bool
	configDrafts map[string]*configDraft
	configError  map[string]string
	// configOperations is which integrations have a copy or export in flight
	// ("copy" or "export"), configSaveBusy which have a save in flight, and
	// configDiscard which have asked to fold a dirty form away. The
	// reference's one `configOperation` item disabled both the toolbar's
	// icon-buttons (`disabled={Boolean(configOperation)}`,
	// `ExtensionsPanel.tsx:2994,2997`) — a copy and an export cannot run at
	// once — while `busy.kind === "save"` swapped the Save's own word
	// (`ExtensionsPanel.tsx:3020`: `t("settings.extensions.saving")`).
	configOperationMu sync.RWMutex
	configOperations  map[string]string
	configSaveBusy    map[string]bool
	configDiscard     map[string]bool
	// configDiscardAt is when each fold-away question was asked: the reference
	// armed it with `useTimedReset(detailsDiscardArmed, …)` and its 3000 ms
	// default (`ExtensionsPanel.tsx:866,2056-2060`), so an ask left unanswered
	// withdraws.
	configDiscardAt map[string]time.Time
	// configFieldErrors is the sentence shown at one field of one integration,
	// keyed by the integration and the field (see configFieldErrorKey): the
	// reference left the schema's `min`/`max`/`minLength`/`maxLength` bounds to
	// the native control, which drew its own validity state *at the field*
	// (`ExtensionsPanel.tsx:3251-3256`), so the hint belongs there rather than
	// only on the form's own bottom line.
	configFieldErrors map[string]string
	// configListScrolls keeps each multiselect list box's own offset, keyed by
	// the integration and the field, so a long option list scrolls inside the
	// reference's 66px viewport where the user left it.
	configListScrolls map[string]*ui.ScrollState
	// shortcutsSuspended is the last state reported to the shell, so the
	// recorder releases the global keys once and takes them back once.
	shortcutsSuspended bool
	// TransferBusy is "export" or "import" while a transfer is in flight, and
	// empty otherwise: the reference's `syncOperation`, which disables the two
	// buttons and shows the busy line while one runs.
	TransferBusy string
	// TransferReport is what the last import did; nil until one runs, and
	// cleared when the next transfer starts (the reference's `importReport`).
	TransferReport *ImportReport
	// Visible sections before the installed list can move its active forms.
	// Rebuilt while drawing; hidden recommendations and callback addresses
	// do not contribute, so equal refreshes preserve manual scrolling.
	integrationLead string

	// Sidebar holds the page list's identity, its choice and its focus.
	Sidebar ui.ListState
	// Body keeps the form's scroll offset across frames.
	Body          ui.ScrollState
	bodyScrollbar scrollbarActivity
	// PluginScroll keeps the plugin configuration sheet's offset, so a long
	// schema scrolls where the user left it.
	PluginScroll    ui.ScrollState
	pluginScrollbar scrollbarActivity
	// sheetPlugin is the plugin id the current `PluginScroll` belongs to.
	// P13-gu：一个 App 依次画每个插件的浮层，而 `ui.Scroll` 的 key 是常量；
	// 插件一变就把偏移归零，免得 A 的滚动位置接到 B 身上（§6.163）。
	sheetPlugin      string
	pluginSections   []*pluginSectionIdentity
	pluginEditorRefs map[string]*ui.Handle
	// pluginNumberDrafts holds a number field's in-progress text while its box
	// has the keyboard, so a half-typed or emptied value is not overwritten by
	// the stored one mid-edit; an entry is dropped when the box loses focus and
	// the field re-reads its value (the framework's `ui.NumberInput` did the
	// same with its own local draft). Both draft maps are keyed by the plugin id
	// plus the field key: one App draws every plugin's sheet in turn and a field
	// key is not unique across plugins.
	pluginNumberDrafts   map[string]string
	pluginNumberObserved map[string]float64
	// Text fields commit on Enter, so their unsubmitted edit must survive
	// frames independently of the stored value, just like number drafts.
	pluginTextDrafts map[string]string
	// Last host text, used to distinguish withdrawn edits from real conflicts.
	pluginTextObserved map[string]string
	// pluginTextCommits holds the text a text field handed the host on its
	// submit frame, until the next frame can read the host's own answer to it.
	// The host normalizes what a field sends (`plugincfg.coerce` trims a text
	// value and an all-space one becomes empty), so without this record the box
	// keeps painting the text that was sent while the plugin holds something
	// else — until the box loses the focus and re-reads the value.
	pluginTextCommits map[string]string

	// installName and installVersion are the npm install field's contents.
	installName     string
	installVersion  string
	installRevision uint64

	// The custom-shortcut row being made: whether it is on screen at all (the
	// reference's Add put it there), the recorded key, the chosen action and,
	// for a command line, its text. customRecordRow names the row the recorder
	// is editing: an index into the stored list, or -1 for the row being made.
	customDraftOpen  bool
	customRecording  bool
	customRecordRow  int
	customRecordKey  string // identity survives a host list reorder
	customFocusKey   string // recorder destination after a binding changes key
	customFocusDraft bool
	customFocusAdd   bool
	customKey        string
	customAction     string
	customCommand    string
	// customDuplicate is a key this section refused on the spot (another custom
	// row already holds it), and customRejections are the keys the shell could
	// not register with the system. Both hang under the row that holds the key.
	customDuplicate    string
	customDuplicateRow int
	customDuplicateKey string // binding whose recording was refused
	customRejections   []CustomShortcutRejection
	// Availability is the host's current registration result, independent of
	// the page's history of refused edits.
	CustomUnavailable []CustomShortcutRejection
	SummonUnavailable bool
	// customEdits holds a saved row's command line while it is being typed in
	// place, keyed by the binding. The reference kept the same draft on the row
	// (`row.command`) and committed it on Enter/blur (`ShortcutsPage.tsx:204-216`);
	// the port's fields commit on Enter, so the text lives here between frames
	// and is dropped when the row's action is rewritten or the row is removed.
	customEdits map[string]string

	// rejectedShortcut is the action whose last recording the page refused —
	// the reference's `rejectedAction`. It carries the warning at the top of
	// the page and under that row's name until the next recording starts.
	rejectedShortcut string
}

// CustomShortcutRejection is a key the system would not bind.
type CustomShortcutRejection struct {
	Key    string
	Reason string
}

// The reasons a custom global shortcut is refused, as the shell reports them
// and the settings page words them. The old host had exactly these two tokens
// (`src-tauri/src/commands/config.rs:1691,1707`): a key that shadows one of the
// app's own shortcuts is a `conflict`, and one the system will not take (almost
// always another application already owns it) is `occupied`.
const (
	// CustomShortcutReasonConflict: the key is already one of the app's own.
	CustomShortcutReasonConflict = "conflict"
	// CustomShortcutReasonOccupied: the system refused the key.
	CustomShortcutReasonOccupied = "occupied"
)

// New builds the settings surface over a store.
func New(store *settings.Store, actions Actions) *App {
	a := &App{Store: store, Actions: actions, customRecordRow: -1}
	// The sidebar is a click-only list: it is *not* given a cursor, so the
	// framework's own list navigation never claims ↑/↓. The reference's page
	// keys are the window's, not the sidebar's — they walk the pages from
	// anywhere on the surface, wrap at both ends, and remember the choice
	// (see `stepPage`). Giving the list a cursor here would put its
	// non-wrapping, non-persisting navigation in front of that handler
	// whenever the sidebar held the keyboard.
	a.Sidebar.Label = func(row int) string { return a.page(row).Title }
	return a
}

// FocusSidebar asks for the keyboard focus on the page list, and arms the
// entry-focus mark: the shell calls it when the settings surface opens, so the
// sidebar is where the keyboard starts (the reference's
// `focusCurrentSettingsSidebar`).
func (a *App) FocusSidebar() {
	a.Sidebar.Handle.Focus()
	a.sidebarEntryFocus = true
	a.entryFocusArmed = false
}

// SidebarEntryFocus reports whether the sidebar's entry-focus mark is up — the
// reference's `data-entry-focus` (R152) — for the tests.
func (a *App) SidebarEntryFocus() bool { return a.sidebarEntryFocus }

// page describes one sidebar entry in the current language.
type page struct {
	Title string
	Hint  string
}

// bodyPage is the page whose body `body` draws. An index this build does not
// know falls back to the first page — the same clamp `page` applies to the
// title and `PageName` applies to the stored id, so the three of them can never
// describe two different pages in one frame (P13-by).
func bodyPage(page int) int {
	if page < 0 || page >= pageCount {
		return PageGeneral
	}
	return page
}

// page returns the i-th page's copy.
func (a *App) page(i int) page {
	c := i18n.For(a.settings().Language).Settings
	switch i {
	case PageSessions:
		return page{c.PageSessions, c.PageSessionsHint}
	case PageShortcuts:
		return page{c.PageShortcuts, c.PageShortcutsHint}
	case PageIntegrations:
		return page{c.PageIntegrations, c.PageIntegrationsHint}
	case PageAbout:
		return page{c.PageAbout, c.PageAboutHint}
	default:
		return page{c.PageGeneral, c.PageGeneralHint}
	}
}

// RecordingShortcut reports the current capture owner before View publishes
// its deferred suspension change to the shell.
func (a *App) RecordingShortcut() bool {
	return a.recording || a.customRecording
}

// StopShortcutRecording releases capture when its page or window leaves.
// Recorded draft keys and unsubmitted commands still belong to the form.
// Publish immediately: a hidden window may not draw another frame.
func (a *App) StopShortcutRecording() {
	a.recording, a.customRecording = false, false
	a.customRecordRow, a.customRecordKey = customDraftRow, ""
	a.syncShortcutSuspension()
}

// syncShortcutSuspension tells the shell whether a recorder is waiting for a
// key. While one is, the global shortcuts are released: pressing the key that
// currently summons floter must be recorded, not acted on.
func (a *App) syncShortcutSuspension() {
	if a.Actions.SetShortcutsSuspended == nil {
		return
	}
	suspended := a.recording || a.customRecording
	if suspended == a.shortcutsSuspended {
		return
	}
	a.shortcutsSuspended = suspended
	a.Actions.SetShortcutsSuspended(suspended)
}

// View builds the settings surface: the page list beside the body.
func (a *App) View(c *ui.Context) {
	defer func() {
		changed := a.shortcutsSuspended != (a.recording || a.customRecording)
		a.syncShortcutSuspension()
		if changed {
			// Resume runs after this tree was built. Draw its registration
			// result without waiting for an unrelated input event.
			c.AnimationFrame()
		}
	}()
	copy := i18n.For(a.settings().Language).Settings
	t := c.Theme()
	a.retireMissingConfirmations()

	// A write the page's own controls could not commit is announced for a few
	// seconds; while one is up the frame keeps coming so the deadline is
	// reached on a still page.
	a.expireSaveFailed(c)
	// A slider drag or alias edit is shown at once but written once the pause
	// passes; the frame keeps coming until the window closes.
	a.expireSettingsWrites(c)
	// A session's two-step close also carries its own clock: the reference's
	// `killArmTimer` reverted the button after three seconds, so an ask left
	// unanswered does not stay armed on a later glance.
	a.expireSessionClose(c)
	// The two inline confirmations carry the same clock: the reference armed
	// their targets with `useTimedReset` and its own three-second default
	// (`src/ExtensionsPanel.tsx:864-865`).
	a.expireConfirmations(c)

	// The panel's very first frame puts the keyboard on the sidebar. The
	// shell's own `FocusSidebar` runs when the surface opens, before the list
	// has ever been built, so on the first open the request has nowhere to
	// land; delivering it here, once the list takes state, is the reference's
	// `focusCurrentSettingsSidebar` (`src/App.tsx`).
	if !a.entered {
		a.entered = true
		a.FocusSidebar()
	}

	// While a recorder waits, Escape belongs to it: a shortcut of the view is
	// handled before the focused element's input, so both recorders have to
	// yield or their cancel key would close the panel instead. And while any
	// confirmation or armed session close is up, Escape answers that question —
	// it must not fall through to Close and leave the page as well (the
	// reference's own `stopImmediatePropagation`: the removal/disable bars and
	// the sessions page's kill arm each installed a capture-phase Escape
	// listener that cancelled the question and swallowed the key).
	escape := func() {
		switch {
		case a.recording:
			// The armed recorder owns the first bare Escape even after the
			// keyboard has moved elsewhere. Its capture pane only sees the key
			// while it still holds the focus; without this arm, clicking any
			// other control left the recorder armed (and the global shortcuts
			// suspended) with no way to give it up.
			a.recording = false
		case a.customRecording:
			// Same for the custom-shortcuts row: its recorder is armed on the
			// page, not on whichever control happens to hold the keyboard now.
			a.customRecording = false
			a.customRecordRow = customDraftRow
		case a.anyConfirmOpen():
			a.cancelConfirmations()
		case a.anySessionArmed():
			a.disarmSessionClose()
		case a.Page == PageIntegrations && a.integrationNav.detail != nil:
			a.flushSettingsWrites()
			a.closeIntegrationDetail()
		case a.Actions.Close != nil:
			a.Actions.Close()
		}
	}
	if c.Shortcut(0, ui.KeyEscape) {
		escape()
	}

	// ↑/↓ walk the sidebar from anywhere on the surface — a header button, a
	// control, or the sidebar itself — wrapping at both ends, as the
	// reference's window-level handler did (`useAppKeyboard.ts`: "↑/↓ cycle
	// sidebar pages from anywhere in the settings panel"). An editor keeps its
	// own arrows (its `wants` runs before the window's shortcuts) and so do
	// the page's select/range controls (their element-scoped shortcuts sit in
	// the focus chain), which is the reference's `isArrowKeyEditableTarget`
	// rule. While a recorder waits for a key, the arrows do not navigate.
	if !a.recording && !a.customRecording {
		switch {
		case c.Shortcut(0, ui.KeyDown):
			a.stepPage(1)
		case c.Shortcut(0, ui.KeyUp):
			a.stepPage(-1)
		}
	}

	// A compact window toolbar keeps close/quit reachable without spending
	// the search field's taller editing band on a settings title.
	ui.Column(c).Fill().Children(func() {
		ui.Row(c).FillWidth().Height(max(40, t.Space(10))).Padding(0, t.Space(4)).
			Gap(t.Space(2.5)).AlignItems(ui.Center).Children(func() {
			ui.Text(c, copy.Title).FontSize(a.tokens(c).Emphasis).FontWeight(500).
				TextColor(a.tokens(c).TextStrong)
			if version := strings.TrimSpace(a.About.Version); version != "" {
				ui.Text(c, "v"+version).FontSize(t.FontSize).TextColor(t.TextMuted)
			}
			// The header's own two controls, at its end: the way out of the
			// application and the way back to the launcher, as the old panel's
			// `.settings-card__actions` carried them.
			ui.Box(c).Grow(1)
			// The header's own two controls, at its end: the way out of the
			// application and the way back to the launcher. They are the
			// reference's `.toolbar-button` — 28u transparent squares with a
			// 16u mark — never filled pills in the header band.
			headerButton := func(glyphName, label, hint string, run func()) {
				if run == nil {
					return
				}
				tokens := a.tokens(c)
				button := ui.Row(c).Focusable().Shrink(0).Size(max(36, t.Space(9)), max(36, t.Space(9))).
					Radius(tokens.RadiusSM).AlignItems(ui.Center).Justify(ui.Center).Label(label).
					Tooltip(hint)
				if label == copy.Close {
					button.Bind(noticeExit(c))
					// A returned keyboard focus shows this button's tooltip.
					// Escape still follows the settings priority above, before
					// that hint can consume the key meant for the way out.
					if button.Shortcut(0, ui.KeyEscape) {
						escape()
					}
				}
				if button.Pressed() {
					// P13-q（`docs/liquid-glass.md` §5）：`.toolbar-button` 的第三档。
					// 页头这两枚 28u 方格与启动器同尺寸的格同一触感。
					button.Background(tokens.ControlPress)
					button.Scale(0.92, 0.92)
					tokens.LitFace(button)
				} else if button.Hovered() {
					button.Background(tokens.ControlHover)
					// The header's icon button lights the resting rung under the
					// pointer (`.toolbar-button:hover`); it is transparent at rest,
					// like the reference's own. E1: one lit edge above and its
					// counter-side below, no ring (`theme.Tokens.LitFace`) — the
					// four-layer `Lens`'s ring was a second colour on the same edge.
					tokens.LitFace(button)
				}
				button.Children(func() {
					if glyph, ok := launcher.Glyph(glyphName); ok {
						ui.Icon(c, glyph).Size(t.Space(4), t.Space(4)).TextColor(t.TextMuted)
					}
				})
				if button.Clicked() {
					run()
				}
			}
			headerButton("power", copy.Quit, copy.QuitHint, a.Actions.Quit)
			headerButton("close", copy.Close, copy.CloseHint, a.Actions.Close)
		})
		// The header/body separator is the contract's one weak hairline
		// (`docs/raycast-design.md` §6.1): a 1px `HairlineSoft` rule, full width,
		// with no fade — the same line the card's rows draw between themselves.
		a.hairlineRule(c, false)
		// Let the shell’s glass run through both columns. Grow only into the
		// space left by the header, so the bottom of the page stays reachable.
		ui.Row(c).Grow(1).MinHeight(0).AlignItems(ui.Stretch).Gap(0).Children(func() {
			sidebarWidth := float32(152)
			for i := range pageCount {
				w, _ := c.MeasureText(0, ui.Span{Text: a.page(i).Title, Size: a.tokens(c).Body, Weight: 400})
				sidebarWidth = max(sidebarWidth, float32(math.Ceil(float64(w)))+sidebarGlyphSize+t.Space(13.5)+2)
			}
			ui.Column(c).Width(sidebarWidth).Padding(t.Space(4), t.Space(2.5)).Gap(t.Space(1.5)).
				Children(func() {
					// A click may change Page while rows are being built. Keep one
					// selection marker in this frame in either navigation direction.
					page := a.Page
					list := ui.List(c.Key("settings.sidebar"), &a.Sidebar, pageCount, func(i int) {
						a.sidebarRow(c, i, i == page)
					}).Grow(1).Label(copy.Title)
					// The entry-focus mark withholds the list's own ring: the chosen
					// pill already shows where the keyboard is, and the reference's
					// `data-entry-focus` kept `:focus-visible` off the sidebar until
					// the first interaction (R152). Once the keyboard leaves the
					// sidebar — a Tab, a click on a control — the mark goes and the
					// ring is the framework's again.
					list.FocusRing(!a.sidebarEntryFocus)
					switch {
					case a.sidebarEntryFocus && a.Sidebar.Focused(c):
						a.entryFocusArmed = true
					case a.entryFocusArmed:
						a.sidebarEntryFocus, a.entryFocusArmed = false, false
					}
				})
			// The sidebar's column separator is the same weak hairline, drawn
			// vertically (same rule, §6.1).
			a.hairlineRule(c, true)
			// No fixed paper colour behind the content or its grouped rows.
			ui.Column(c).Grow(1).Background(ui.Transparent).Children(func() {
				a.body(c, copy)
			})
		})
	})
}

// markDot is the size the two status discs (`●` / `○`) are drawn at, in the
// permission audit's trailing slot and on the integrations failure row.
//
// P13-dd：它是字阶账里的**具名例外**（`internal/ci/fontladder_contract_test.go`
// 的 `fontLadderExceptions`）。一枚盘不是一段文字：它没有字重、不换行、也不参与
// 任何行盒的比较，唯一的要求是**装得进它所在那一行的 caption 行盒**——所以在
// caption 下面两档。写成 `t.FontSize-3` 与写成这里没有区别，区别在于账能把它
// 和「一行字被写成了 body 的偏移量」分开：后者是这轮真正在修的东西。
func markDot(t *ui.Theme) float32 {
	return t.FontSize - 3
}

// permissionTier draws one tier of the permission audit: its label and the
// one-line explanation of what the tier means, then a row per permission.
//
// The row's own state is **one mark in the row's trailing slot** (P13-bn): a
// solid disc for a permission the host itself decides, a hollow ring for one
// the tool only declares. Nothing else in that slot — the two tiers are told
// apart by their heading above the card and by that one mark.
//
// 它此前是**两枚**：一枚 `alert` 警示环 + 一枚 `●`/`○`，两者都染同一个墨、同一个状态。
// 那枚环没有语义——`alert` 在 `internal/shell/notices.go:294-299` 的 `toastMark`
// 里是 `error` 的记号，而这一行说的是「这条权限属于哪一层」，不是「这里坏了」。
// 实测（520u 卡，行尾墨段）：`493..506`(14) 是那枚环、`514..521`(8) 是那枚盘，中间只隔
// **7 级像素**——读成一枚徽标的两个部件，而不是两件东西。删掉环之后行尾只有一段墨，
// 且它的左边界从 493 移到 514（行尾不再有第二个物体）。
func (a *App) permissionTier(c *ui.Context, label, hint string, enforced bool, language string, permissions []string) {
	if len(permissions) == 0 {
		return
	}
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	ui.Column(c).FillWidth().Gap(t.Space(1)).Children(func() {
		// P13-eh 重定基线：分组标题这一角色在本页有五个同族调用点，都是
		// `Caption + 620 + TextSecondary`（`rows.go` 的 `rowTitle` 与
		// `settingsui.go` 的四处小节标题）。这一处是**卡内**的子分组，
		// 却用了 `650 + TextStrong`——比它上面那张卡的标题（`Title + 620 +
		// TextStrong`）字重更重、墨也更高，于是层级是反的：子级比父级更响。
		// 旧值 → 新值：`650 / TextStrong` → `620 / TextSecondary`；父子关系
		// 改由**字号 + 墨**两级承担（Title 13.5 > Caption 9.9，Strong >
		// Secondary），字重不再逆序。
		ui.Text(c, label).FontSize(tokens.Caption).FontWeight(620).TextColor(tokens.TextSecondary)
		if hint != "" {
			ui.Text(c, hint).FontSize(tokens.Caption).TextColor(t.TextMuted)
		}
		a.card(c, func() {
			for _, permission := range permissions {
				permission := permission
				a.row(c, i18n.PermissionLabel(language, permission), i18n.PermissionDescription(language, permission), func() {
					mark := "\u25cb"
					if enforced {
						mark = "\u25cf"
					}
					color := t.TextMuted
					if enforced {
						// §5 注脚第 1 条：实心/空心即 ON/OFF，属「控件状态」那一类
						// accent 用途。
						color = t.Accent
					}
					ui.Text(c, mark).FontSize(markDot(t)).TextColor(color)
				})
			}
		})
	})
}

// mustGlyph is the shared glyph vocabulary with a hard failure: the names here
// are program constants, so a missing one is a bug rather than a runtime
// condition.
func mustGlyph(name string) *ui.SVG {
	glyph, ok := launcher.Glyph(name)
	if !ok {
		glyph, _ = launcher.Glyph("alert")
	}
	return glyph
}

// sidebarRow uses a regular body label and a neutral selected background.
func (a *App) sidebarRow(c *ui.Context, i int, selected bool) {
	t := c.Theme()
	tokens := a.tokens(c)
	row := ui.Row(c).FillWidth().MinHeight(max(40, t.Space(10))).
		Padding(0, t.Space(3)).Gap(t.Space(2.5)).
		Radius(tokens.RadiusSM).AlignItems(ui.Center).
		Transition(ui.ElementTransition{Colors: true, Duration: theme.ColorStep})
	if selected {
		// Clear the hover wash immediately: the moving marker is the only
		// selected background, including the frame after a click.
		row.Transition(ui.ElementTransition{Colors: true, Duration: -1})
	} else {
		if row.Pressed() {
			row.Background(tokens.RowPressed)
		} else if row.Hovered() {
			row.Background(tokens.RowHover)
		}
	}

	// The reference puts the row's ink on one of three rungs
	// (`settings.css:137,152-156,166-170`): `--text-muted` at rest,
	// `--text-primary` under the pointer, and `--text-primary` on the chosen
	// page. The old port kept the resting muted ink for hover too and used
	// `--text-strong` for the chosen page, so a pointed-at row never lit and
	// the current one was a hair dimmer than the reference's own.
	color := t.TextMuted
	// 按下与悬停同一档墨：第三档换的是**面**，不是墨（`row.Pressed()` 蕴含指针
	// 在这条行上，写出来是为了让这三档在源码里也是显式的）。
	if selected || row.Hovered() || row.Pressed() {
		color = t.Text
	}
	row.Children(func() {
		if selected {
			fill := tokens.RowSelected
			if row.Pressed() {
				fill = tokens.RowPressed
			}
			duration := 180 * time.Millisecond
			if !a.sidebarMotion {
				duration = -1
			}
			ui.Box(c.Key("settings.sidebar.selection")).Absolute().Top(0).Bottom(0).Left(0).Right(0).
				Radius(tokens.RadiusSM).Background(fill).PassThrough().ZIndex(-1).Bind(&a.sidebarMarker).
				Transition(ui.ElementTransition{Position: true, Duration: duration, Ease: sidebarEase, Match: sidebarSelection{a}})
		}
		if glyph, ok := pageGlyph(i); ok {
			// Keep navigation glyphs at a consistent optical size.
			icon := ui.Icon(c, glyph).Size(sidebarGlyphSize, sidebarGlyphSize).TextColor(color)
			if selected {
				icon.TextColor(t.Accent)
			}
		}
		ui.Text(c, a.page(i).Title).FontSize(tokens.Body).FontWeight(400).
			TextColor(color).Ellipsis("\u2026").SingleLine()
	})
	if row.Clicked() {
		// A click is the first interaction, so the entry-focus mark goes.
		a.sidebarEntryFocus, a.entryFocusArmed = false, false
		a.selectPage(i)
		a.sidebarMotion = true
	}
}

type sidebarSelection struct{ app *App }

var sidebarEase = ui.CubicBezier(0.23, 1, 0.32, 1)

// sidebarGlyphSize keeps the navigation marks legible at every scale.
const sidebarGlyphSize float32 = 18

// pageGlyph is the mark a settings page leads with: the exact lucide set the
// reference's sidebar named (`main:src/App.tsx:2903-2908`),
// `[general SlidersHorizontal, sessions SquareTerminal, shortcuts Keyboard,
// integrations Blocks, about Info]`, drawn through the launcher's shared
// vocabulary so a page and the thing it configures look alike. It is not the
// page's *content* glyph (a star for shortcuts, a file for integrations): the
// reference picks a shape per page, not the first mark to hand.
func pageGlyph(page int) (*ui.SVG, bool) {
	switch page {
	case PageGeneral:
		return launcher.Glyph("sliders-horizontal")
	case PageSessions:
		return launcher.Glyph("square-terminal")
	case PageShortcuts:
		return launcher.Glyph("keyboard")
	case PageIntegrations:
		return launcher.Glyph("blocks")
	case PageAbout:
		return launcher.Glyph("info")
	}
	return nil, false
}

// selectPage switches pages and remembers the choice, so the next visit to
// the settings surface reopens where the user left off.
func (a *App) selectPage(page int) {
	a.sidebarMotion = false
	if page != PageShortcuts {
		a.StopShortcutRecording()
	}
	// The page's own debounced controls are written before it leaves: a drag
	// that is still inside its window must not be lost with the page.
	a.flushSettingsWrites()
	// The reference's kill arm lived in the SessionsPage component: leaving
	// the page unmounted it, so the question never survived a visit
	// elsewhere. Drop it where the page changes hands.
	if page != PageSessions {
		a.disarmSessionClose()
	}
	// A page's scroll belongs to that page. The reference keys the page's own
	// scroller with the page (`main:src/App.tsx:2930`
	// `<main className="settings-content" ... key={settingsPage}>`;
	// `.settings-content` is the scroller, `main:src/styles/settings.css:233-244`),
	// so a page change remounts it at the top. This surface has one scroller
	// for all five pages (`ui.Scroll(c.Key("settings.body"))`), so the reset
	// has to be said here: without it a click from General scrolled halfway
	// opened Shortcuts with its heading already above the viewport. The same
	// page is the same key in the reference — re-clicking the page one is
	// reading leaves the offset alone.
	if page != a.Page {
		a.Body.Y = 0
		if a.Page == PageIntegrations {
			a.toolPageEpoch++
			a.copiedContent, a.copiedContentValue = "", ""
			a.copiedContentUntil = time.Time{}
		}
		if a.Page == PageAbout {
			a.copiedLink, a.copiedLinkUntil = "", time.Time{}
		}
	}
	a.Page = page
	if a.Actions.SetPage != nil {
		a.Actions.SetPage(PageName(page))
	}
}

// stepPage walks the sidebar by `delta`, wrapping around its order, and puts
// the keyboard back on the sidebar — the reference's `nextSettingsPage` plus
// its `settingsSidebarButtons.current.get(next)?.focus()`.
func (a *App) stepPage(delta int) {
	a.selectPage(nextPage(a.Page, delta))
	// An arrow is the first interaction, so the entry-focus mark goes too: the
	// ring is the keyboard's own from here.
	a.sidebarEntryFocus, a.entryFocusArmed = false, false
	a.Sidebar.Handle.Focus()
}

// nextPage is the page `delta` steps away in the sidebar order, wrapping at
// both ends (the reference's `nextSettingsPage` over `wrapIndex`).
func nextPage(page, delta int) int {
	n := pageCount
	return ((page+delta)%n + n) % n
}

// body uses one scrolling reading surface. Small windows keep their height
// for controls; the sidebar already names the page, so integrations needs no
// second title or explanatory banner above its navigation.
func (a *App) body(c *ui.Context, copy i18n.Settings) {
	t := c.Theme()
	var integrations []Integration
	if a.Page == PageIntegrations {
		integrations = a.installedIntegrations()
		a.syncIntegrationNavigation(integrations)
	}
	scrollTheme := *t
	scrollTheme.ScrollbarWidth = max(3, t.Space(1))
	ui.Themed(c, &scrollTheme).Background(ui.Transparent).Fill().MinWidth(0).Children(func() {
		scroll := ui.Scroll(c.Key("settings.body")).TrackScroll(&a.Body).Fill().MinHeight(0).
			KeepScrollbars(true).ScrollbarInsets(t.Space(2), t.Space(1.5), t.Space(2), 0).
			Padding(t.Space(4), t.Space(5), t.Space(5))
		scrollTheme = a.bodyScrollbar.theme(c, scroll, &a.Body)
		scroll.Children(func() {
			ui.Column(c).FillWidth().Gap(t.Space(4)).Children(func() {
				a.saveAlert(c, copy)
				if a.Page == PageIntegrations {
					a.integrationToolbar(c.Key("integrations.navigation"), copy)
				} else {
					ui.Text(c, a.page(a.Page).Title).FontSize(a.tokens(c).Emphasis).FontWeight(600).TextColor(t.Text)
				}
				pageContext := c.Key("settings.page-content").Key(a.settingsScrollKey())
				switch bodyPage(a.Page) {
				case PageGeneral:
					a.general(pageContext, copy)
				case PageSessions:
					a.sessions(pageContext, copy)
				case PageIntegrations:
					a.integrationContent(pageContext, copy, integrations)
				case PageShortcuts:
					a.shortcuts(pageContext, copy)
				case PageAbout:
					a.about(pageContext, copy)
				}
			})
		})
	})
}

// sessions lists the running terminal sessions.
//
// The list is the sessions page's own, not the terminal surface's: it is
// ordered along its own axis — newest first, the old page's default — and the
// heading carries that order as a control, so a hand can flip it. A session's
// program runs in this process, so there is no refresh to offer: what the list
// says is what the surface holds, at the frame it was drawn.
func (a *App) sessions(c *ui.Context, copy i18n.Settings) {
	t := c.Theme()
	sessions := a.sortedSessions()
	if len(sessions) == 0 {
		// The reference's shared empty region (`SessionsPage.tsx:142-167,
		// 218-244`): the mark, the state in one line and the grey why under
		// it, with the page-body floor (`.session-manager > .settings-empty`
		// is 160u, where the list placeholder is 92u). This build's session
		// list is in-process and synchronous, so only the resting arm of the
		// reference's three-way is reachable (see `sessionsEmptyFaceFor`); the
		// page's own New session control stays the way out.
		face := sessionsEmptyFaceFor(copy, false, false)
		a.emptyState(c, face.Icon, face.Title, face.Hint, 0, t.Space(40), true, func() {
			if a.Actions.NewSession != nil {
				if a.pageButton(c, copy.SessionsNew).Clicked() {
					a.Actions.NewSession()
				}
			}
		})
		return
	}
	// The order control shows the order in force and swaps it on press, as
	// the old page's `session-manager__sort-toggle` did — and it leads with
	// that control's own mark, lucide's ArrowUpDown at 13px
	// (`SessionsPage.tsx:123-125`), so the two directions the list can run in
	// are on the control itself.
	order := copy.SessionsSortNewest
	if a.sessionsSortOldest {
		order = copy.SessionsSortOldest
	}
	a.pageColumn(c, func() {
		// A question whose session is gone has nothing left to answer: the
		// reference's page re-rendered its list against the broker each poll,
		// so a killed/ended session's row took its arm with it. Here the list
		// is this frame's, so an arm that names no row is dropped before it is
		// handed to another one (see sessionInList).
		if a.armedSession != 0 && !sessionInList(sessions, a.armedSession) {
			a.disarmSessionClose()
		}
		a.sectionWithControls(c, copy.PageSessions, copy.SessionsActive, func() {
			a.actionWithGlyph(c, "arrow-up-down", order, func() {
				a.sessionsSortOldest = !a.sessionsSortOldest
			})
		}, func() {
			a.card(c, func() {
				for _, session := range sessions {
					session := session
					// The old page's own row was the resume control: its
					// `onActivate` was wired only for a *resumable* session
					// — `resumable = !session.exited && !session.attached`
					// (`SessionsPage.tsx:170,197`) — so pressing anywhere on
					// a session that is running behind the one on screen
					// brings it back, while the Play button beside it is
					// the same action's explicit form. An exited session and
					// the one already on screen answer nothing.
					resumable := session.Running && !session.Active
					// The row says what the session is doing — attached (on
					// screen), running behind the one that is, or how the
					// program went — and, under it, where the shell is and
					// when the session started. Its leading mark is the
					// reference's own `.settings-row__icon` chip with lucide's
					// SquareTerminal (`SessionsPage.tsx:186-187`), which is the
					// shared settings-row slot and not the extension panel's
					// package chip.
					// P13-ea：这一行穿的是参考自己那条 56px 地板（见 sessionRowFloorPx），
					// 不是设置卡的 44 —— 两行字加一条脚注的行比一行字需要更多空气，
					// 且那 5.6px 全落在状态行下方。
					activated := a.rowValue(c, ui.Center, func() { a.sessionChip(c) }, rowFace{Floor: sessionRowFloorPx, Inert: !resumable || a.Actions.SelectSession == nil},
						session.Title, sessionLines(session), "", func() {
							// The trailing controls are the reference's two 28u icon
							// buttons (`SessionsPage.tsx:203-232`): Play (disabled once
							// the session has exited, while it is on screen, or while
							// another row's action runs) and Trash2 (disabled for the
							// same busy window). They sit in a 3u-gap row
							// (`.session-manager__actions { gap: 3u }`, `:1333-1336`).
							ui.Row(c).Gap(t.Space(0.75)).AlignItems(ui.Center).Children(func() {
								// The reference disables a row's controls while *another*
								// row's action is in flight (`actionId !== null`,
								// `SessionsPage.tsx:204,226`), and this build's arm is
								// the one such state a session has.
								// The reference's own reservations for the two controls
								// (`SessionsPage.tsx:204-206,226`): the Play button is
								// disabled on an *exited* session (`disabled={session.exited
								// || busy || actionId !== null}`), and the bin is disabled
								// only while this build has an action in flight — which it
								// never does, since a resume and a close both call straight
								// through to the shell. Its accent resume dot marks the
								// running-but-detached row it is *for* (`:203`).
								if a.Actions.SelectSession != nil {
									a.sessionIconButton(c, "play", copy.SessionsResume,
										false, resumable, !session.Running,
										func() { a.Actions.SelectSession(session.Index) })
								}
								if a.Actions.CloseSessionAt == nil {
									return
								}
								// Closing a session kills its program, so the control
								// arms first — the reference's two-step in place, where
								// the icon button *expands into* the warm question pill
								// rather than drawing a second row of buttons
								// (`SessionsPage.tsx:216-229`).
								if a.armedSession == session.ID {
									a.sessionKillConfirm(c, copy.SessionsKillArm, false, func() {
										a.disarmSessionClose()
										a.Actions.CloseSessionAt(session.Index)
									})
									return
								}
								a.sessionIconButton(c, "trash", copy.SessionsKill,
									true, false, false, func() { a.armSessionClose(session.ID) })
							})
						})
					if activated && resumable && a.Actions.SelectSession != nil {
						a.Actions.SelectSession(session.Index)
					}
				}
			})
		})
		if a.Actions.NewSession != nil {
			if a.pageButton(c, copy.SessionsNew).Clicked() {
				a.Actions.NewSession()
			}
		}
	})
}

// sortedSessions is the session list in the order the page's control asks for:
// newest first by default, oldest first once the user has flipped it. The sort
// is stable, so sessions with no recorded start (a test's fixtures) keep the
// order the shell handed over.
func (a *App) sortedSessions() []Session {
	sessions := a.runningSessions()
	if len(sessions) < 2 {
		return sessions
	}
	out := append([]Session(nil), sessions...)
	sort.SliceStable(out, func(i, j int) bool {
		if a.sessionsSortOldest {
			return out[i].Created.Before(out[j].Created)
		}
		return out[i].Created.After(out[j].Created)
	})
	return out
}

// sessionLines is the row's grey block: the shell's working directory (when
// it reported one) above the state line, the screen size and the start time —
// the old page's `.session-manager__cwd` and its `.session-manager__meta`
// line. The state word is a segment of its own so it can carry its colour:
// the accent while the session runs, the quiet grey once it has exited, as
// `.session-state` and `.session-state--exited` did. The directory is marked
// `Mono`, because the reference draws it in its monospace stack — a path is a
// value, `settings.css:1272-1276`.
func sessionLines(session Session) []rowLine {
	var lines []rowLine
	if session.Dir != "" {
		lines = append(lines, rowLine{Text: session.Dir, Mono: true})
	}
	if meta := sessionMeta(session); len(meta) > 0 {
		lines = append(lines, rowLine{Segments: meta})
	}
	return lines
}

// sessionMeta is the meta line's segments — the state word, the screen size
// and the start time — each its own segment so the state word can take a
// brighter ink while the session runs and the quiet grey once it has exited. It
// is empty when the session reported none of the three.
func sessionMeta(session Session) []rowSegment {
	var segments []rowSegment
	if session.Note != "" {
		// P13-cm: three rungs, not two. A running session's state is the strong
		// neutral (P8-d), an ended one joins the quiet grey, and an ended one
		// that *failed* wears the warning hue — the same hue the terminal
		// surface's resident note has used for `ExitCode != 0` since before this
		// page had an arm for it. Running wins over failed: a program that is
		// still running has no ending to colour.
		role := rowSegmentTertiary
		switch {
		case session.Running:
			role = rowSegmentStrong
		case session.Failed:
			role = rowSegmentWarning
		}
		segments = append(segments, rowSegment{Text: session.Note, Role: role})
	}
	if session.Size != "" {
		segments = append(segments, rowSegment{Text: session.Size, Role: rowSegmentTertiary})
	}
	if !session.Created.IsZero() {
		segments = append(segments, rowSegment{
			Text: session.Created.Local().Format("2006-01-02 15:04"),
			Role: rowSegmentTertiary,
		})
	}
	return segments
}

// integrations lists the installed extensions, each with its state and a
// switch. An orphan package directory is listed too, with the two operations
// it can take.
// basePlugin is one built-in plugin as the Integrations page lists it: its id
// (the same vocabulary the launcher's gear and the plugin configuration use),
// what it is called and does, the extra privacy line the clipboard carries,
// and whether it has a persisted on/off switch at all.
type basePlugin struct {
	ID         string
	Name       string
	Hint       string
	Privacy    string
	Toggleable bool
	Enabled    bool
}

// basePlugins is the shipped list, in the order the old panel listed it. The
// calculator has no persisted on/off field, so it carries no switch rather
// than a dead one.
func (a *App) basePlugins(copy i18n.Settings) []basePlugin {
	s := a.settings()
	return []basePlugin{
		{
			ID: settings.CustomPluginClipboard, Name: copy.BaseClipboard, Hint: copy.BaseClipboardHint,
			Privacy: copy.BaseClipboardPrivacy, Toggleable: true, Enabled: settings.ClipboardOf(s).Enabled,
		},
		{
			ID: settings.CustomPluginBrowser, Name: copy.BaseBrowser, Hint: copy.BaseBrowserHint,
			Toggleable: true, Enabled: settings.BrowserPluginOf(s).Enabled,
		},
		{ID: settings.CustomPluginCalculator, Name: copy.BaseCalculator, Hint: copy.BaseCalculatorHint},
	}
}

// basePluginSection is the Integrations page's own list of the built-in
// plugins: one card per plugin, naming it, saying what it does, and carrying
// the two controls it can have — the switch that turns it on or off, and the
// Configure button that opens its declarative configuration in the launcher
// (the mode's own gear opens the same sheet). The browser mode's message
// ("Enable it in Settings > Integrations") is this section; without it the
// hint would point at a door that does not exist.
func (a *App) basePluginSection(c *ui.Context, copy i18n.Settings) {
	if a.Actions.OpenPluginConfig == nil && a.Actions.SetPluginEnabled == nil {
		return
	}
	plugins := a.basePlugins(copy)
	a.extensionSection(c, copy.BasePlugins, len(plugins), func() {
		a.extensionHint(c, copy.BasePluginsHint)
		for _, plugin := range plugins {
			plugin := plugin
			a.card(c, func() { a.basePluginCard(c, copy, plugin) })
		}
	})
}

// basePluginCard is one built-in plugin's own card — the reference's
// `.extensions-base-plugin` (`extensions.css:2550-2563`): a 66px **floor**, a
// 16px gap between its two columns, a `12px 14px` padding pair, the panel's
// `--ext-border` hairline and the card ladder's `--radius-md` on the
// `--glass-control` plane (the face `card` already paints, which is why this
// draws the reference's *interior* and not a card of its own).
//
// The interior is the reference's two columns, aligned to the top rather than
// centred (`align-items: flex-start`):
//
//	.extensions-base-plugin__main  name, description, optional privacy note,
//	                               a `flex column` with a 3px gap
//	.extensions-base-plugin__actions  the Configure pill (24px, emphasis
//	                               step) and the switch — never the row's own
//	                               trailing slot (`cardRow`'s 44u floor and
//	                               8px gap are the settings card's, not this
//	                               card's)
//
// The three text lines are the reference's own registers: the name is the
// **title** step (13px) at line-height 1.5 with no weight of its own, the
// description the **emphasis** step (12px) at 1.5 in `--text-secondary`, and
// the privacy note the **body** step (11px) in `--text-warning` with a 2px top
// padding — `.settings-privacy-hint`'s ink, worn by the one row that discloses
// rather than describes. The port had flattened all three into one settings
// row: the name at the emphasis step, the description one register too quiet
// (`--text-muted`) and single-line, the note weight-500 with no padding.
func (a *App) basePluginCard(c *ui.Context, copy i18n.Settings, plugin basePlugin) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	enabled, changed := plugin.Enabled, false
	labelClicked := false
	// `min-height: 66px` (`--extensions-row-height` is 66) at the extension
	// panel's literal unit, with the card's own `align-items: flex-start`.
	// The floor is what the reference's own note buys (`extensions.css:2540-2549`):
	// the card's arithmetic — two 12px paddings, two 1px borders, a 19.5px name
	// line, a 3px gap and one 18px description line — lands on ~66.5px, so a
	// plugin whose description is short (or absent) must not draw a card
	// shorter than the one that carries it. Without the floor the calculator's
	// one-line card settled ~3px under the clipboard's three-line card, and the
	// column of cards lost its shared edge.
	// 66px is a `border-box` floor in the reference (base.css's `*` reset), so
	// the two 1px borders are *inside* it: the row's own floor is the 64px
	// interior. `MinHeight(Space(16))` is 64 at the panel's literal unit.
	row := ui.Row(c).FillWidth().Gap(t.Space(4)).MinHeight(t.Space(16)).
		AlignItems(ui.Start).Padding(t.Space(3), t.Space(1))
	row.Children(func() {
		// The copy column: `min-width: 0`, a `flex column` with the
		// reference's 3px gap. Its name and description wrap, as the
		// reference's do (no `nowrap` here, unlike a settings row's sublabel).
		main := ui.Column(c).Grow(1).MinWidth(0).Gap(t.Space(0.75))
		main.Children(func() {
			ui.Text(c, plugin.Name).FontSize(tokens.Body).FontWeight(500).LineHeight(1.5).
				TextColor(tokens.TextStrong)
			if plugin.Hint != "" {
				ui.Text(c, plugin.Hint).FontSize(tokens.Caption).FontWeight(400).LineHeight(1.5).
					TextColor(tokens.TextSecondary).Wrap()
			}
			if plugin.Privacy != "" {
				// `.extensions-base-plugin__privacy` + `.settings-privacy-hint`:
				// the body step in the warning ink, its own `2px 2px 0` padding.
				ui.Text(c, plugin.Privacy).FontSize(tokens.Caption).FontWeight(400).
					Padding(t.Space(0.5), t.Space(0.5), 0, t.Space(0.5)).
					TextColor(t.Warning).Wrap()
			}
		})
		if main.Clicked() {
			labelClicked = true
		}
		// The controls column: `flex: 0 0 auto`, centred, the reference's 10px
		// gap. The switch takes the reference's 2px optical nudge off the
		// card's top edge.
		actions := ui.Row(c).Shrink(0).Gap(t.Space(2.5)).AlignItems(ui.Center)
		actions.Children(func() {
			if a.Actions.OpenPluginConfig != nil {
				// The visible text is the reference's "Configure"; the
				// accessible name names the plugin, because three buttons
				// reading "Configure" alone are three buttons a screen
				// reader cannot tell apart. It is the card's own
				// one-step-down pill
				// (`.extensions-base-plugin__configure`,
				// `extensions.css:2610-2614`): a 24u height and the
				// emphasis step, so it never out-shouts the plugin name
				// beside it.
				configure := a.extensionActionButton(c, copy.PluginConfigure,
					t.Space(9), tokens.RadiusSM, tokens.Body)
				configure.Label(copy.PluginConfigure + " " + plugin.Name)
				if configure.Clicked() {
					a.Actions.OpenPluginConfig(plugin.ID)
				}
			}
			if plugin.Toggleable && a.Actions.SetPluginEnabled != nil {
				on := enabled
				sw := a.switchControl(c, &on).Label(plugin.Name).Margin(t.Space(0.5), 0, 0, 0)
				if sw.Changed() {
					enabled, changed = on, true
				}
			}
		})
	})
	// The name is a hit target, as every switch row's is: pressing the words
	// toggles the control beside them. The reference wires only the switch
	// itself; the wider target is this build's own addition.
	if labelClicked && plugin.Toggleable && a.Actions.SetPluginEnabled != nil {
		enabled, changed = !enabled, true
	}
	if changed {
		a.observeSettingsWrite(func() { a.Actions.SetPluginEnabled(plugin.ID, enabled) })
	}
}

// RecommendedTool is one shipped package, as the page lists it.
type RecommendedTool struct {
	ID          string
	Name        string
	Description string
	// Installed is true when the inventory already has it.
	Installed bool
}

// recommendedRow lists the shipped tool packages that are not installed yet,
// each with the one press that installs it. Nothing is shown once everything
// shipped is installed.
func (a *App) recommendedRow(c *ui.Context, copy i18n.Settings) {
	if a.Actions.ConnectRecommended == nil || a.Recommended == nil {
		return
	}
	var pending []RecommendedTool
	for _, tool := range a.Recommended() {
		if !tool.Installed {
			pending = append(pending, tool)
		}
	}
	if len(pending) == 0 {
		return
	}
	a.integrationLead += "recommended:"
	for _, tool := range pending {
		a.integrationLead += strconv.Quote(tool.Name) + strconv.Quote(tool.Description)
	}
	a.section(c, copy.IntegrationsRecommended, copy.IntegrationsRecommendedHint, func() {
		a.card(c, func() {
			for _, tool := range pending {
				tool := tool
				a.row(c, tool.Name, tool.Description, func() {
					if a.packageInstallBusy["recommended:"+tool.ID] {
						a.busyActionButton(c, copy.IntegrationsConnect, "install.recommended."+tool.ID)
					} else if a.actionButton(c, copy.IntegrationsConnect).Clicked() {
						a.Actions.ConnectRecommended(tool.ID)
					}
				})
			}
		})
	})
}

// transferRow is the export and import of the whole list: a backup of what is
// installed and how it is configured, and the way back in on another machine.
//
// The reference's panel (`src/ExtensionsPanel.tsx:1206-1240,2300-2350`) puts
// the pair behind one overflow menu, disables them while a transfer is in
// flight, shows that transfer's busy line beside them, and renders the last
// import's report under the row. This build keeps the two buttons in the row
// (its one authoring row) but follows the same three states: disabled while
// busy, one busy line, and the report block below.
func (a *App) transferRow(c *ui.Context, copy i18n.Settings) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	busy := a.TransferBusy != ""
	ui.Row(c).FillWidth().Gap(t.Space(1)).AlignItems(ui.Center).
		Padding(0, 0, t.Space(1), 0).Children(func() {
		if a.Actions.ExportIntegrations != nil {
			var button ui.Element
			if busy {
				// P13-ba: a locked pill must not wear the lit edge that says it can
				// be pressed; the face picks its material while it draws.
				button = a.disabledActionButton(c, copy.IntegrationsExport)
			} else {
				button = a.actionButton(c, copy.IntegrationsExport)
			}
			if button.Clicked() {
				a.TransferReport = nil
				a.Actions.ExportIntegrations()
			}
		}
		if a.Actions.ImportIntegrations != nil {
			var button ui.Element
			if busy {
				button = a.disabledActionButton(c, copy.IntegrationsImport)
			} else {
				button = a.actionButton(c, copy.IntegrationsImport)
			}
			if button.Clicked() {
				a.TransferReport = nil
				a.Actions.ImportIntegrations()
			}
		}
		switch a.TransferBusy {
		case "export":
			busyLine(c, copy.IntegrationsExporting, tokens)
		case "import":
			busyLine(c, copy.IntegrationsImporting, tokens)
		}
	})
	if a.TransferReport != nil {
		a.transferReport(c, copy)
	}
}

// busyLine is the transfer row's one in-flight word: which of the two
// buttons is running, said beside them while both are locked.
//
// P13-ff（`docs/liquid-glass.md` §6.127）：这一句话此前穿的是这一页**静止帮助句**
// 的墨（`t.TextMuted`，与卡上方那句 “Integrations are command-line tools floter
// discovers and runs in the terminal.” 逐像素同档：实测浅色 116 / 权重 120，深色
// 160 / 133，深浅两套都是**相等**）。于是一整页里唯一会变的那句话，读起来与一条
// 永远不变的说明句一模一样——而它旁边那两枚胶囊此刻已经熄灯（P13-aq 的禁用面，
// 墨权重 104），这一行唯一的信号源却是全行最安静的字。
//
// 本仓对「在飞的词」已经有两条规矩，这一处是唯一没跟上的：
//
//   - 启动器的翻页页脚（`launcher/output.go` 的 `footerWord`）：在飞用
//     `TextSecondary` 与 500，静止用 `TextMuted` 且不带字重——**在飞比静止重一档**；
//   - 设置页的配置工具条（`config.go` 的 `configToolbar`，P13-el）：在飞与落地
//     **同档**（`TextTertiary`），因为它有一枚落地后的孪生词（"Saved"），换词不换墨。
//
// 这一句没有孪生词——导出结束它整句消失，页面上留下的是另一块报告或什么都没有，
// 所以它走**第一条**：在飞的词抬到 `TextSecondary` + 500，比它脚下的帮助句重一档。
// 字号、盒、位置一个字节不动（仍是 `tokens.Caption`，仍居中于两枚胶囊的中线）。
func busyLine(c *ui.Context, word string, tokens theme.Tokens) {
	ui.Text(c, word).FontSize(tokens.Caption).FontWeight(500).TextColor(tokens.TextSecondary)
}

// installRow is the npm install field: a package name, an optional version,
// and the button that asks the shell to install it.
func (a *App) installRow(c *ui.Context, copy i18n.Settings) {
	if a.Actions.InstallFromRegistry == nil {
		return
	}
	t := a.cardTheme(c)
	name, version := a.installName, a.installVersion
	requested := false
	ui.Row(c).FillWidth().Gap(t.Space(1)).AlignItems(ui.Center).
		Padding(0, 0, t.Space(1), 0).Children(func() {
		var field ui.Element
		ui.Column(c).Grow(1).MinWidth(0).Children(func() {
			a.formFeedbackOutlet(c.Key("registry-name-outlet"), a.integrationLead, func() {
				field = a.textInput(c, &name).Placeholder(copy.IntegrationsPackageHint).Label(copy.IntegrationsPackageHint).FillWidth()
			}, func() bool { return field.FocusVisible() })
		})
		a.formFeedbackOutlet(c.Key("registry-version-outlet"), a.integrationLead, func() {
			a.textInput(c, &version).Placeholder(copy.IntegrationsVersionHint).Label(copy.IntegrationsVersionHint).Width(160)
		})
		var install ui.Element
		a.formFeedbackOutlet(c.Key("registry-submit-outlet"), a.integrationLead, func() {
			switch {
			case a.packageInstallBusy["registry"]:
				a.restoreNotice(c, "registry-install", "install", false, field)
				install = a.busyActionButton(c, copy.IntegrationsInstall, "install.registry")
			case strings.TrimSpace(name) == "":
				install = a.disabledActionButton(c, copy.IntegrationsInstall)
			default:
				install = a.actionButton(c, copy.IntegrationsInstall)
				a.rememberOperationFocus(c, "registry-install", "install", install)
			}
		}, func() bool { return install.FocusVisible() })
		if install.Clicked() {
			requested = true
		}
	})
	if name != a.installName || version != a.installVersion {
		a.installRevision++
	}
	a.installName, a.installVersion = name, version
	if requested && strings.TrimSpace(name) != "" {
		a.Actions.InstallFromRegistry(strings.TrimSpace(name), strings.TrimSpace(version))
		a.installName, a.installVersion = "", ""
		a.Body.Y = 0
	}
}

// BeginRegistryInstall runs synchronously in the submit event, so the current
// frame sees the busy state. Completion redraws after all host work settles.
func (a *App) BeginRegistryInstall() bool {
	if a.packageInstallBusy["registry"] {
		return false
	}
	if a.packageInstallBusy == nil {
		a.packageInstallBusy = map[string]bool{}
	}
	a.packageInstallBusy["registry"] = true
	return true
}

// RegistryInstallRecovery returns this request's failure outlet. Submission
// still clears the fields; later typing (even typing then clearing) owns a new
// draft that an older result must never replace. Call on the UI thread.
func (a *App) RegistryInstallRecovery(name, version string) func() {
	revision := a.installRevision
	if strings.TrimSpace(a.installName) == name && strings.TrimSpace(a.installVersion) == version {
		name, version = a.installName, a.installVersion
	}
	return func() {
		if a.installRevision == revision && a.installName == "" && a.installVersion == "" {
			a.installName, a.installVersion = name, version
		}
	}
}

// Detail metadata uses the same semantic status as the overview.
func (a *App) stateMark(c *ui.Context, integration Integration, copy i18n.Settings, lead bool) {
	if lead {
		ui.Text(c, "·").FontSize(a.tokens(c).Caption).TextColor(a.tokens(c).TextTertiary)
	}
	a.integrationStatus(c, copy, integration)
}

// runtimeUnavailableBadge is the reference's `.extension-status--broken`
// chip in the meta line (`src/extensions/ExtensionRow.tsx:258-272`): a warm
// chip with the warning keyline, reading "Tool unavailable" (or its
// localisation), with the specific cause beside it only when the list knows
// one. It is a state mark, not an action — the row's repair button (drawn
// separately) is the action, and this chip only says why the button is there.
//
// Its face is `stateMark`'s broken chip: the warm system plane
// (`tokens.RaisedWarm`) fill under the `ControlEdge` hairline at the
// `--ext-radius` corner — the same three facts the reference's one
// `.extension-status--broken` rule carried for both readers, minus the coloured
// ring the contract does not allow outside §5's three places (§6.1 第 8 条).
func (a *App) runtimeUnavailableBadge(c *ui.Context, copy i18n.Settings, integration Integration) ui.Element {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	label := copy.RuntimeUnavailable
	if code := integration.FailureCode; code != "" {
		if cause := copy.ErrorCodeLabel(code); cause != "" && cause != code {
			label += " · " + cause
		}
	}
	chip := ui.Row(c).Padding(t.Space(0.5), t.Space(1.5)).Radius(tokens.RadiusSM).
		Background(tokens.RaisedWarm)
	chip.InsetShadow(0, 0, 0, 1, tokens.ControlEdge)
	chip.Children(func() {
		ui.Text(c, label).FontSize(tokens.Caption).FontWeight(600).TextColor(t.Warning)
	})
	return chip
}

// integrationMeta is the reference's single `.extension-row__meta` line under
// the title (`src/extensions/ExtensionRow.tsx:255-282`): the package identity,
// the integration kind, the runtime source and the state word, in the caption
// register the reference drew them. The three plain facts share the tertiary
// ink and a `·` separator; the state word keeps its own colour (accent while
// running, a warm chip while broken, secondary while off) through stateMark,
// which is why it is a separate node rather than one joined string.
func (a *App) integrationMeta(c *ui.Context, copy i18n.Settings, integration Integration) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	facts := make([]string, 0, 3)
	if id := integration.identity(); id != "" {
		facts = append(facts, id)
	}
	if kind := integration.integrationKind(copy); kind != "" {
		facts = append(facts, kind)
	}
	if source := integration.runtimeSourceLabel(copy); source != "" {
		facts = append(facts, source)
	}
	ui.Row(c).FillWidth().Wrap().GapX(t.Space(2)).GapY(t.Space(1)).AlignItems(ui.Center).Children(func() {
		for i, fact := range facts {
			a.metaFact(c, tokens, fact, i > 0)
		}
		// The state word closes the line the same way: `·` in front of it unless
		// it is a *boxed* chip, which is its own separator.
		a.stateMark(c, integration, copy, len(facts) > 0)
	})
}

// metaFact draws one meta fact, with the `·` that introduces it inside the
// same text node.
//
// The reference writes the separator as the fact span's own `::before`
// (`main:src/styles/extensions.css:979-984`: `content: "·"`, `margin-right:
// 6px`, `opacity: .7`), so a line that has to wrap carries the dot *ahead* of
// the fact it introduces. Drawn as a flex child of its own, the dot stays on
// the line where it still fits and the fact moves to the next one: the line
// then ends in an orphan `·` with nothing after it. Measured at 460u — where
// this meta column is 187u wide and each fact takes a line of its own — all
// three dots sat at line ends and every line began with a bare fact.
//
// P13-cs（§6.62）：dot 的墨是**事实自己那一档**（`TextTertiary`），不再乘一把 0.7。
// 参考的 `.7` 是 CSS 里叠在一条不透明的墨上的乘法；本仓把同一个数接在半透明的 token
// 上时，一次乘法变成了两次（token 的 alpha × 0.7），实测这枚点只到档位的 0.55–0.63，
// 而且每换一张地面就换一个高度（地面 253 上 70 级、面板面 229 上 48 级、深色 39 上 40 级
// —— 与 `HairlineSoft` 同级）。比它引入的事实更轻这件事仍然成立：`TextTertiary` 就是
// 阶梅的最后一档，而事实自己已经落在那里。
//
// The pair rides one text
// node instead of a nested `ui.Row` because a nested unit is measured against
// the line's *remaining* width here: with the dot in a row of its own, a 90u
// fact at 460u got 82u and wrapped into two lines — a worse trade than
// anything the dot costs.
func (a *App) metaFact(c *ui.Context, tokens theme.Tokens, fact string, lead bool) {
	spans := make([]ui.Span, 0, 2)
	if lead {
		spans = append(spans, ui.Span{Text: "· ", Color: tokens.TextTertiary})
	}
	spans = append(spans, ui.Span{Text: fact, Weight: 500, Color: tokens.TextTertiary})
	ui.RichText(c, spans...).FontSize(tokens.Caption)
}

// healthDetail draws the stored probe report's own lines under the Health row
// (the old build's `extension-health` block): every probe the last run
// recorded with its duration, then the failed ones with the reason a retry
// decision needs, then when the run happened. The status word above stays
// the row's value; these lines are its detail.
func (a *App) healthDetail(c *ui.Context, copy i18n.Settings, report *HealthReport) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	// The block the reference draws under the Health row is a column with an
	// 8u gap (`ExtensionsPanel.tsx:2920-2972`, `extensions.css:2182`), and
	// each of its groups opens with the reference's own `__label`: a caption
	// at 620 on the secondary ink, one voice with the block labels around it
	// (`extensions.css:2191`) — never a ruled card row with a 44u floor and a
	// separator. The port drew each group that way, so the checks read as
	// four unrelated settings rows instead of one block's list.
	//
	// The reference's `capabilities` half (its `Features` / `Limitations`
	// groups) is deliberately not drawn: the original never populated it (its
	// reprobe path passed `Default::default()`, `probe_executor.rs:18`), so
	// both groups are dead on both sides — see the note in
	// `internal/extensions/helpderive.go`. Its own empty state is the same
	// dead end: the port sets `Health` and `HealthReport` together.
	// P13-cw（`docs/liquid-glass.md` §6.66）：这一列此前没有水平内缩——整块（Checks / Failures /
	// 时间戳 / 失败卡 / 探针的时长）从卡面的第一像素开始，比卡上每一个行标签左 8px，右端
	// 一路贴到卡框（实测 720×1700：行标签 x=200，块 x=192，时长右端 x=701）。参考的
	// `.extension-health` 住在 `.extension-detail-block` 里，和它自己的 `h4` 同一个 padding
	// （`floter-main:src/styles/extensions.css:1997-2002`），本仓那个 `h4` 就是 `Health` 行，
	// 所以块必须进 `rowInset` 那一列（P11-bf 给其它块修过的同一个 bug）。
	// 只加水平内缩：纵向节奏（组间 8u、组内 4u、探针行 4u padding）一个像素都不动。
	block := ui.Column(c).FillWidth().Gap(t.Space(2)).Padding(0, a.rowInset(t))
	block.Children(func() {
		if len(report.Probes) > 0 {
			// The checks group keeps the reference's own label and then one
			// probe line each — mark, monospace id, trailing duration.
			//
			// P13-cv: the rows are separated by a 1px hairline *between* them
			// and never closed by one — the same list punctuation the
			// diagnostics grid below uses (`diagnosisCheckRow`). Drawn on the
			// row's own bottom edge it hugged its own text (3px) and stood 8px
			// off the next one, and the last row left a rule with nothing
			// under it (`docs/rounds/P13-cv-report.md`).
			ui.Column(c).FillWidth().Gap(t.Space(1)).Children(func() {
				ui.Text(c, copy.IntegrationsHealthChecks).FontSize(tokens.Caption).
					FontWeight(620).TextColor(tokens.TextSecondary)
				for i, probe := range report.Probes {
					probe := probe
					a.healthProbeRow(c, probe)
					if i < len(report.Probes)-1 {
						ui.Box(c).FillWidth().Height(1).Background(tokens.Hairline).Shrink(0)
					}
				}
			})
		}
		var failed []HealthProbe
		for _, probe := range report.Probes {
			if !probe.Passed {
				failed = append(failed, probe)
			}
		}
		if len(failed) > 0 {
			ui.Column(c).FillWidth().Gap(t.Space(1)).Children(func() {
				ui.Text(c, copy.IntegrationsHealthFailures).FontSize(tokens.Caption).
					FontWeight(620).TextColor(tokens.TextSecondary)
				for _, probe := range failed {
					probe := probe
					a.healthFailureCard(c, copy, probe)
				}
			})
		}
		if when := healthCheckedAt(report.CheckedAt); when != "" {
			ui.Text(c, copy.IntegrationsHealthCheckedAt(when)).FontSize(tokens.Caption).
				TextColor(t.TextMuted).Wrap()
		}
	})
}

// diagnosticsSection draws the drawer's Diagnostics block at the reference's
// own face (`main:src/ExtensionsPanel.tsx:2892-2902`,
// `main:src/styles/extensions.css:2207-2210,2324-2350`): a block label, the
// verdict word as a summary line, then one grid row per check — the check's
// own status word in a fixed 54px column and its message in the rest, each
// row closed by a 1px hairline. What it replaces was the whole check reduced
// to one ruled card row whose grey subline carried the summary and whose
// trailing slot carried the integration's own state word (a third fact that
// had nothing to do with the check).
//
// P11-be: on the settings card the block is a **row of that card**, so it wears
// the card's frame (`cardRow`): the separator above it, the row's floor and the
// row's inset, with the label and everything under it drawn in the card's label
// column. Drawn as a bare `ui.Row` it had none of the three — its label sat
// flush against the permission pills of the row above (reading as their
// caption) and its check grid started at the card's own edge, one whole inset
// left of every label above it (`docs/rounds/P11-be-spec.md` §1.2). The label's
// own step is unchanged: it is still the drawer's `.extension-detail-block h4`
// (caption 620 at the secondary ink), which `TestTheDiagnosticsBlockLabelIsTheBlocksOwnStep`
// pins — a card row's emphasis step is *not* what a block label wears.
func (a *App) diagnosticsSection(c *ui.Context, copy i18n.Settings, integration Integration) {
	tokens := a.tokens(c)
	t := a.cardTheme(c)
	a.cardRow(c, ui.Start, nil, rowFace{Inert: true}, func() {}, func() {
		// The block label: the drawer's `.extension-detail-block h4` — sentence case
		// at the secondary ink, caption 620 (`extensions.css:2008-2013`), one voice
		// with the metadata grid's own `dt` labels.
		ui.Text(c, copy.IntegrationsDiagnostics).FontSize(tokens.Caption).FontWeight(620).
			TextColor(tokens.TextSecondary)
		if !integration.diagnosisRan() {
			// No check ran at all (the provider answered with nothing): the
			// reference's own empty line (`extensions.css:2054-2059`,
			// `--text-muted` body). A check that ran but reported no rows is *not*
			// this state — its verdict is the summary line on its own.
			ui.Text(c, copy.IntegrationsDiagnosticsUnavailable).FontSize(t.FontSize).
				TextColor(t.TextMuted).Wrap()
			return
		}
		// The verdict is the reference's plain summary span: `justify-self: start`,
		// a `2px 0` padding pair, no pane, no dot and **no weight of its own** —
		// the rule sets colour and `capitalize` alone, and the caption step
		// inherits the body's 400 (`extensions.css:2324-2332`). The port drew it
		// at 620, one step heavier than the reference's own summary. Its colour
		// follows the *status word it prints*, the same classification the check
		// rows below use (the reference ranged `--${diagnose.status}` over both,
		// `ExtensionsPanel.tsx:2896-2899`), so a verdict the finding flag does not
		// cover still wears its own state's ink.
		verdict := diagnosisVerdict(integration, copy)
		ink := statusInk(verdict, tokens, t, tokens.TextSecondary)
		if integration.DiagnosisFailed {
			ink = t.Warning
		}
		ui.Text(c, capitalizeWord(verdict)).FontSize(tokens.Caption).
			TextColor(ink)
		// One row per check: the reference's `.extension-diagnostics > div` is a
		// `54px minmax(0,1fr)` grid with an 8px gap, a `8px 0` padding pair and a
		// 1px bottom hairline — dropped on the last row
		// (`extensions.css:2344-2350,2306-2308`).
		for i, check := range integration.DiagnosisChecks {
			a.diagnosisCheckRow(c, check, i == len(integration.DiagnosisChecks)-1)
		}
	})
}

// diagnosisCheckRow is one `.extension-diagnostics > div`: the status word in
// the grid's own 54px column and the message in the rest, on the caption step.
func (a *App) diagnosisCheckRow(c *ui.Context, check DiagnosisCheck, last bool) {
	tokens := a.tokens(c)
	t := a.cardTheme(c)
	// The status word is the provider's *raw* vocabulary (`extensions.css:2341`
	// capitalises only the first letter, `capitalize`), so it is not translated:
	// it is the word the provider answered in.
	ui.Column(c).FillWidth().Children(func() {
		grid := ui.Grid(c).FillWidth().Padding(t.Space(2), 0).
			ColumnTracks(ui.Fixed(a.cardSpace(t, 13.5)), ui.Fr(1)).
			GapX(t.Space(2)).AlignItems(ui.Start)
		grid.Children(func() {
			ui.Text(c, capitalizeWord(check.Status)).FontSize(tokens.Caption).
				TextColor(statusInk(check.Status, tokens, t, tokens.TextTertiary)).ColumnStart(1)
			message := check.Message
			if strings.TrimSpace(message) == "" {
				message = check.ID
			}
			ui.Text(c, message).FontSize(tokens.Caption).
				TextColor(t.TextMuted).Wrap().ColumnStart(2)
		})
		if !last {
			ui.Box(c).FillWidth().Height(1).Background(tokens.Hairline).Shrink(0)
		}
	})
}

// diagnosisVerdict is the summary line's word: the provider's own overall
// status when it gave one, and the integration's state word when the check
// itself said nothing (`Diagnosis` is that fallback's spelling).
func diagnosisVerdict(integration Integration, copy i18n.Settings) string {
	// The provider cannot hide a prior lifecycle failure behind its own
	// verdict. A standalone provider keeps its existing summary vocabulary.
	if integration.DiagnosisFailed && (integration.DiagnosisLifecycleFailed || strings.EqualFold(strings.TrimSpace(integration.DiagnosisStatus), "ok")) {
		if problem := strings.TrimSpace(integration.Diagnosis); problem != "" {
			return problem
		}
	}
	if status := strings.TrimSpace(integration.DiagnosisStatus); status != "" {
		return status
	}
	if word := strings.TrimSpace(integration.Diagnosis); word != "" {
		return word
	}
	return integration.state(copy)
}

// diagnosisRan reports whether any check reported anything at all: the
// provider's own verdict, a summary word this build derived, or a check row.
// None of the three is the reference's "Diagnostics are unavailable." state.
func (i Integration) diagnosisRan() bool {
	return strings.TrimSpace(i.DiagnosisStatus) != "" ||
		strings.TrimSpace(i.Diagnosis) != "" || len(i.DiagnosisChecks) > 0
}

// capitalizeWord applies the reference's `text-transform: capitalize` to one
// provider-supplied word (`extensions.css:2331,2341`): the first letter is
// uppercased and the rest is left exactly as the provider spelled it, so a
// vocabulary this build does not know still prints its own word.
func capitalizeWord(word string) string {
	trimmed := strings.TrimSpace(word)
	if trimmed == "" {
		return trimmed
	}
	first := []rune(trimmed)[0]
	return strings.ToUpper(string(first)) + string([]rune(trimmed)[1:])
}

// statusInk is one status word's colour, the reference's own split: `ok` and
// `healthy` take the strong ink, `error` and `broken` the warning, and every
// other word the caller's quiet register (`extensions.css:2334-2346`). The
// summary line and the check rows share this classifier because the reference
// ranged the *same* `--${diagnose.status}` / `--${check.status}` modifier over
// both; only the fallback differs — the summary sits on `--text-secondary`, a
// check row on the quieter `--text-tertiary` (`:2329` vs `:2360`).
//
// P8-d 重定基线（§5 判据）：`ok`/`healthy` 曾是 `t.Accent`。accent 只回答
// 「哪个被选中 / 哪个是开的」（§5 四类），一个「这条好」的**结果语义**不在
// 其中——它既不是控件状态，也不是主 CTA。所以这两个词降到 `TextStrong`（与
// 它右边那列消息的 `TextMuted` 仍差两档，读得出「结论 vs 说明」），而
// `error`/`broken` 保留 `t.Warning`：那是**语义色**，不是 accent（§5 第 3 条的
// 状态色说的是控件自己的选中/开启，语义色另有一支）。
func statusInk(status string, tokens theme.Tokens, t *ui.Theme, quiet ui.Color) ui.Color {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "ok", "healthy":
		return tokens.TextStrong
	case "error", "broken":
		return t.Warning
	default:
		return quiet
	}
}

// healthDuration is one probe's wall time, as the old card printed it: the
// raw millisecond count, no unit conversion.
func healthDuration(ms uint64) string { return strconv.FormatUint(ms, 10) + "ms" }

// healthExitCode is a probe's exit code, or `-` for one that never ran to an
// exit (the host records -1). The old card's `exit: {code}` reads the same
// way whether the code came from a real exit or from a timeout.
func healthExitCode(code int) string {
	if code < 0 {
		return "-"
	}
	return strconv.Itoa(code)
}

// healthCheckedAt is the stored RFC 3339 timestamp as a readable local time.
// An empty or unparseable value is returned trimmed rather than swallowed: a
// timestamp this build cannot read is still what the repository holds.
func healthCheckedAt(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	if parsed, err := time.Parse(time.RFC3339, raw); err == nil {
		return parsed.Local().Format("2006-01-02 15:04")
	}
	return raw
}

// approvalDetail draws the recorded permission approval under the
// integration's own rows (the old host's R7-8 block): when it happened, the
// manifest digest it is bound to with the on-disk digest beside it — "what I
// approved" and "what is here now" as two readable rows rather than a
// boolean — the permissions it covered, tiered by the same host-enforced
// vocabulary the permission audit uses, and one warning line when the bytes
// on disk no longer match the approval. No record is one empty-state line,
// not a block of placeholders.
func (a *App) approvalDetail(c *ui.Context, copy i18n.Settings, record *ApprovalRecord) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	if record == nil {
		a.factRow(c, copy.ApprovalRecord, copy.ApprovalRecordNone)
		return
	}
	a.labelRow(c, copy.ApprovalRecord, "")
	a.factRow(c, copy.ApprovalRecordApprovedAt, approvalApprovedAt(record.At))
	digest := copy.ApprovalRecordDigestUnknown
	if short := extensions.ShortDigest(record.ApprovedDigest); short != "" {
		digest = short
	}
	current := copy.ApprovalRecordDigestUnknown
	if short := extensions.ShortDigest(record.CurrentDigest); short != "" {
		current = short
	}
	a.factRow(c, copy.ApprovalRecordDigest, digest)
	a.factRow(c, copy.ApprovalRecordDigestCurrent, current)
	language := a.settings().Language
	stale := extensions.ApprovalIsStale(record.ApprovedDigest, record.CurrentDigest)
	// The changed-manifest warning is *reported*, never acted on: "the approval
	// no longer covers the bytes on disk" is a prompt to re-approve, not a
	// version state to restore. Unknown (either side missing) stays silent. It
	// rides under the permissions row as the reference's own
	// `.extension-approval-record__stale` banner (`extensions.css:2171-2179`),
	// never as a nameless ruled card row with a lone `!`.
	staleBelow := func() {
		if stale {
			a.approvalStaleBanner(c, copy)
		}
	}
	if len(record.Enforced) == 0 && len(record.Disclosure) == 0 {
		a.labelRow(c, copy.ApprovalRecordPermissions, copy.ApprovalRecordPermissionsNone, staleBelow)
	} else {
		// The reference draws the approved permissions as *pills* under the
		// label, never as one ruled row per id: an enforced id wears the
		// recognizable raised-quiet + accent-keyline face its twin in the audit
		// list has, a disclosure id the plain icon-surface face
		// (`.extension-approval-record__permission`, `extensions.css:2149-2168`).
		a.labelRow(c, copy.ApprovalRecordPermissions, "", func() {}, func() {
			ui.Column(c).FillWidth().Gap(t.Space(2)).Children(func() {
				if len(record.Enforced) > 0 {
					ui.Text(c, copy.PermissionsEnforcedLabel).FontSize(tokens.Caption).
						FontWeight(620).TextColor(tokens.TextSecondary)
					a.approvalPermissionPills(c, language, record.Enforced, true)
				}
				if len(record.Disclosure) > 0 {
					ui.Text(c, copy.PermissionsDisclosureLabel).FontSize(tokens.Caption).
						FontWeight(620).TextColor(tokens.TextSecondary)
					a.approvalPermissionPills(c, language, record.Disclosure, false)
				}
			})
		}, staleBelow)
	}
}

// approvalApprovedAt is the record's Unix seconds as a readable local time
// (the old host's `toLocaleString`; the health report's own timestamp shape).
// A record without a time is the zero row's own absence: no line at all.
func approvalApprovedAt(at uint64) string {
	if at == 0 {
		return ""
	}
	return time.Unix(int64(at), 0).Local().Format("2006-01-02 15:04")
}

// integrationRowFace is the decoration the integration row's own state asks
// for. A broken row wears `.extension-row--broken`: the warm raised pane, the
// warning keyline and the warning rule, so an unusable integration reads at a
// glance instead of only in its status word. A row a `floter://register` link
// named is the row the link **chose**, so it wears the contract's neutral
// selection rung (`RowSelected`, docs/raycast-design.md §4.3) with no keyline
// and no leading rule. Every other row keeps the card's plane and an unlit
// rule (hover lights it in cardRow).
//
// P8-c 重定基线（§6.3 第 2 条 / §5）：命名行的 `RaisedQuiet` + `AccentEdge` +
// accent bar → `RowSelected`，accent 只留给前导图标。旧面是 base.css 的
// `.extension-row--register`（升起的静默面 + accent 内环 + accent 前导条），
// 三处都是 accent；而 §5 的判据是「accent 只能回答『哪个被选中』，不能回答
// 『这块面好看』」——这一行确实是被选的，但**选中行**在列表里从不拿 accent
// （§4.3 末句），所以选中本身用中性档，前导图标是唯一可带 accent 的位置。
func (a *App) integrationRowFace(c *ui.Context, integration Integration) rowFace {
	tokens := a.tokens(c)
	t := a.cardTheme(c)
	switch {
	case integration.Broken:
		// P13-e（§6.4 第 4-4 行，**故意不加**）：破损行的那条受光边已经被它的
		// 警告色内环占住了（`Inset` 四边都在，`InsetShadow(0,0,0,1, warning)`）。
		// §1 的不变量是「一个面只说一句话」——再叠一条白冠线会画进同一个 1px 行，
		// 把「这块坏了」洗成「这块被选中了」。臂的顺序也维持原样（先 Broken）：
		// 一块既坏又被链接命名的行说的是「坏的」那一句。
		return rowFace{Face: tokens.RaisedWarm, FaceSet: true, Inset: t.Warning, Bar: t.Warning}
	case integration.Highlighted:
		// P13-e（`docs/liquid-glass.md` §6.4 第 4-1 行）：这一行是**被选中的面**，
		// 不是一个色块。`Lit` 给它 E1 的一对线（顶 `LensRim` 受光边 + 底
		// `LensEdge` 对侧），因为「选中」是这个应用里唯一一种「同一块地板上
		// 又高半层」的意思。
		return rowFace{Face: tokens.RowSelected, FaceSet: true, Lit: true}
	}
	return rowFace{}
}

// integrationRow is one integration as a card: its identity and state, what
// it declares, what it can run (each command a row with its switch and its
// alias), and the row of doors — check, re-scan, uninstall.
func (a *App) integrationRow(c *ui.Context, copy i18n.Settings, integration Integration) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	// The row's own one-word freshness, read once and used twice: the mark
	// beside the name and the fuller row below it, projected from the same
	// value so the two can never disagree.
	freshness, hasFreshness := a.freshnessOf(integration)
	// The card wears the reference extension row's own geometry, not the
	// settings card's: `.extension-row` is a 66px row with 8px of padding and a
	// 4px line gap (`extensions.css:15-16,733-744,879-880`), so the title row is
	// a 66u floor and every row under it — Permissions, Freshness, the command
	// list, the action cluster — shares the same 8u inset and 4u line gap. That
	// is what makes the title's name, the sub-rows' labels and the card's
	// separators line up on one text column.
	a.cardGeometry(c, t.Space(2), t.Space(16.5), t.Space(1), "", func() {
		// The link's mark: a row the `floter://register` link named wears the
		// reference's own sentence under its description (the reference drew a
		// dot before the name; a native pane has no tooltip, so the word itself
		// is the mark). An unnamed row draws nothing.
		highlight := ""
		if integration.Highlighted {
			highlight = copy.RegisterHighlight
		}
		// The title row is the reference's own `.extension-row__title`: the
		// name, the version beside it and the freshness mark trailing both,
		// all in the label column, with the runtime-unavailable chip as the
		// row's only control. The old port printed the version on a separate
		// identity row and the freshness dot in the control slot.
		a.cardRow(c, ui.Center, func() {
			if a.integrationNav.detail != nil {
				if a.extensionIconButton(c.Key("back"), "arrow-left", copy.IntegrationsBack, false).Clicked() {
					a.flushSettingsWrites()
					a.closeIntegrationDetail()
				}
			} else {
				a.packageChip(c, false, integration.Highlighted)
			}
		}, a.integrationRowFace(c, integration), func() {
			if !integration.RuntimeAvailable {
				a.runtimeUnavailableBadge(c, copy, integration)
			}
		}, func() {
			// P13-ae: the title line is a `nowrap` flex row like the reference's
			// `.extension-row__title` (`extensions.css:884-894`: `display: flex`, no
			// `flex-wrap`), so the name is the only child that gives: the version
			// (`flex: 0 0 auto`) and the freshness mark keep the line they are on.
			// A wrapping row was the old shape, and it made a long package name
			// drop the version onto a second line — the row grew for the one title
			// whose length was already the problem.
			title := ui.Row(c).FillWidth().GapX(t.Space(2)).AlignItems(ui.Center)
			title.Children(func() {
				// P13-ae: a package's name is a *value* — `com.raycast.extensions.
				// something` is chosen by whoever published it, not by this build —
				// so it takes one line and an ellipsis instead of wrapping into the
				// description below it (`.extension-row__title strong { min-width: 0;
				// overflow: hidden; text-overflow: ellipsis; white-space: nowrap }`,
				// `main:src/styles/extensions.css:895-907`). Its `min-width: 0` is
				// what lets the ellipsis land in the name column instead of pushing
				// the version and freshness marks out of the row; the full name
				// rides the row as a tooltip, since the settings page is where a
				// package identifies itself.
				nameText := ui.Text(c, integration.Name).FontSize(tokens.Emphasis).FontWeight(580).
					TextColor(tokens.TextStrong).SingleLine().Ellipsis("\u2026").
					Shrink(1).MinWidth(0)
				// P13-az：全名提示是浮面（§6.20 20-3）。
				tokens.Tip(c, nameText, integration.Name)
				if integration.Version != "" {
					ui.Text(c, "v"+integration.Version).FontSize(t.FontSize).FontWeight(500).TextColor(tokens.TextTertiary)
				}
				if hasFreshness {
					a.freshnessDot(c, copy, freshness)
				}
			})
			if integration.Description != "" {
				ui.Text(c, integration.Description).FontSize(t.FontSize).FontWeight(500).TextColor(t.TextMuted)
			}
			if highlight != "" {
				ui.Text(c, highlight).FontSize(t.FontSize).FontWeight(500).TextColor(t.Warning)
			}
			// The reference's single `.extension-row__meta` line replaces the
			// old separate identity row: the package identity, the kind, the
			// runtime source and the state word together under the title.
			a.integrationMeta(c, copy, integration)
		})

		if len(integration.Permissions) > 0 && !integration.Orphan {
			labelClicked := a.row(c, copy.IntegrationsPermissions, a.permissionLine(integration, copy), func() {
				var permissions ui.Element
				a.formFeedbackOutlet(c.Key("permissions-outlet"), a.integrationLead, func() {
					permissions = a.actionButton(c, copy.IntegrationsPermissions)
				}, func() bool { return permissions.FocusVisible() })
				if permissions.Clicked() {
					a.toggleAudit(integration.ID)
				}
			}, func() { a.permissionAudit(c, copy, integration) })
			if labelClicked {
				a.toggleAudit(integration.ID)
			}
		}

		// The freshness of the command list: when it was last derived, how
		// that went, and how the list moved. Nothing is shown for an
		// integration nothing has ever probed — "unknown" is its own state,
		// not a row of zeroes.
		if hasFreshness {
			a.freshnessSection(c, copy, integration, freshness)
		}

		// The stored lifecycle health: the probe report lives in the repository,
		// so the row says how the tool was last found to be — before any check
		// runs in this session — and a check refreshes it. The status word is
		// the row's value; the live findings are the diagnostics row below.
		if integration.Health != "" {
			a.row(c, copy.IntegrationsHealth, "", func() {
				// The reference's heading carries the re-run control beside the
				// block's name (`.extension-detail-heading` is a
				// `space-between` flex row, `extensions.css:2015-2020`), and the
				// status chip opens the report under it. This build's row *is*
				// that heading, so the chip and the button share the slot: the
				// chip is the block's value and the button its one action.
				ui.Row(c).Gap(t.Space(1.5)).AlignItems(ui.Center).Children(func() {
					a.healthStatusChip(c, copy, integration.Health, integration.HealthStatus)
					// A stored report is history; only the current declaration can
					// authorize another run. Keep the report if that outlet retires.
					if a.Actions.ReprobeHealth != nil && integration.HealthReport != nil && !integration.HealthReprobeUnavailable {
						label := copy.IntegrationsHealthReprobe
						var reprobe ui.Element
						a.formFeedbackOutlet(c.Key("health-reprobe-outlet"), a.integrationLead, func() {
							reprobe = a.extensionIconButton(c, "refresh", label, a.rowBusy(integration.ID))
						}, func() bool { return reprobe.FocusVisible() })
						if reprobe.Clicked() {
							a.Actions.ReprobeHealth(integration.ID)
						}
					}
				})
			})
		}
		if integration.HealthReport != nil {
			a.healthDetail(c, copy, integration.HealthReport)
		}

		// The approval record: every installed integration has either one or
		// the empty state — an orphan has neither (no repository entry names
		// it, so there is nothing to record).
		if !integration.Orphan {
			a.approvalDetail(c, copy, integration.Approval)
		}

		if integration.diagnosisRan() {
			a.diagnosticsSection(c, copy, integration)
		}
		if reason := failureReason(copy, integration.FailureCode, integration.FailureDetail); reason != "" {
			a.row(c, copy.IntegrationsFailureDetail, "", func() {
				ui.Text(c, reason).FontSize(tokens.Caption).TextColor(t.Danger)
			})
		}
		if integration.Error != "" {
			a.row(c, copy.IntegrationsDiagnostics, integration.Error, func() {
				ui.Text(c, "\u25cf").FontSize(markDot(t)).TextColor(t.Danger)
			})
		}

		var discardOpener ui.Element
		if configOwnerIsHost(integration) && !integration.Orphan {
			// The row *is* the reference's configuration block title: the panel
			// drew `<h4>{t("settings.extensions.configuration")}</h4>` above the
			// form (`ExtensionsPanel.tsx:2971-2975`), and the block's own action
			// carried the verb. Labelling the row with the verb instead printed
			// "Configure" twice on one line and gave the block a different name
			// from its tool-owned sibling, which already leads with
			// `ConfigSection` (see configOpenToolRow).
			var opener ui.Handle
			wasAsking := a.configDiscard[integration.ID]
			opened := a.row(c.Key("integration.config"), copy.ConfigSection, "", func() {
				var button ui.Element
				a.formFeedbackOutlet(c.Key("host-config-outlet"), a.integrationLead+a.permissionFeedback(integration)+approvalFeedback(integration), func() {
					button = a.actionButton(c, copy.ConfigOpen).Bind(&opener)
				})
				a.restoreNotice(c, integration.ID, "discard", a.configDiscard[integration.ID], button)
				if button.Clicked() {
					a.toggleConfig(integration.ID)
				}
			}, func() { a.configFields(c, copy, integration) }, func() {
				// The discard bar is the reference's own sibling of the form
				// (`ExtensionsPanel.tsx:3029-3035`): it appears while the
				// fold-away question is armed and the draft is still dirty.
				if a.configDiscard[integration.ID] && a.configDirty(integration, a.draft(integration)) {
					a.configDiscardBar(c, copy, integration)
				}
			})
			if opened {
				a.toggleConfig(integration.ID)
				// Clicking the disclosure's title focuses its text column. The
				// same action must leave a keyboard-operable disclosure behind.
				if !a.configDiscard[integration.ID] {
					opener.Focus(c)
				}
			}
			// Both answers remove the focused confirmation button. Hand the
			// keyboard back to the existing disclosure in the same frame.
			if wasAsking && !a.configDiscard[integration.ID] {
				c.Resolve(opener).Focus().ScrollIntoView()
			}
			// The form can survive a schema refresh that removes just its
			// focused editor. Return to its disclosure without touching values.
			fieldFocus := a.noticeFocus(c, integration.ID, "field")
			a.restoreNotice(c, integration.ID, "field", c.Resolve(fieldFocus.panel).Valid(), c.Resolve(opener))
			transfer := c.Resolve(a.noticeFocus(c, integration.ID, "transfer").panel)
			a.restoreNotice(c, integration.ID, "transfer", a.configOperationNow(integration.ID) != "" || transfer.Valid() && !transfer.IsDisabled(), c.Resolve(opener))
			discardOpener = c.Resolve(opener)
		} else if configOwnerIsTool(integration) && !integration.Orphan {
			// A tool-owned configuration has no host form: the reference drew an
			// "Open configuration" button instead, running the provider's own
			// `openCommand` (`ExtensionsPanel.tsx:2977-2986`). The button is
			// disabled when the provider declared no `openCommand`, exactly as
			// the reference's `disabled={!configuration.openPlan}` did.
			discardOpener = a.configOpenToolRow(c, copy, integration)
		}

		// Only the commands the provider's descriptor declared are *commands* to
		// this panel. The host synthesizes an editor command for a tool-owned
		// configuration, and the reference never lists it: its command list is
		// `externalCommands` filtered by extension, which is the provider
		// registry (`main:src-tauri/src/extensions/catalog.rs:427-449`), and a
		// tool-owned configuration is the "Configuration" block above with an
		// "Open configuration" action (`ExtensionsPanel.tsx:2971-2986`). The
		// synthesized row here carried a launcher switch and an alias field for
		// a command the launcher does not accept (see the shell's
		// `launcherCommands`), i.e. two controls that could not do anything.
		if commands := declaredCommands(integration.Commands); len(commands) > 0 && !integration.Orphan {
			// P13-fw（`docs/liquid-glass.md` §6.142）：命令这一块（标题 / 说明 / 每一块板）
			// 戴的是**这张卡自己的 8u 缩进**，与卡里其他每一行同一条竖线。
			//
			// 此前这三样是卡的直接子节点，一个缩进都不戴：实测 720 宽、浅色，卡的左边框
			// 在 x=187（216），命令板的左边框紧贴 x=188（194）——两块 1px 线中间**没有面**。
			// 一条命令时这只是「板的边框盖住了卡的边框」；24 条命令时它是**沿整张卡左右
			// 两侧从上贯到下的一条 2px 双线**（216 + 194），读起来是一圈画框，正好是 §1
			// 「靠画框分层」要拆掉的那种东西。卡里的其他行（标题、权限、新鲜度）都在
			// x=196，所以命令板也回到 196，卡片自己的面在两者之间露出 8px 的沟。
			//
			// `Gap(0)` 是必须的：卡的子节点列本来就是 0 间隔，包一层不许顺手加一条。
			ui.Column(c.Key("integration.commands")).FillWidth().Gap(0).Padding(0, a.rowInset(t)).Children(func() {
				// The per-command switches' caption and the one line that says
				// what a switch does, printed above the list rather than repeated
				// on every row (the old build's R39).
				a.sectionHeading(c, copy.IntegrationsCommands, nil)
				a.sectionHint(c, copy.IntegrationsCommandsHint)
				a.commandList(c, copy, integration.ID, commands, a.integrationLead, approvalFeedback(integration), a.permissionFeedback(integration),
					strconv.Quote(integration.Description),
					strconv.FormatBool(integration.Highlighted),
					a.commandTransferFeedback(copy),
					strconv.FormatBool(hasFreshness),
					strconv.FormatBool(hasFreshness && freshness.Source == extensions.FreshnessHealth),
					strconv.FormatBool(!integration.Orphan && (configOwnerIsHost(integration) || configOwnerIsTool(integration))),
					a.commandConfigLayoutFeedback(integration),
					strconv.Quote(integration.Error), failureReason(copy, integration.FailureCode, integration.FailureDetail),
					strconv.Quote(integration.Health)+fmt.Sprintf("%#v", integration.HealthReport),
					strconv.Quote(integration.Diagnosis)+strconv.Quote(integration.DiagnosisStatus)+fmt.Sprintf("%#v", integration.DiagnosisChecks))
			})
		}

		runWasOpen := a.runOpen[integration.ID]
		a.runForm(c, copy, integration)

		// The last background run's output rides the row it came from: the
		// panel run that took the background route leaves it here (see
		// shell.runWithParams).
		a.runOutput(c, copy, integration)

		if integration.Orphan {
			// An orphan is a package directory the repository does not name:
			// the row offers to graft it in or to remove it, and nothing
			// else — there is no record to enable, check or uninstall.
			var adoptOpener ui.Element
			a.row(c, copy.IntegrationsOrphan, copy.IntegrationsAdoptHint, func() {
				if a.Actions.AdoptIntegration != nil {
					a.formFeedbackOutlet(c.Key("orphan-adopt-outlet"), a.integrationLead, func() {
						if a.orphanOperation[integration.ID] == "adopt" {
							adoptOpener = a.busyActionButton(c, copy.IntegrationsAdopt, "orphan.adopt")
						} else if a.orphanOperation[integration.ID] != "" {
							adoptOpener = a.disabledActionButton(c, copy.IntegrationsAdopt)
						} else {
							adoptOpener = a.actionButton(c, copy.IntegrationsAdopt)
						}
					}, func() bool { return adoptOpener.FocusVisible() })
					if adoptOpener.Clicked() {
						a.Actions.AdoptIntegration(integration.ID)
					}
				}
				if a.Actions.DeleteOrphan != nil {
					var remove ui.Element
					a.formFeedbackOutlet(c.Key("orphan-delete-outlet"), a.integrationLead, func() {
						if a.orphanOperation[integration.ID] == "delete" {
							remove = a.busyActionButton(c, copy.IntegrationsDeleteOrphan, "orphan.delete")
						} else if a.orphanOperation[integration.ID] != "" {
							remove = a.disabledActionButton(c, copy.IntegrationsDeleteOrphan)
						} else {
							remove = a.actionButton(c, copy.IntegrationsDeleteOrphan)
						}
					}, func() bool { return remove.FocusVisible() })
					if remove.Clicked() {
						a.Actions.DeleteOrphan(integration.ID)
					}
				}
			})
			a.restoreNotice(c, integration.ID, "disable", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "remove", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "uninstall", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "discard", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "save", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "repair", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "toggle", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "editor", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "run", a.runOpen[integration.ID] && len(integration.Params) > 0 && a.Actions.RunWithParams != nil, adoptOpener)
			a.restoreNotice(c, integration.ID, "command", false, adoptOpener)
			a.restoreNotice(c, integration.ID, "run-opener", false, adoptOpener)
			return
		}
		commandFocus := a.noticeFocus(c, integration.ID, "command")
		a.restoreNotice(c, integration.ID, "command", !a.rowBusy(integration.ID) && c.Resolve(commandFocus.panel).Valid(), ui.Element{})

		enabled := integration.Enabled
		enableChanged := false
		// The actions row keeps no label of its own: the reference drew the
		// action cluster and the toggle beside the row's title, not under an
		// "Enabled" heading (`src/extensions/ExtensionRow.tsx:288-458`). The
		// switch's own accessible name is what a test and a screen reader read.
		// busy is the whole-row lock: while any operation on this integration is
		// in flight the reference disabled *every* control in the cluster and
		// the switch together (`const busy = Boolean(operation)` /
		// `disabled={busy}`, `src/extensions/ExtensionRow.tsx:131,301-419,447`),
		// not only the button that was pressed.
		busy := a.rowBusy(integration.ID)
		// A first result or its disclosure changes the space above this row.
		// Observe those transitions, not the scroll position or output bytes.
		_, hasOutput := a.runOutputs[integration.ID]
		outputFeedback := strconv.FormatBool(hasOutput) + strconv.FormatBool(a.outputOpen[integration.ID])
		// rowAction draws one of the row's action pills, disabled while the row
		// is busy. The one button whose own work is in flight (the re-check or
		// the reconnect) is drawn by repairAction in its busy face instead.
		rowAction := func(label string) ui.Element {
			if busy {
				// P13-ba: `.Disabled` after the build is too late — the material was
				// already chosen. The locked cluster goes through the disabled arm.
				return a.disabledActionButton(c, label)
			}
			return a.actionButton(c, label)
		}
		// The inline run form above can disappear; the disclosure's identity
		// must survive that sibling removal for returned focus to remain valid.
		var removeOpener, disableOpener, checkOpener ui.Element
		a.rowAligned(c.Key("integration.actions"), ui.Center, nil, rowFace{Inert: busy}, "", nil, "", func() {
			// The row's Run button: on a runnable row it runs the integration —
			// straight away when it declares no inputs, or unfolding the inline
			// parameter form when it does (the same button is the disclosure, so
			// there is no second control to learn). A row that cannot run keeps
			// the button but disabled, with the reason in its tooltip, exactly as
			// the reference's `extensions-icon-button--row` did
			// (`src/extensions/ExtensionRow.tsx:381-399`).
			if a.Actions.RunWithParams != nil {
				runnable := integration.Running && !integration.Broken
				// P13-ba: the locked Run is **built** disabled, not disabled after the
				// fact, so its crown goes out with the rest of the cluster. Exactly one
				// pill is built either way.
				var run ui.Element
				a.formFeedbackOutlet(c.Key("row-run-output-outlet"), a.integrationLead+outputFeedback, func() {
					switch {
					case !runnable:
						run = tokens.Tip(c, a.disabledActionButton(c, copy.RunAction), copy.RunActionUnavailable)
					case busy:
						run = a.disabledActionButton(c, copy.RunAction)
					default:
						run = a.actionButton(c, copy.RunAction)
					}
				})
				a.rememberOperationFocus(c, integration.ID, "run-opener", run)
				if run.IsDisabled() && run.FocusWithin() {
					c.Resolve(*noticeExit(c)).Focus()
				}
				if runWasOpen && !a.runOpen[integration.ID] {
					run.Focus().ScrollIntoView()
				}
				a.restoreNotice(c, integration.ID, "run", a.runOpen[integration.ID] && len(integration.Params) > 0, run)
				if run.Clicked() && runnable {
					if len(integration.Params) > 0 {
						if a.runOpen == nil {
							a.runOpen = map[string]bool{}
						}
						a.runOpen[integration.ID] = !a.runOpen[integration.ID]
						delete(a.runError, integration.ID)
					} else {
						// No inputs: run at once. There is no form to print a
						// refusal under, and a run with no declared parameters
						// cannot raise a parameter failure, so the returned
						// failure is always nil here.
						a.Actions.RunWithParams(integration.ID, nil)
					}
				}
			} else {
				a.restoreNotice(c, integration.ID, "run", false, ui.Element{})
				a.restoreNotice(c, integration.ID, "run-opener", false, ui.Element{})
			}
			// A broken row's entry is the re-check, not a reconnect: the
			// reference drew the Wrench on a `broken` row and the reconnect
			// button on every other unavailable one
			// (`src/extensions/ExtensionRow.tsx:313-330,345-370`). A re-check
			// verifies the installed package and falls through to the search
			// path itself when the runtime is what moved, so a broken row
			// still has its way back.
			if integration.Broken {
				if a.Actions.RepairIntegration != nil {
					var recheck ui.Element
					a.formFeedbackOutlet(c.Key("row-recheck-outlet"), a.integrationLead+outputFeedback, func() {
						recheck = a.repairAction(c, integration.ID, copy.IntegrationsRecheck, copy.IntegrationsRecheck, a.Actions.RepairIntegration)
					}, func() bool { return recheck.FocusVisible() })
				}
			} else {
				switch integration.repairKind() {
				case repairReconnect:
					if a.Actions.ReconnectIntegration != nil {
						var reconnect ui.Element
						a.formFeedbackOutlet(c.Key("row-reconnect-outlet"), a.integrationLead+outputFeedback, func() {
							reconnect = a.repairAction(c, integration.ID, integration.repairLabel(copy), integration.repairTooltip(copy), a.Actions.ReconnectIntegration)
						}, func() bool { return reconnect.FocusVisible() })
					}
				case repairHomepage:
					if a.Actions.OpenHomepage != nil {
						var homepage ui.Element
						a.formFeedbackOutlet(c.Key("row-homepage-outlet"), a.integrationLead+outputFeedback, func() {
							homepage = tokens.Tip(c, rowAction(integration.repairLabel(copy)), integration.repairTooltip(copy))
						}, func() bool { return homepage.FocusVisible() })
						if homepage.Clicked() {
							a.Actions.OpenHomepage(integration.Homepage)
						}
					}
				}
			}
			if a.Actions.DiagnoseIntegration != nil {
				a.formFeedbackOutlet(c.Key("row-check-output-outlet"), a.integrationLead+outputFeedback, func() {
					checkOpener = rowAction(copy.IntegrationsCheck)
				})
				if checkOpener.Clicked() {
					a.Actions.DiagnoseIntegration(integration.ID)
				}
			}
			// A generated custom integration's command list came from the
			// tool's own help at connect time; the button re-runs that
			// derivation, so a tool that shipped new subcommands comes back
			// with them without a disconnect.
			if integration.Generated && a.Actions.ReprobeCommands != nil {
				var reprobe ui.Element
				// Pointer focus must not move the target between press and release.
				// Layout feedback still reveals either kind of existing focus.
				a.formFeedbackOutlet(c.Key("row-reprobe-outlet"), a.integrationLead+outputFeedback, func() {
					reprobe = rowAction(copy.IntegrationsReprobe)
				}, func() bool { return reprobe.FocusVisible() })
				if reprobe.Clicked() {
					a.Actions.ReprobeCommands(integration.ID)
				}
			}
			if integration.Generated && a.Actions.EditCustomTool != nil && a.Actions.ToolForEdit != nil {
				var edit ui.Element
				a.formFeedbackOutlet(c.Key("row-edit-outlet"), a.integrationLead+outputFeedback, func() {
					edit = rowAction(copy.EditLabel)
				}, func() bool { return edit.FocusVisible() })
				if edit.Clicked() {
					form := a.toolFormKey
					tool, ok := a.Actions.ToolForEdit(integration.ID)
					// Fetching may replace the editor or refresh the target's
					// eligibility. Its old answer cannot reopen either one.
					current, exists := integration, true
					if a.Integrations != nil {
						current, exists = a.integrationByID(integration.ID)
					}
					if ok && a.toolFormKey == form && exists && current.Generated && !current.Orphan &&
						a.Actions.EditCustomTool != nil && !a.rowBusy(integration.ID) {
						a.beginEdit(integration.ID, tool)
					}
				}
			}
			// Removal is one door for every kind: the row's button asks the
			// kind's own removal bar (`requestRemove` → `removeConfirmation`),
			// and the bar's confirm branches — npm and custom go on to the
			// componentized dialog, a system-owned built-in and a linked local
			// package run the plain removal, exactly as the reference's
			// `confirmRemoval` did (`src/ExtensionsPanel.tsx:1286-1304`).
			// Before this branch the two actions were wired in the shell and
			// some kinds skipped the bar, which handed npm and custom rows one
			// question fewer than the reference asked.
			if (a.Actions.UninstallIntegration != nil || a.Actions.UninstallComponents != nil) && !integration.Orphan {
				a.formFeedbackOutlet(c.Key("row-remove-output-outlet"), a.integrationLead+outputFeedback, func() {
					removeOpener = rowAction(integration.removalLabel(copy))
				})
				if removeOpener.Clicked() {
					a.requestRemove(integration.ID)
				}
			}
			// The componentized dialog, once the bar's confirm opened it,
			// floats over the row.
			a.uninstallComponentsRow(c, copy, integration)
			// The enable/disable toggle rides at the very end of the actions,
			// after the removal door, where the reference's separate
			// `.extension-row__toggle-slot` sat (`src/extensions/ExtensionRow.tsx:437-458`).
			// Its handling is unchanged: turning one *off* asks first because it
			// stops whatever is running; turning one on is no question at all.
			if a.Actions.SetIntegrationEnabled != nil {
				on := enabled
				a.formFeedbackOutlet(c.Key("row-toggle-output-outlet"), a.integrationLead+outputFeedback, func() {
					switch {
					case a.toggleBusy[integration.ID] || a.disableBusy[integration.ID]:
						// The write is in flight: the reference swapped the switch's
						// thumb for a turning LoaderCircle and set `aria-busy` until
						// `runMutation`'s `finally` (`settings-switch--loading`,
						// `src/extensions/ExtensionRow.tsx:443-455`).
						a.rememberOperationFocus(c, integration.ID, "toggle", a.busySwitchControl(c, &on, "extensions.toggle."+integration.ID).Label(copy.IntegrationsEnable))
					case busy || integration.Broken:
						// Another operation is in flight, or the row is broken: the
						// reference disabled the switch for both
						// (`disabled={busy || extension.state === "broken"}`).
						a.rememberOperationFocus(c, integration.ID, "toggle", disabledSwitch(a.switchControl(c, &on)).Label(copy.IntegrationsEnable))
					default:
						disableOpener = a.rememberOperationFocus(c, integration.ID, "toggle", a.switchControl(c, &on).Label(copy.IntegrationsEnable))
						if disableOpener.Changed() {
							if !on {
								a.requestDisable(integration.ID)
							} else {
								enabled, enableChanged = on, true
							}
						}
					}
				})
			}
		})
		if enableChanged && a.Actions.SetIntegrationEnabled != nil {
			a.startToggle(integration.ID, enabled)
		}
		// Discovery can remove the repair entry before its callback unlocks
		// the row. A disabled Check is not an outlet; restoreNotice then uses
		// the existing header return, without waiting on or moving the reply.
		repairFocus := a.noticeFocus(c, integration.ID, "repair")
		a.restoreNotice(c, integration.ID, "repair", c.Resolve(repairFocus.panel).Valid(), checkOpener)
		if !configOwnerIsTool(integration) || !discardOpener.Valid() {
			editorOutlet := discardOpener
			if !editorOutlet.Valid() {
				editorOutlet = checkOpener
			}
			a.restoreNotice(c, integration.ID, "editor", false, editorOutlet)
		}
		if !configOwnerIsHost(integration) {
			// The old form can disappear while its discard answer owns focus.
			// A tool without an editor still has the row's diagnostic outlet.
			if !discardOpener.Valid() && !busy {
				discardOpener = checkOpener
			}
			a.restoreNotice(c, integration.ID, "discard", a.configDiscard[integration.ID], discardOpener)
			// A host save can still be in flight when its form is replaced by
			// the provider's editor, or its schema is withdrawn altogether.
			a.restoreNotice(c, integration.ID, "save", false, discardOpener)
		}
		if !disableOpener.Valid() && integration.Broken {
			disableOpener = checkOpener
		}
		a.restoreNotice(c, integration.ID, "disable", a.disableConfirm[integration.ID], disableOpener)
		if !a.uninstallOpen[integration.ID] {
			a.restoreNotice(c, integration.ID, "remove", a.removeConfirm[integration.ID], removeOpener)
			a.restoreNotice(c, integration.ID, "uninstall", false, removeOpener)
		}
		if a.disableConfirm[integration.ID] {
			a.disableConfirmation(c.Key("integration.disable-confirmation"), copy, integration)
			if !a.disableConfirm[integration.ID] {
				disableOpener.Focus()
			}
		}
		if a.removeConfirm[integration.ID] {
			a.removeConfirmation(c.Key("integration.remove-confirmation"), copy, integration)
			if !a.removeConfirm[integration.ID] && !a.uninstallOpen[integration.ID] {
				removeOpener.Focus()
			}
		}
	})
}

// configOwnerIsHost reports whether an integration's configuration is the
// form's to draw.
//
// The reference gated the whole form on `configuration.descriptor.owner ===
// "host"` (`ExtensionsPanel.tsx:2975`) and drew an "Open configuration"
// button for a `tool`-owned one; the schema on which `owner` is *required*
// (`docs/extensions/schemas/provider-description.schema.json`) leaves a
// provider that omits it invalid, so no owner and `host` are the same thing
// here. A `tool` owner is the one case that must not wear the form: its
// editor lives at the tool, and drawing a host form over it would offer to
// write values the tool owns.
func configOwnerIsHost(integration Integration) bool {
	return len(integration.Config) > 0 && !strings.EqualFold(integration.ConfigOwner, "tool")
}

// configOwnerIsTool reports whether an integration's configuration is the
// tool's own to open: the reference's `configuration.descriptor.owner ===
// "tool"` arm (`ExtensionsPanel.tsx:2977`). Such a card carries the "Open
// configuration" button rather than the host form. The gate is the owner
// alone, not the schema's presence — a `tool` owner declares no host schema,
// and its `openCommand` may be empty, in which case the button is drawn
// disabled (the reference's `disabled={!configuration.openPlan}`).
func configOwnerIsTool(integration Integration) bool {
	return strings.EqualFold(integration.ConfigOwner, "tool")
}

// toggleConfig folds or unfolds one integration's configuration form.
//
// Folding a form whose draft has unsaved edits is the reference's own
// two-step: the first press only *asks* (`if (configDirty) {
// setDetailsDiscardArmed(true); return }`, `ExtensionsPanel.tsx:2056-2060`)
// and the panel draws the discard bar under the form; the question is answered
// by keeping the form open or by discarding, which is what finally folds it.
// Opening a folded form is never a question.
func (a *App) toggleConfig(id string) {
	if a.configOpen == nil {
		a.configOpen = map[string]bool{}
	}
	if a.configOpen[id] {
		if integration, ok := a.integrationByID(id); ok && a.configDirty(integration, a.draft(integration)) {
			a.armConfigDiscard(id)
			return
		}
		a.closeConfig(id)
		return
	}
	a.configOpen[id] = true
	a.configError[id] = ""
	a.disarmConfigDiscard(id)
}

// integrationByID finds an integration in the list the panel is drawing.
func (a *App) integrationByID(id string) (Integration, bool) {
	for _, integration := range a.installedIntegrations() {
		if integration.ID == id {
			return integration, true
		}
	}
	return Integration{}, false
}

// armConfigDiscard asks before a dirty form is folded away. The reference armed
// its own question with `useTimedReset(detailsDiscardArmed, …)` and the same
// three-second window the removal and disable bars use
// (`ExtensionsPanel.tsx:866`), so an ask left unanswered withdraws instead of
// staying armed on a later glance.
func (a *App) armConfigDiscard(id string) {
	if a.configDiscard == nil {
		a.configDiscard = map[string]bool{}
	}
	if a.configDiscardAt == nil {
		a.configDiscardAt = map[string]time.Time{}
	}
	a.configDiscard[id] = true
	a.configDiscardAt[id] = a.now()
}

// disarmConfigDiscard answers the question with "keep": the form stays open,
// exactly as the reference's Cancel did (`setDetailsDiscardArmed(false)`).
func (a *App) disarmConfigDiscard(id string) {
	if a.configDiscard != nil {
		delete(a.configDiscard, id)
	}
	if a.configDiscardAt != nil {
		delete(a.configDiscardAt, id)
	}
}

// closeConfig folds one integration's form away and drops the draft: a form
// opened again reads the stored values, which is the reference's own effect on
// the selected integration changing (`ExtensionsPanel.tsx:1094-1096`).
func (a *App) closeConfig(id string) {
	a.disarmConfigDiscard(id)
	if a.configOpen != nil {
		delete(a.configOpen, id)
	}
	if a.configDrafts != nil {
		delete(a.configDrafts, id)
	}
	if a.configError != nil {
		delete(a.configError, id)
	}
	if a.configFieldErrors != nil {
		prefix := id + "\x00"
		for key := range a.configFieldErrors {
			if strings.HasPrefix(key, prefix) {
				delete(a.configFieldErrors, key)
			}
		}
	}
	// The list boxes' offsets belong to the form that was open. Keeping them
	// after the draft is dropped would reopen the same schema mid-list, over a
	// value map the user has never scrolled.
	if a.configListScrolls != nil {
		prefix := id + "\x00"
		for key := range a.configListScrolls {
			if strings.HasPrefix(key, prefix) {
				delete(a.configListScrolls, key)
			}
		}
	}
}

// discardConfigChanges is the discard bar's destructive answer: the edits are
// dropped and the form closes (the reference's `discardDetailsChanges`,
// `ExtensionsPanel.tsx:2135-2138`).
func (a *App) discardConfigChanges(id string) { a.closeConfig(id) }

// configOpenToolRow draws a tool-owned configuration's one outlet: the
// reference's `settings.extensions.configuration` block title and the
// "Open configuration" action that runs the provider's own `openCommand`
// (`ExtensionsPanel.tsx:2971-2986`). The action is the panel's ordinary
// action pill, carrying the reference's ExternalLink mark then the word, and
// it is disabled when the provider declared no `openCommand` — the
// reference's `disabled={!configuration.openPlan}`.
func (a *App) configOpenToolRow(c *ui.Context, copy i18n.Settings, integration Integration) ui.Element {
	openable := len(integration.ConfigOpenCommand) > 0 && a.Actions.OpenConfiguration != nil && !a.rowBusy(integration.ID)
	var opener ui.Element
	// P13-go: the row and its only control share availability. A disabled
	// outlet keeps the card's plane; it must not lift or sink under the pointer.
	a.rowAligned(c.Key("tool-config-row"), ui.Center, nil, rowFace{Inert: !openable}, copy.ConfigSection, nil, "", func() {
		// P13-s（§6.2b-6）：禁用的面不跟着字一起淡——`openable` 直接进面。
		var button ui.Element
		a.formFeedbackOutlet(c.Key("tool-config-outlet"), a.integrationLead+strconv.Quote(integration.Error)+strconv.Quote(integration.Description)+a.permissionFeedback(integration)+approvalFeedback(integration), func() {
			button = a.extensionGlyphActionButton(c, "link", copy.ConfigOpenConfiguration,
				a.cardTheme(c).Space(7.5), a.cardTheme(c).Space(3.75), a.tokens(c).Body, !openable)
		})
		a.rememberOperationFocus(c, integration.ID, "editor", button)
		if !openable {
			button = button.Disabled(true).Cursor(ui.CursorDefault)
		} else {
			opener = button
		}
		if button.Clicked() && openable {
			a.Actions.OpenConfiguration(integration.ID, append([]string{}, integration.ConfigOpenCommand...))
		}
	})
	return opener
}

// configDiscardBar draws the reference's `.extension-discard-bar`
// (`extensions.css:2455-2482`, `ExtensionsPanel.tsx:3029-3035`): the error
// notice with the question, then Cancel and the destructive Discard. It is
// drawn under the form, and only while the question is armed *and* the draft is
// still dirty — the reference's `detailsDiscardArmed && configDirty`.
func (a *App) configDiscardBar(c *ui.Context, copy i18n.Settings, integration Integration) {
	focus := a.noticeFocus(c, integration.ID, "discard")
	band := a.noticeBand(c, true, copy.ConfigDiscardConfirm, func(cancel *ui.Element) {
		*cancel = a.barButton(c, copy.ConfigCancel, false, false, nil, func() {
			a.disarmConfigDiscard(integration.ID)
		}).Bind(&focus.cancel)
		a.barButton(c, copy.ConfigDiscard, true, false, nil, func() {
			a.discardConfigChanges(integration.ID)
		}).Bind(&focus.confirm)
	})
	// The reference's own effect puts focus on Cancel, so the first Enter or
	// Escape answers "keep" without the pointer moving.
	band.AutoFocus()
}

// toggleAudit folds or unfolds one integration's permission audit.
func (a *App) toggleAudit(id string) {
	if a.auditOpen == nil {
		a.auditOpen = map[string]bool{}
	}
	a.auditOpen[id] = !a.auditOpen[id]
}

// Permission declarations can reflow the audit above a focused form. Compare
// contents, including enforcement groups, without following draft or scroll
// changes. Hidden audits do not contribute an expanded list to the layout.
func (a *App) permissionFeedback(integration Integration) string {
	if integration.Orphan || len(integration.Permissions) == 0 {
		return ""
	}
	return fmt.Sprintf("%t:%#v:%#v", a.auditOpen[integration.ID], integration.Permissions, integration.Enforced)
}

// The approval block precedes both forms. Compare its displayed contents,
// including in-place record updates, rather than the record's address.
func approvalFeedback(integration Integration) string {
	if integration.Orphan {
		return ""
	}
	return fmt.Sprintf("%#v", integration.Approval)
}

// Only declared commands appear above the run form. Synthesized editor
// commands must not reclaim a user's scroll when the visible list is stable.
func catalogFeedback(integration Integration) string {
	return approvalFeedback(integration) + fmt.Sprintf("%#v", declaredCommands(integration.Commands))
}

// permissionAudit draws the per-permission explanation under a row: what each
// permission allows, and whether the host itself decides it. The list is folded
// away until the user asks for it, so a row stays a row.
//
// P11-be: the fold has **one** switch, and it is the row's own control slot
// (the Permissions row's trailing pill, `settingsui.go:2471-2478`). This block
// used to draw a second `actionButton(copy.IntegrationsPermissions)` as its
// first child, which made three "Permissions" on one surface — the row's label,
// the row's pill, and a full-width band under them. `cardRow` paints its
// `below` callbacks every frame (`rows.go:1035-1040`), so that band was on
// screen while the audit was *closed* too: an unexplained full-width button
// between the Permissions row and the next one. The row's label is a hit target
// as well (`cardRow`'s `names.Clicked()` → the row's `labelClicked`), so
// nothing was lost by removing it.
func (a *App) permissionAudit(c *ui.Context, copy i18n.Settings, integration Integration) {
	t := a.cardTheme(c)
	language := a.settings().Language
	if !a.auditOpen[integration.ID] {
		return
	}
	// Two tiers, the host's own decision first: what floter refuses until it
	// is approved, then what the tool merely declares. The split is the
	// message — a user must be able to tell a check from an FYI.
	var enforced, disclosure []string
	for _, permission := range integration.Permissions {
		if integration.Enforced[permission] {
			enforced = append(enforced, permission)
			continue
		}
		disclosure = append(disclosure, permission)
	}
	// The audit is a `below` block of the Permissions row. The row's own inset
	// is applied by `cardRow` to everything drawn in that slot (P11-bf), so the
	// block pads only its own vertical rhythm: its tier labels land on the
	// column the row labels above them sit on, and only one place answers
	// "where does the card's content column start?".
	ui.Column(c).FillWidth().Gap(t.Space(3)).Padding(0, 0, t.Space(1), 0).Children(func() {
		a.permissionTier(c, copy.PermissionsEnforcedLabel, copy.PermissionsEnforcedHint, true, language, enforced)
		a.permissionTier(c, copy.PermissionsDisclosureLabel, copy.PermissionsDisclosureHint, false, language, disclosure)
	})
}

// commandList draws an integration's commands as the reference's
// `.extension-command-list` (`ExtensionsPanel.tsx:2777-2871`,
// `extensions.css:2206-2281`): one plate per command, each holding the
// identity line (name, description, the words that summon it and the launcher
// switch) above the alias editor at the plate's full width. The port had one
// flat settings row per command with the alias editor as its grey second line,
// which is neither the reference's two-line plate nor its bordered list.
func (a *App) commandList(c *ui.Context, copy i18n.Settings, extensionID string, commands []Command, preceding ...string) {
	t := a.cardTheme(c)
	ui.Column(c).FillWidth().Gap(t.Space(2)).Children(func() {
		occurrences := map[string]int{}
		for index, command := range commands {
			command := command
			// Discovery may reorder commands while one owns the keyboard.
			// Distinguish duplicate declarations without keying other IDs by index.
			occurrence := occurrences[command.ID]
			occurrences[command.ID]++
			a.commandPlate(c.Key(strconv.Itoa(occurrence)+"\x00"+command.ID), copy, extensionID, command,
				strconv.Itoa(index)+"\x00"+strings.Join(preceding, "\x00"))
		}
	})
}

// declaredCommands keeps the commands the provider's descriptor declared and
// drops the ones the host synthesized (a tool-owned configuration's editor).
// The reference's command list is the provider registry, which never holds the
// synthesized command; see commandList's caller.
func declaredCommands(commands []Command) []Command {
	out := make([]Command, 0, len(commands))
	for _, command := range commands {
		if command.Declared {
			out = append(out, command)
		}
	}
	return out
}

// commandPlate is one command's card in the reference's list
// (`.extension-command-list > .extension-command-list__row`): a
// `--hairline`-edged, `--glass-control`-filled plate with the `--ext-radius`
// corner and a 10px/12px padding pair. A command whose launcher switch is off
// is dimmed as a whole (opacity 0.62) so its state reads before the switch is
// found — a de-emphasis, never a disable (the alias editor and the switch stay
// live).
func (a *App) commandPlate(c *ui.Context, copy i18n.Settings, extensionID string, command Command, position ...string) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	plate := ui.Column(c).FillWidth().Gap(t.Space(2)).
		Padding(t.Space(2.5), t.Space(3)).
		Radius(tokens.RadiusSM).Background(tokens.Control)
	a.rememberOperationFocus(c, extensionID, "command", plate)
	// `.extension-command-list__row` is a hairline-edged plate; the edge is a
	// real 1px border here because the reference's own box is `border: 1px` and
	// the plate's box was never a pinned metric.
	plate.Border(1, tokens.Hairline)
	// P13-m（`docs/liquid-glass.md` §6.2b-2 第 9-16 行）：命令块是扩展页命令列表里
	// **每一条命令**的面，与 §6.2 第 2-3 行的分组卡同档（E1）——分组卡有那一对线，
	// 它没有。外圈的 `Hairline` 是画框，一个字节不动；`LitFace` 只加两条 1px 内线。
	//
	// P13-ct（§6.63）：命令的开关关着时，这块面的材质换成 `DimFace`——**灯熄、暗线留**。
	// 此前它先戴 `LitFace`、再被下面那道 0.62 洗一遍，于是「灯还亮着」这件事没有决定过，
	// 只是被淡了 38%：实测冠线行 − 面 浅色 **+5 → +2**（0.62 洗在一条本来只有 5 级的
	// 冠线上，读不出来）、深色 **+17 → +11**（还亮着）。同一句「这条命令是关的」在两套
	// 外观上是两个说法。§3 说受光边是「这块面可以被碰」的记号，§6.15 18-1 给整张不可用
	// 的卡片定的也是「一道淡、灯熄」——这条面不是 `Disabled`（开关与别名框仍然是活的，
	// 参考那边也是 `--off` 而非 `:disabled`），所以它保留自己那一道 0.62，只是不再点灯。
	if command.Enabled {
		plate = tokens.LitFace(plate)
	} else {
		plate = tokens.DimFace(plate)
		plate.Opacity(0.62)
	}
	plate.Children(func() {
		a.formFeedbackOutlet(c.Key("command-switch-outlet"), strings.Join(position, ""), func() {
			a.commandIdentity(c, copy, extensionID, command)
		})
		// P13-kw: preserve the active editor's visible ink when discovery
		// moves its stable ID. Values and single-line descriptions do not
		// change its position, so they must not reclaim manual scrolling.
		a.formFeedbackOutlet(c.Key("command-alias-outlet"), strings.Join(position, ""), func() {
			a.commandAliasEditor(c, copy, extensionID, command)
		})
	})
}

// commandIdentity is the reference's `.extension-command-list__head`
// (`ExtensionsPanel.tsx:2815-2843`): the command's name, its description and
// the words that summon it on the left, the launcher switch on the right. The
// name is a `<code>` the reference set in the caption register at
// `--text-secondary` (`.extension-command-list code`,
// `extensions.css:2310-2316`); the description and the trigger line are the
// muted caption the list's `span` rule gave (`:2318-2322`).
func (a *App) commandIdentity(c *ui.Context, copy i18n.Settings, extensionID string, command Command) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	locked := a.rowBusy(extensionID)
	on := command.Enabled
	toggled := false
	name := command.Name
	if name == "" {
		name = command.ID
	}
	h := ui.Row(c).FillWidth().AlignItems(ui.Start).Gap(t.Space(3))
	h.Children(func() {
		identity := ui.Column(c).Grow(1).MinWidth(0).Gap(t.Space(0.5))
		identity.Children(func() {
			ui.Text(c, name).FontSize(tokens.Caption).
				TextColor(tokens.TextSecondary).SingleLine().Ellipsis("\u2026")
			description := command.Description
			if description == "" {
				description = copy.IntegrationsNoDescription
			}
			ui.Text(c, description).FontSize(tokens.Caption).
				TextColor(t.TextMuted).SingleLine().Ellipsis("\u2026")
			// The summon words are the reference's own "Summon with: …" line,
			// printed only when the command is one the provider registry knows —
			// the same vocabulary the launcher's trigger parser reads. A command
			// the host synthesized (the tool-owned configuration editor) is not in
			// that registry, so it prints no line (`ExtensionsPanel.tsx:2824-2829`).
			if command.Declared {
				if words := commandTriggerWords(command); len(words) > 0 {
					// P13-cr（`docs/liquid-glass.md` §6.61）：这一行此前是 `TextMuted`
					// 再乘一把 0.85（参考 CSS 的 `.extension-command-list__triggers`
					// `opacity: .85` 叠在 `span { color: var(--text-muted) }` 上，两个
					// 旋钮一道算）。乘法不是阶梯：实测浅色 141 恰好撞上
					// `TextTertiary` 的 142（1 级），深色 122 落在 `TextMuted` 133 与
					// `TextTertiary` 110 之间——同一行字在两套外观上站两个梯级。
					// 现在交给阶梯自己的第三档：浅 141 → 142（不可见），深 122 → 110。
					ui.Text(c, copy.IntegrationsCommandsTriggers(strings.Join(words, ", "))).
						FontSize(tokens.Caption).TextColor(tokens.TextTertiary).
						SingleLine().Ellipsis("\u2026")
				}
			}
		})
		// The switch rides the identity line's own top (the reference's
		// `align-items: flex-start` + `margin-top: 2px`). Its own click is the
		// toggle — never the whole line's, or the label would toggle too and
		// the two would cancel.
		switcher := a.switchControl(c, &on).Label(copy.IntegrationsCommandEnable(name)).
			Margin(t.Space(0.5), 0, 0, 0)
		if locked {
			switcher = disabledSwitch(switcher)
		}
		if switcher.Changed() && !locked {
			toggled = true
		}
	})
	if toggled && a.Actions.SetCommandEnabled != nil {
		a.observeSettingsWrite(func() { a.Actions.SetCommandEnabled(extensionID, command.ID, on) })
	}
}

// commandAliasEditor is the reference's `.extension-command-alias`
// (`ExtensionsPanel.tsx:2852-2868`): the caption label over the input, on the
// plate's full width. The input is the panel's own inline box (see
// `aliasField`), and the taken note is the muted caption line under it. It is
// a text field, so it rides the reference's 180ms debounce: one write per
// pause, not one per keystroke (see debounce.go).
func (a *App) commandAliasEditor(c *ui.Context, copy i18n.Settings, extensionID string, command Command) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	locked := a.rowBusy(extensionID)
	ui.Column(c).FillWidth().Gap(t.Space(0.5)).Children(func() {
		ui.Text(c, copy.IntegrationsCommandAlias).FontSize(tokens.Caption).TextColor(t.TextMuted)
		alias := command.Alias
		// The pending write is also the visible draft until its deadline.
		// A redraw or a redeclared editor must not resurrect the stored alias.
		if edit, pending := a.pendingAliases[extensionID+"\x00"+command.ID]; pending {
			alias = edit.alias
		}
		name := command.Name
		if name == "" {
			name = command.ID
		}
		input := a.aliasFieldLit(c, &alias, !locked).Placeholder(copy.IntegrationsCommandAliasPlaceholder).
			Label(copy.IntegrationsCommandAliasFor(name)).FillWidth()
		if locked {
			input = lockedControl(input.TextColor(tokens.Disabled))
		}
		if input.Changed() && !locked &&
			a.Actions.SetCommandAlias != nil {
			a.debounceAlias(extensionID, command.ID, alias)
		}
		// Taken describes the host's alias, not an uncommitted replacement.
		if command.Taken && strings.TrimSpace(alias) == strings.TrimSpace(command.Alias) {
			ui.Text(c, copy.IntegrationsCommandAliasTaken).
				FontSize(tokens.Caption).TextColor(t.TextMuted)
		}
	})
}

// commandTriggerWords is a command's summon vocabulary: its id, its name and
// its declared aliases, each reduced to its first whitespace-separated token —
// the reference's `pluginCommandTriggers` (`plugins/external.ts:86-97`), which
// the launcher's trigger parser reads too, so the words the plate prints are
// exactly the words that enter the mode. A word that does not begin with an
// ASCII letter or digit is dropped: the trigger split the launcher applies
// needs a typeable first character, and the reference's own de-duplication
// would otherwise print a word nothing can summon.
func commandTriggerWords(command Command) []string {
	seen := map[string]bool{}
	words := make([]string, 0, 3)
	for _, source := range append([]string{command.ID, command.Name}, command.Aliases...) {
		word := firstTriggerWord(strings.TrimSpace(source))
		key := strings.ToLower(word)
		if word == "" || seen[key] {
			continue
		}
		seen[key] = true
		words = append(words, word)
	}
	return words
}

// firstTriggerWord is the first whitespace-separated token of a source word:
// the reference reduces every trigger source to it because the mode is entered
// by one word followed by a space (`plugins/external.ts:79-84`).
func firstTriggerWord(source string) string {
	if fields := strings.Fields(source); len(fields) > 0 {
		return fields[0]
	}
	return ""
}

// permissionLine names the package's permissions, marking the ones the host
// itself decides.
func (a *App) permissionLine(integration Integration, copy i18n.Settings) string {
	language := a.settings().Language
	parts := make([]string, 0, len(integration.Permissions))
	for _, permission := range integration.Permissions {
		label := i18n.PermissionLabel(language, permission)
		if integration.Enforced[permission] {
			label += " (" + copy.PermissionsEnforced + ")"
		}
		parts = append(parts, label)
	}
	return strings.Join(parts, " · ")
}

// state is the integration's one-word state.
func (i Integration) state(copy i18n.Settings) string {
	switch {
	case i.Orphan:
		return copy.IntegrationsOrphan
	case i.Broken:
		return copy.IntegrationsBroken
	case i.Enabled:
		return copy.IntegrationsRunning
	default:
		return copy.IntegrationsOff
	}
}

// identity is the publisher and version line.
func (i Integration) identity() string {
	parts := []string{}
	if i.Publisher != "" {
		parts = append(parts, i.Publisher)
	}
	if i.Version != "" {
		parts = append(parts, i.Version)
	}
	if i.ToolVersion != "" && i.ToolVersion != i.Version {
		parts = append(parts, "tool "+i.ToolVersion)
	}
	if i.ID != "" {
		parts = append(parts, i.ID)
	}
	return strings.Join(parts, " · ")
}

// integrationKind is the integration's *type*, the second slot the reference's
// `.extension-row__meta` filled (`src/extensions/ExtensionRow.tsx:220-222`: the
// package identity, then `t(integrationKindKey(extension))`). It is a type, not
// the removal verb: the same card reads "System tool" and offers "Disconnect".
//
// The reference's `integrationKindKey` (`:77-94`) told seven kinds apart, but
// the `recommended` / `manifest` / `tool` branches all require `!connected`, and
// this build never draws a `DetectedTool` or `RecommendedTool` as an
// `Integration` — those live in their own sections with their own renderers. So
// for the connected cards this method is the four-way pick, walked in the
// reference's own order (`generatedCustom` first, so a custom integration that
// also came from npm is still custom).
func (i Integration) integrationKind(copy i18n.Settings) string {
	switch {
	case i.Generated:
		return copy.IntegrationsKindCustom
	case i.DistributionSource == "npm":
		return copy.IntegrationsKindNPM
	case i.DistributionSource == "built-in" && i.RuntimeOwnership == "system":
		return copy.IntegrationsKindSystem
	default:
		return copy.IntegrationsKindPackage
	}
}

// runtimeSourceLabel is where the runtime lives, the meta line's third slot
// (`src/extensions/ExtensionRow.tsx:233`). The word follows the reference's own
// `runtimeSource` projection; an unknown source (a fixture with no projection)
// prints nothing rather than inventing a home for the runtime.
func (i Integration) runtimeSourceLabel(copy i18n.Settings) string {
	switch i.RuntimeSource {
	case "managed":
		return copy.IntegrationsRuntimeManaged
	case "system":
		return copy.IntegrationsRuntimeSystem
	case "bundled":
		return copy.IntegrationsRuntimeBundled
	default:
		return ""
	}
}

// identityLine is the card's own second row: the package identity the reference
// printed, then the type word (`integrationKind`). Both are skipped when empty
// so an orphan's bare id row does not trail a separator, and the two are the
// reference's own two meta slots in its own order.
func (i Integration) identityLine(copy i18n.Settings) string {
	parts := []string{}
	if id := i.identity(); id != "" {
		parts = append(parts, id)
	}
	if kind := i.integrationKind(copy); kind != "" {
		parts = append(parts, kind)
	}
	return strings.Join(parts, " · ")
}

// The removal kinds the reference told apart (`src/extensions/ExtensionRow.tsx:109-114`).
// Exported so the shell can pick the kind's own removal notification after the
// settings page has passed the same fact through the action.
const (
	RemovalCustom  = "custom"
	RemovalNPM     = "npm"
	RemovalSystem  = "system"
	RemovalPackage = "package"
)

// removalKind is what this integration *is*, for the purpose of the removal
// verb: a generated custom integration is deleted, an npm package is
// uninstalled, a built-in whose runtime the system owns is disconnected (the
// package is not floter's to delete), and anything else is a linked local
// package that is only removed from the list. Ported line for line from the
// reference's `removalKind`; the order matters — a generated integration that
// also came from npm is still a custom one, exactly as the reference read it
// (`generatedCustom` first).
func (i Integration) removalKind() string {
	switch {
	case i.Generated:
		return RemovalCustom
	case i.DistributionSource == "npm":
		return RemovalNPM
	case i.DistributionSource == "built-in" && i.RuntimeOwnership == "system":
		return RemovalSystem
	default:
		return RemovalPackage
	}
}

// componentizedRemoval reports whether this kind's removal is the
// componentized dialog. The reference offered it to npm and custom only
// (`src/ExtensionsPanel.tsx:1290-1304`): those are the kinds whose files
// floter owns and whose host-config / tool-data / artifact categories are the
// user's to pick. A system-owned built-in and a linked local package have no
// data directory of floter's to delete, so they take the plain removal (the
// removal bar → `extensions_uninstall {removeData:false}`) and the reference
// never drew the three data checkboxes under them.
func (i Integration) componentizedRemoval() bool {
	switch i.removalKind() {
	case RemovalNPM, RemovalCustom:
		return true
	default:
		return false
	}
}

// removalLabel is the removal verb for this kind, the same four-way pick the
// reference made when it chose its menu item's text and icon
// (`src/extensions/ExtensionRow.tsx:409-418`): the custom kind reuses the
// `deleteCustom` string the confirmation already has, npm the plain
// uninstall.
func (i Integration) removalLabel(copy i18n.Settings) string {
	switch i.removalKind() {
	case RemovalCustom:
		return copy.RemoveDelete
	case RemovalNPM:
		return copy.IntegrationsUninstall
	case RemovalSystem:
		return copy.IntegrationsDisconnect
	default:
		return copy.IntegrationsRemovePackage
	}
}

// removalWords is the confirmation bar's question for this kind. The reference
// did not fall back to one generic sentence: `removalTextKey`
// (`src/ExtensionsPanel.tsx:2140-2151`) built one key per kind and
// `RemovalConfirmation.tsx:41` read the title through it, so the bar asks the
// same question the button promised — "Disconnect X?" under a Disconnect
// button, not "Uninstall X?".
//
// The second return is the `Description` half of that key family. The
// reference's bar never drew it — `:41` renders the Title only, and the
// `*Description` strings have no other reader in the original tree — so the
// band's whole question is `removalSentence`; the detail stays here as the
// per-kind mapping it is.
func (i Integration) removalWords(copy i18n.Settings) (title, detail string) {
	switch i.removalKind() {
	case RemovalCustom:
		return copy.RemoveCustomTitle(i.Name), copy.RemoveCustomDetail + " " + copy.RemoveCustomWarning
	case RemovalNPM:
		return copy.RemoveTitle(i.Name), copy.RemoveDetail
	case RemovalSystem:
		return copy.IntegrationsDisconnectTitle(i.Name), copy.IntegrationsDisconnectDetail
	default:
		return copy.IntegrationsRemovePackageTitle(i.Name), copy.IntegrationsRemovePackageDetail
	}
}

// removalSentence is the band's whole question, assembled the way the
// reference assembled it (`RemovalConfirmation.tsx:41`): the kind's title, and —
// for a generated custom integration only — the warning that Floter cannot undo
// the deletion. It is one line, not a title over a body: the reference's
// `*Description` strings were never drawn in the bar.
func (i Integration) removalSentence(copy i18n.Settings) string {
	title, _ := i.removalWords(copy)
	if i.Generated {
		return title + " " + copy.RemoveCustomWarning
	}
	return title
}

// The repair a connected row offers when its runtime no longer resolves. The
// reference drew one button for this state and picked its arm from the same
// three facts (`src/extensions/ExtensionRow.tsx:345-370`).
type repairKind int

const (
	// repairNone: the runtime resolves, or the row is broken for a reason a
	// check already reported — there is nothing to repair here.
	repairNone repairKind = iota
	// repairReconnect: the program belongs to the machine, so the search path
	// is asked again.
	repairReconnect
	// repairHomepage: floter does not own this runtime and has nowhere of its
	// own to look, so the row sends the user to the project's page.
	repairHomepage
)

// repairKind is which repair this row offers, or none. The condition is the
// reference's own: a *connected*, *not broken* row whose runtime does not
// resolve offered the button when its runtime belonged to the system, when it
// had a project page, or both. Managed and bundled rows with no page render
// nothing at all (the reference's own note on that arm), and a `broken` row
// shows the re-check instead (`src/extensions/ExtensionRow.tsx:313-330`).
func (i Integration) repairKind() repairKind {
	if i.Broken || i.RuntimeAvailable {
		return repairNone
	}
	if i.RuntimeOwnership == extensions.RuntimeOwnershipSystem {
		return repairReconnect
	}
	if i.Homepage != "" {
		return repairHomepage
	}
	return repairNone
}

// repairLabel is the button's word: the reference named the reconnect arm
// "Reconnect" whenever the runtime was the system's to look for (with or
// without a page, because reconnecting is what it does), and "Install tool
// first" for the arm that can only hand over a page.
func (i Integration) repairLabel(copy i18n.Settings) string {
	if i.repairKind() == repairHomepage {
		return copy.IntegrationsInstallTool
	}
	return copy.IntegrationsReconnect
}

// repairTooltip is the full sentence behind the button. The reference's
// `reconnectUnboundHint` says what to expect when the search path found
// nothing *and* there is no page either — the button re-runs the search, and
// the sentence says so rather than promising a tool it knows about.
func (i Integration) repairTooltip(copy i18n.Settings) string {
	if i.repairKind() == repairReconnect && i.Homepage == "" {
		return copy.IntegrationsReconnectUnboundHint
	}
	return i.repairLabel(copy)
}

// repairGlyphName is the mark the row's re-check / reconnect pill wears at rest:
// the reference's RefreshCw (`src/extensions/ExtensionRow.tsx:305,325,364`), the
// glyph the in-flight LoaderCircle replaces one for one. P13-cl: without it the
// busy pill had no slot to swap into and grew 15px on the press.
const repairGlyphName = "refresh"

// repairAction draws the row's re-check / reconnect entry and holds it in the
// in-flight face from the press until the shell calls back, so a press that
// has not landed is visible rather than assumed. The reference drew exactly
// this pair (`src/extensions/ExtensionRow.tsx:313-330,345-372`): one button
// whose icon became a turning LoaderCircle and whose `disabled={busy}` face
// stayed until `runMutation`'s `finally`.
func (a *App) repairAction(c *ui.Context, id, label, tooltip string, run func(string, func(error))) ui.Element {
	tokens := a.tokens(c)
	if a.repairBusy[id] {
		return a.rememberOperationFocus(c, id, "repair", tokens.Tip(c, a.busyActionButton(c, label, "extensions.repair."+id), tooltip))
	}
	// P13-cl（`docs/liquid-glass.md` §6.55）：这一枚键有三个状态——静息 / 另一操作在飞 /
	// 自己在飞——而三个状态画的是两种内容：一行字，或一枚环加一行字。此前静息臂是
	// **一行字**（`actionButton`），在飞臂是**环 + 一行字**（`busyActionButton`），于是
	// 一按下，词盒 x 走 **15px**（环 10 + 间距 5），胶囊也宽出 15px。
	//
	// 参考那边不会动，因为环是**顶替**那枚已有的 Wrench / RefreshCw
	// （`ExtensionRow.tsx:305,325,364`）——1:1 换，槽本来就留着。这一版丢了静息的
	// glyph，环就成了**加**上去的东西。所以这里把那枚 glyph 补回来：两臂的语义都是
	// 「再跑一次搜索」（`repairTooltip`：`reconnectUnboundHint` 说的就是搜索会重跑），
	// 一个 RefreshCw 对两臂都成立。
	//
	// P13-ba 的规矩照旧：`disabled` 在**建造时**传入，不先建后 `.Disabled`（先建会留下
	// 亮着的冠线，而冠线是「这枚键能按」的记号）。`extensionGlyphActionButton` 只把
	// `disabled` 交给材质，不设框架的禁用位，所以那一臂自己补两行。
	t := a.cardTheme(c)
	disabled := a.rowBusyExceptRepair(id)
	button := a.extensionGlyphActionButton(c, repairGlyphName, label,
		t.Space(7.5), t.Space(3.75), tokens.Body, disabled)
	if disabled {
		button = button.Disabled(true).Cursor(ui.CursorDefault)
	}
	button = a.rememberOperationFocus(c, id, "repair", tokens.Tip(c, button, tooltip))
	if button.Clicked() {
		a.startRepair(id, run)
	}
	return button
}

// rowBusy reports whether any operation on an integration is in flight, so the
// row's whole action cluster and its switch can lock together. The reference
// kept one `operation` for the panel and disabled the row's controls from it
// (`const busy = Boolean(operation)` / `disabled={busy}`,
// `src/extensions/ExtensionRow.tsx:131,301-419,447`); here the in-flight marks
// live on the row's own maps, so the union is what the whole-row lock reads.
func (a *App) rowBusy(id string) bool {
	return a.orphanOperation[id] != "" || a.diagnosisBusy[id] || a.healthBusy[id] || a.repairBusy[id] || a.disableBusy[id] || a.removeBusy[id] ||
		a.uninstallBusy[id] || a.toggleBusy[id]
}

// rowBusyExceptRepair is rowBusy without the repair mark, for the re-check /
// reconnect entry itself: when its own work is in flight the button wears the
// busy pill instead of a plain disabled face, so it asks only about the row's
// *other* operations.
func (a *App) rowBusyExceptRepair(id string) bool {
	return a.orphanOperation[id] != "" || a.diagnosisBusy[id] || a.healthBusy[id] || a.disableBusy[id] || a.removeBusy[id] || a.uninstallBusy[id] ||
		a.toggleBusy[id]
}

// BeginPackageInstall and FinishPackageInstall retain the install outlet's
// waiting state until its review, disk work and inventory refresh settle.
func (a *App) BeginPackageInstall(outlet string) bool {
	if a.packageInstallBusy[outlet] {
		return false
	}
	if a.packageInstallBusy == nil {
		a.packageInstallBusy = map[string]bool{}
	}
	a.packageInstallBusy[outlet] = true
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
	return true
}

func (a *App) FinishPackageInstall(outlet string) {
	delete(a.packageInstallBusy, outlet)
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// BeginOrphanOperation and FinishOrphanOperation keep the package row locked
// through permission review and refresh, including failure and cancellation.
func (a *App) BeginOrphanOperation(id, operation string) bool {
	// A former installed row can become an orphan while its old callback
	// is outstanding. Only an operation on this package owns its new outlet.
	if a.orphanOperation[id] != "" {
		return false
	}
	if a.orphanOperation == nil {
		a.orphanOperation = map[string]string{}
	}
	a.orphanOperation[id] = operation
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
	return true
}

func (a *App) FinishOrphanOperation(id string) {
	delete(a.orphanOperation, id)
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// BeginDiagnosis and FinishDiagnosis share the existing row operation lock.
// The shell settles it on the UI thread even when an obsolete check exits.
func (a *App) BeginDiagnosis(id string) bool {
	if a.rowBusy(id) {
		return false
	}
	if a.diagnosisBusy == nil {
		a.diagnosisBusy = map[string]bool{}
	}
	a.diagnosisBusy[id] = true
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
	return true
}

func (a *App) FinishDiagnosis(id string) {
	delete(a.diagnosisBusy, id)
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// BeginHealthReprobe and FinishHealthReprobe use the existing row operation
// lock. The shell calls them on the UI thread, including every failure exit.
func (a *App) BeginHealthReprobe(id string) bool {
	if a.rowBusy(id) {
		return false
	}
	if a.healthBusy == nil {
		a.healthBusy = map[string]bool{}
	}
	a.healthBusy[id] = true
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
	return true
}

func (a *App) FinishHealthReprobe(id string) {
	delete(a.healthBusy, id)
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// startRepair marks a row's re-check or reconnect as in flight and hands the
// shell the id to work on with the callback that settles the row.
func (a *App) startRepair(id string, run func(string, func(error))) {
	if a.repairBusy == nil {
		a.repairBusy = map[string]bool{}
	}
	a.repairBusy[id] = true
	run(id, func(_ error) { a.finishRepair(id) })
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// finishRepair settles a row after the shell reports a re-check or reconnect
// back on the main thread. The reference's `runMutation` cleared `busy` in
// `finally` whether the work succeeded or failed, and a failure reached the
// user through the app's own notice rather than through the row
// (`src/ExtensionsPanel.tsx:1190-1210,1255-1267`).
func (a *App) finishRepair(id string) {
	if a.repairBusy != nil {
		delete(a.repairBusy, id)
	}
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// startToggle marks an enable write as in flight and hands the shell the id to
// work on with the callback that settles the switch. The reference's
// `runMutation` set `operation` to the enable kind and cleared it in `finally`
// (`src/ExtensionsPanel.tsx:1190-1210`); a failure reaches the user through
// the shell's own notice path, so the switch only has to come back.
func (a *App) startToggle(id string, enabled bool) {
	if a.toggleBusy == nil {
		a.toggleBusy = map[string]bool{}
	}
	a.toggleBusy[id] = true
	a.Actions.SetIntegrationEnabled(id, enabled, func(_ error) { a.finishToggle(id) })
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// finishToggle settles an enable write after the shell reports back on the main
// thread: success and failure both return the switch to its resting face.
func (a *App) finishToggle(id string) {
	if a.toggleBusy != nil {
		delete(a.toggleBusy, id)
	}
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

func (a *App) installedIntegrations() []Integration {
	if a.Integrations == nil {
		return nil
	}
	return a.Integrations()
}

// shortcuts lists the shortcuts the app answers, with the key each one
// currently holds and a recorder for the one the app can change.
func (a *App) shortcuts(c *ui.Context, copy i18n.Settings) {
	a.pageColumn(c, func() {
		// A refused recording is the first thing the user reads, above the
		// page's own groups (the old page's static save alert).
		a.shortcutRejectedAlert(c, copy)
		// The group title row carries the group's own action, as the reference's
		// pane did: "Restore defaults" beside the title, in the accent-text
		// idiom, and it really resets.
		a.sectionWithAction(c.Key("shortcuts.summon"), copy.ShortcutsToggle, copy.ShortcutsHint,
			copy.ShortcutsReset, func() {
				if a.Actions.ResetShortcuts != nil {
					// Like starting a recording, an explicit reset begins a new
					// attempt even when the stored map is already the default.
					a.rejectedShortcut = ""
					a.observeSettingsWrite(a.Actions.ResetShortcuts)
					if a.Actions.ShortcutRefused != nil && a.Actions.ShortcutRefused(settings.ShortcutToggleWindow) {
						a.rejectedShortcut = settings.ShortcutToggleWindow
					}
				}
			}, func() {
				a.card(c, func() {
					a.shortcutRow(c, copy)
				})
			})
		a.section(c.Key("shortcuts.app"), copy.ShortcutsApp, copy.ShortcutsAppHint, func() {
			a.card(c, func() {
				for _, action := range settings.ShortcutActions {
					if action == settings.ShortcutToggleWindow {
						continue // the summon key has its own card above
					}
					a.shortcutMapRow(c, copy, action)
				}
			})
		})
		a.customSection(c.Key("shortcuts.custom"), copy)
	})
}

// shortcutMapRow is one of the app's own keys: its name, its binding, and a
// recorder that rebinds that action. A recording the page refused carries the
// reference's warning under the name.
func (a *App) shortcutMapRow(c *ui.Context, copy i18n.Settings, action string) {
	a.rowNote(c, copy.ShortcutNames[action], "", a.shortcutWarning(action, copy), func() {
		a.shortcutControl(c, copy, action, a.binding(action))
	})
}

// shortcutWarning is the reference's `settings.shortcut.rejected`, drawn in the
// row whose recording was refused (the page draws the same sentence at its top,
// as `src/settings/ShortcutsPage.tsx:382,404-406` did).
func (a *App) shortcutWarning(action string, copy i18n.Settings) string {
	if a.rejectedShortcut == action || (action == settings.ShortcutToggleWindow && a.SummonUnavailable) {
		return copy.ShortcutRejected
	}
	return ""
}

// binding is one action's accelerator, from the settings.
func (a *App) binding(action string) string {
	return settings.Shortcut(a.settings(), action)
}

// shortcutRow is one shortcut: its name, its keys, and the recorder.
func (a *App) shortcutRow(c *ui.Context, copy i18n.Settings) {
	a.rowNote(c, copy.ShortcutsToggle, "", a.shortcutWarning(settings.ShortcutToggleWindow, copy), func() {
		a.shortcutControl(c, copy, "", a.summonShortcut())
	})
}

// shortcutControl is a row's trailing slot: the recorder while the action is
// being recorded (capturing the next chord, Escape to give up), the current
// keys and the Record button otherwise.
func (a *App) shortcutControl(c *ui.Context, copy i18n.Settings, action, value string) {
	t := c.Theme()
	id := action
	if id == "" {
		id = settings.ShortcutToggleWindow
	}
	recordedID := a.ShortcutID
	if recordedID == "" {
		recordedID = settings.ShortcutToggleWindow
	}
	recording := a.recording && recordedID == id
	if recording {
		// The armed recorder: the same control face as the resting one, plus
		// the accent ring and the accent prompt — the one state in this page
		// where an accent ring is allowed, because the user *is* aiming a key
		// at it (§6.1 第 10 条).
		//
		// P8-b 重定基线：`RaisedQuiet` 不透面 → `Control`（与静息同一档面），
		// 只多一圈 accent 环；一个不透明的抬起面会读成第二个材质（§1）。
		tokens := a.tokens(c)
		capture := ui.Box(c).Focusable().Padding(t.Space(1), t.Space(2)).Radius(tokens.RadiusSM).
			Background(tokens.Control).Border(1, t.Accent).Label(copy.ShortcutRecording)
		capture.Children(func() {
			ui.Text(c, copy.ShortcutRecording).FontSize(t.FontSize).TextColor(t.Accent)
		})
		capture.HandleInput(func(ev ui.InputEvent) bool {
			if ev.Kind != ui.InputKeyDown {
				return false
			}
			// Escape gives up the recording, but only a bare Escape: a modified
			// Escape is a chord the user may want to record (the old build's
			// `if (event.key === "Escape" && bare) onCancel()`).
			if ev.Key == ui.KeyEscape && ev.Mods == 0 {
				a.recording = false
				return true
			}
			accelerator, ok := shortcuts.FromKey(ev.Mods, ev.Key)
			if !ok {
				return true // a key without a modifier is not a shortcut
			}
			a.recording = false
			id := action
			if id == "" {
				id = settings.ShortcutToggleWindow
			}
			a.recordShortcut(id, accelerator)
			return true
		})
		capture.Focus()
		return
	}
	// The reference's `.shortcut-recorder` (`settings.css:1198-1224`): a
	// resting control pane (82u × 27u, `--glass-control` fill, 1px
	// `--glass-control-edge` border, `--radius-sm` corner, `--elev-0` lens)
	// showing the current chord in the monospace stack
	// (`.shortcut-recorder__keys`, `:1238-1242`). The old port drew bare
	// text and a separate Record button, so the row's trailing slot had no
	// bordered control the reference put there.
	a.shortcutRecorder(c, copy.ShortcutRecord, shortcuts.Display(value), func() {
		a.customRecording = false
		a.recording, a.ShortcutID = true, action
		// A fresh attempt clears its own refusal, not another row's.
		if a.rejectedShortcut == id {
			a.rejectedShortcut = ""
		}
	})
}

// shortcutRecorder is the recorder's resting control pane: an 82u-wide,
// 27u-tall control on the resting `Control` face under the `ControlEdge`
// hairline, in the secondary ink. Hover lifts the fill to `ControlHover` and
// the ink to `TextStrong`; press drops it to `ControlPress`. The recorded
// chord is set in the reference's monospace stack (`.shortcut-recorder__keys`),
// the one face where the reference itself breaks the app's proportional font.
// The button carries the reference's `aria-label`
// (`settings.shortcut.record`) and its focus-visible ring.
//
// P8-b 重定基线：旧 hover 把边抬到 `t.Accent` → 合约 §6.1 第 10 条「静息用
// `Control`，只有录制中才用 accent 环」。accent 在本页只有两处法定用途
// （侧栏前导图标、主 CTA，§5），一个悬停的静息控件不是第三处：悬停只抬
// **面**与**字**，不抬色相。
func (a *App) shortcutRecorder(c *ui.Context, aria, label string, clicked func()) ui.Element {
	t := c.Theme()
	tokens := a.tokens(c)
	button := ui.Row(c).Focusable().Label(aria).MinWidth(t.Space(18)).MinHeight(max(28, t.Space(8))).
		Padding(0, t.Space(2.5)).Radius(tokens.RadiusSM).AlignItems(ui.Center).Justify(ui.Center).
		Background(tokens.Control).Border(1, tokens.ControlEdge).FocusRing(true).
		// P13-gv（`docs/liquid-glass.md` §6.169）：录制钮的三个 rung 只换面，而它
		// 此前**一帧跳过去**（实测 `f0 == f60 == f400`），同页的 `pageButton`、
		// 侧栏行、`barButton` 都在 120ms 里走完。§5 第一行只给一个速度。
		Transition(ui.ElementTransition{Colors: true, Duration: theme.ColorStep})
	// P13-l（`docs/liquid-glass.md` §6.2b 第 9-13 行）：这枚按钮此前停在 P12-c 第
	// 2-4 行点名的那个状态——「一块被画框圈住的平涂」。它是**面**，不是槽：外圈
	// `ControlEdge` 是它与卡片之间那道线，`LitFace` 补的是 E1 缺的那一对内线
	// （顶 `LensRim` / 底 `LensEdge`）。三个 rung 共用这一对线，hover 与 press 只
	// 换面（与 `uninstall.go` 的 `uninstallPartRow` 同一写法）；`FocusRing` 是状
	// 态，不是材质，位置与粗细都不动。
	tokens.LitFace(button)
	ink := tokens.TextSecondary
	if button.Hovered() {
		button.Background(tokens.ControlHover)
		ink = tokens.TextStrong
	}
	if button.Pressed() {
		button.Background(tokens.ControlPress)
	}
	button.Children(func() {
		ui.Text(c, label).Font(deepLinkValueFont).FontSize(t.FontSize).TextColor(ink).SingleLine().Shrink(1).MinWidth(0)
	})
	if label != "" && label != "-" {
		button = tokens.Tip(c, button, label)
	}
	if button.Clicked() {
		clicked()
	}
	return button
}

// recordShortcut applies a chord the recorder captured. The map's own rule
// decides: another action already answering for the chord is refused and the
// page says so instead of writing it, re-recording an action's own chord is no
// change at all, and only a new binding reaches the shell (the old build's
// `capture`, `src/hooks/useShortcutCapture.ts:112-136`).
func (a *App) recordShortcut(action, accelerator string) {
	switch settings.ShortcutRecordingOf(a.Store.Snapshot(), action, accelerator) {
	case settings.ShortcutRecorded:
		if a.rejectedShortcut == action {
			a.rejectedShortcut = ""
		}
		if a.Actions.SetShortcut != nil {
			a.observeSettingsWrite(func() { a.Actions.SetShortcut(action, accelerator) })
			// The map has already accepted the chord; the system may still
			// refuse it (another app holds it). The shell keeps the old key
			// in that case and writes nothing, so the row says the
			// reference's sentence rather than leaving a chord on screen
			// that nothing answers.
			if a.Actions.ShortcutRefused != nil && a.Actions.ShortcutRefused(action) {
				a.rejectedShortcut = action
			}
		}
	case settings.ShortcutRefused:
		a.rejectedShortcut = action
	default:
		if a.rejectedShortcut == action {
			a.rejectedShortcut = ""
		}
	}
}

// updateRow is the About page's update row: the version line the old
// AboutPage drew (`Current version: v…`), the state that follows it, and the
// one control the state offers. The state machine is the old build's:
//
//	progress  → the byte bar and its readout
//	downloading → a disabled "Installing…" button
//	failed    → a "Retry" button
//	available → a "Download" button
//	otherwise → no control
//
// The build's no-feed state has no old-build counterpart; it keeps the row and
// says so in the sublabel rather than pretending an update was checked.
func (a *App) updateRow(c *ui.Context, copy i18n.Settings) {
	state := a.Update
	sublabel := copy.UpdateUpToDate
	// P13-dk（`docs/liquid-glass.md` §6.80）：这一行此前把状态字当副标题画
	// （`t.TextMuted` / body / 500），于是「已是最新」和「更新失败，重试？」在
	// 像素上是同一档墨（浅 101 / 深 94 级）—— 更新行唯一会变的那句话，是行上
	// 最安静的字。三档：没事（安静）、有个版本可取（事实）、坏了（意思，允许色相）。
	ink := rowInkQuiet
	switch {
	case state.Disabled:
		sublabel = copy.UpdateDisabled
	case state.Failed:
		sublabel = copy.UpdateFailedRetry
		ink = rowInkWarning
	case state.Available:
		sublabel = copy.UpdateLatestVersion + ": v" + state.Version
		ink = rowInkFact
	}
	a.rowState(c, copy.UpdateCurrentVersion+": v"+a.About.Version, sublabel, ink, func() {
		switch {
		case state.Progress != nil:
			a.updateProgress(c, state.Progress)
		case state.Downloading:
			a.updateButton(c, copy.UpdateInstalling, true, nil)
		case state.Failed:
			a.updateButton(c, copy.UpdateRetry, false, a.Actions.InstallUpdate)
		case state.Available:
			a.updateButton(c, copy.UpdateDownload, false, a.Actions.InstallUpdate)
		}
	})
}

// updateButton is the About page's one accent control: the accent fill with
// `--accent-contrast` ink, the lit top rim (`inset 0 1px 0`), the emphasis step
// at 600, and no keyline at all. Hover fades the whole button to 0.9; a disabled
// face turns the crown off and keeps the framework's one 0.5 fade (P13-aq — the
// reference's `.6` was drawn on top of it, effective 0.3, `docs/liquid-glass.md`
// §6.2b-6), with the pointer refused. It is the one thing on the page the user
// presses, so it is the page's whole accent budget (§5 第 2 条).
//
// P8-b 重定基线：`Radius(a.tokens(c).RadiusSM)` 胶囊 → `RadiusSM`(8) 圆角矩形。accent 填充保留；
// 合约的 CTA 是一个圆角按钮，不是药丸（§6.1 第 9 条），半径从半径梯上取字面值，
// 不用 `Space()`——一个角不随 `--ui-scale` 走（§2）。
func (a *App) updateButton(c *ui.Context, label string, disabled bool, run func()) {
	tokens := a.tokens(c)
	t := c.Theme()
	button := ui.ButtonBase(c).Label(label).
		MinHeight(max(28, t.Space(8))).Padding(t.Space(1), t.Space(3)).Radius(tokens.RadiusSM)
	// P13-bc：面、边、冠线与按下几何走 accent 主 CTA 的同一处定义
	// (`accentPrimaryFace`)。这里此前是 `if Hovered() { .Opacity(0.9) }`——淡的是
	// **整棵子树**（面 + 冠线 + 墨），于是「可以被碰」的那条线在指针落上去的那一刻
	// 自己熄了一半；而同一个淡在两种外观上方向相反（浅色淡向 247 的地面变亮、
	// 深色淡向 14 变暗），因为透明度是相对脚下的地面解析的。
	button = a.accentPrimaryFace(c, button, disabled)
	button.Children(func() {
		ui.Text(c, label).FontSize(tokens.Emphasis).FontWeight(600).TextColor(t.AccentText)
	})
	if button.Clicked() && !disabled && run != nil {
		run()
	}
}

// UpdateFraction is the share of an update download that is done, between 0
// and 1, and 0 while the feed has not named a total. The About page's own
// track and the system's progress surface (the taskbar button, the Dock icon,
// the launcher entry) read it from here, so the two cannot drift: one download
// has one fraction.
func UpdateFraction(p *UpdateProgress) float64 {
	if p == nil || p.Total <= 0 {
		return 0
	}
	return min(max(float64(p.Downloaded)/float64(p.Total), 0), 1)
}

// updateProgress is the old `.update-banner__progress`: a track with the
// accent bar over it and the tabular readout under it (`42% · 1.5 MB / 3.6 MB`,
// or just the downloaded count when the feed named no total).
func (a *App) updateProgress(c *ui.Context, progress *UpdateProgress) {
	t := c.Theme()
	tokens := a.tokens(c)
	track := t.Space(45)
	fraction := float32(UpdateFraction(progress))
	ui.Column(c).MinWidth(track).Shrink(0).Gap(t.Space(1.25)).Children(func() {
		// `.update-banner__progress-track` is a 4u groove with the ladder's
		// small corner and the track edge as an *inset* keyline
		// (`settings.css:1577-1583`), so the bar rides inside a 1px recess
		// rather than inside a border that grows the box.
		bar := ui.Row(c).Width(track).Height(t.Space(1)).Radius(tokens.RadiusXS).
			Background(tokens.Track)
		bar.InsetShadow(0, 0, 0, 1, tokens.TrackEdge)
		bar.Children(func() {
			if fraction > 0 {
				ui.Box(c).Width(track * fraction).Height(t.Space(1)).
					Radius(tokens.RadiusXS).Background(t.Accent)
			}
		})
		// `.update-banner__progress-label` is the caption step in
		// `--text-secondary` with tabular figures, right-aligned under the
		// track (`settings.css:1592-1599`).
		ui.Text(c, updateProgressLabel(progress)).FontSize(tokens.Caption).
			TextColor(tokens.TextSecondary).TextAlign(ui.End).SingleLine()
	})
}

// updateProgressLabel is the progress readout the old build formatted inline:
// `Math.round(percent)% · formatBytes(downloaded) / formatBytes(total)`, or
// `formatBytes(downloaded)` when there is no total.
func updateProgressLabel(progress *UpdateProgress) string {
	if progress.Total <= 0 {
		return formatBytes(progress.Downloaded)
	}
	percent := int(math.Round(float64(progress.Downloaded) * 100 / float64(progress.Total)))
	if percent > 100 {
		percent = 100
	}
	if percent < 0 {
		percent = 0
	}
	return strconv.Itoa(percent) + "% \u00b7 " + formatBytes(progress.Downloaded) + " / " + formatBytes(progress.Total)
}

// formatBytes is the old AboutPage's `formatBytes`: B/KB/MB/GB, whole bytes,
// one decimal above that, and "0 B" for anything not positive.
func formatBytes(bytes int64) string {
	if bytes <= 0 {
		return "0 B"
	}
	units := []string{"B", "KB", "MB", "GB"}
	value := float64(bytes)
	index := 0
	for value >= 1024 && index < len(units)-1 {
		value /= 1024
		index++
	}
	if index == 0 {
		return strconv.FormatInt(int64(math.Round(value)), 10) + " B"
	}
	return strconv.FormatFloat(value, 'f', 1, 64) + " " + units[index]
}

// about shows the build's identity and where its files live.
func (a *App) about(c *ui.Context, copy i18n.Settings) {
	if a.Actions.CopyText == nil {
		a.copiedLink, a.copiedLinkUntil = "", time.Time{}
	}
	tokens := a.tokens(c)
	about := a.About
	a.pageColumn(c, func() {
		// The build's identity is the panel's own header band (see View); the
		// page's rows carry the same facts in the card the update check acts
		// from.
		a.card(c, func() {
			a.keyValue(c, copy.AboutFramework, about.Framework)
			a.keyValue(c, copy.AboutScheme, about.Scheme)
			a.keyValue(c, copy.AboutSettingsFile, about.SettingsPath)
			if about.RepoURL != "" {
				// P13-dj（`docs/liquid-glass.md` §6.79）：这张卡的第四行是**唯一可点的**
				// 一行，但它此前走的是 `a.row` —— 而 `rowTitle` 把名字硬编码在 emphasis 档
				// （`rows.go:1166` 的 `tokens.Emphasis` / 580 / `TextStrong`）。于是同一列、
				// 相邻四行，名字是两把尺子：前三行 11px / 500 / `TextSecondary`（122 / 115 级），
				// 这一行 15px / 580 / `TextStrong`（**202 / 198 级**），而这个链接自己的墨只有
				// 165 / 140 —— 全卡最重的字属于名字，最轻的字属于事实。
				//
				// 「可点」由**形**与**链接自己的色**说（§6.10：只读/可点不靠字阶分家），
				// 所以名字跟着三行兄弟退到 caption 档，值仍是 `ui.Link` 画在控制槽里。
				// 值的**字阶回到这张卡的一条尺子**（`tokens.Emphasis` / 580，与三条事实的值同
				// 档），颜色仍是链接自己的 `Theme.Accent` —— 强调归色，不归字重。
				// 实测：名字 `202 / 198 → **122 / 115**`（与三行兄弟逐字节相同，`litSum`
				// 三通道，1 级 = 3）；链接墨 `165 / 140` 不动（色号没动），名字盒 `18 → 15`
				// （caption 的行盒），行内容高度由链接自己维持 17。
				a.cardRow(c, ui.Center, nil, rowFace{}, func() {
					ui.Link(c, about.RepoURL, about.RepoURL).FontSize(tokens.Body).FontWeight(400)
				}, func() {
					a.factName(c, copy.AboutProject)
				})
			}
		})
		// The update row lives in its own group, the reference's
		// `settings.group.update` section with its card (`AboutPage.tsx:62-70`):
		// the one control the user presses gets a heading and a card of its own
		// rather than sitting loose beside the build's identity.
		a.section(c, copy.GroupUpdate, "", func() {
			a.card(c, func() {
				a.updateRow(c, copy)
			})
		})
		// The deep-link lines: a URL scheme is invisible when it works and
		// invisible when it does not, so the About page is the one place a
		// user can find out that floter answers `floter://` at all. Copying a
		// line is confirmed on the button itself (the old build's own 1.6s
		// "Link copied"), because a clipboard write is otherwise silent.
		a.sectionInline(c, copy.DeepLinkTitle, copy.DeepLinkHint, func() {
			a.card(c, func() {
				for _, link := range []string{deepLinkConnectExample, deepLinkRegisterExample} {
					link := link
					copied := a.linkCopied(link, c.Now())
					if copied {
						// Keep a frame coming at the moment the confirmation
						// expires, so the button returns to "Copy link" on its
						// own rather than at the next unrelated event.
						c.After(a.copiedLinkUntil.Sub(c.Now()))
					}
					label := copy.DeepLinkCopy
					if copied {
						label = copy.DeepLinkCopied
					}
					a.codeRow(c, link, func() {
						a.actionWithGlyph(c, linkCopyGlyph(copied), label, func() {
							if a.Actions.CopyText != nil {
								a.Actions.CopyText(link)
								a.copiedLink, a.copiedLinkUntil = link, c.Now().Add(linkCopiedDuration)
								if a.Actions.NotifySuccess != nil {
									a.Actions.NotifySuccess(copy.DeepLinkCopied)
								}
							}
						}, a.Actions.CopyText == nil).Bind(&a.linkFocus(c, link).button)
					})
				}
			})
		})
	})
}

// linkCopyGlyph is the mark on a deep-link copy action: lucide's Check while
// the copy's 1.6s confirmation holds, Copy otherwise — the two marks the
// reference's `DeepLinkRow` swapped (`DeepLinkRow.tsx:47-58`).
func linkCopyGlyph(copied bool) string {
	if copied {
		return "check"
	}
	return "copy"
}

// The two `floter://` forms the About page offers. The reference declared
// them once in `src/deep-link.ts` (`DEEP_LINK_EXAMPLE` /
// `DEEP_LINK_REGISTER_EXAMPLE`), and the page copied them; the pair lives here
// so the rendered value and the test that copies it cannot drift.
const (
	deepLinkConnectExample  = "floter://connect?manifest=/path/to/tool.json"
	deepLinkRegisterExample = "floter://register?cmd=rg"
)

// linkCopiedDuration is how long the deep-link copy button keeps its
// confirmation: the old build's own 1600ms.
const linkCopiedDuration = 1600 * time.Millisecond

// linkCopied reports whether the deep-link copy button for value should show
// its confirmation, clearing the state once its window has passed.
func (a *App) linkCopied(value string, now time.Time) bool {
	if a.copiedLink == "" || a.copiedLink != value {
		return false
	}
	if !now.Before(a.copiedLinkUntil) {
		a.copiedLink = ""
		return false
	}
	return true
}

// keyValue is one labeled line of read-only information: the label in a
// fixed column, the value beside it, selectable so it can be copied.
// keyValue is one About row: the label at the start, the selectable value at
// the end.
//
// P13-an 重定基线（`docs/liquid-glass.md` §6.11）：这是一张**事实表**，不是一张设置
// 列表 —— 框架版本、链接协议、设置文件在哪里，没有一行可以按，而且这一页是用户唯一
// 能看到「设置文件到底在哪」的地方。此前它借用设置行的墨语义（`rowTitle`：名字
// `t.FontSize+1` / 580 / `TextStrong`，值塞进控制槽 `t.TextMuted` 500），实测浅色
// 名字 **202** / 值 **101**、深色 **198** / 值 **94** —— 和 P13-ak 的审批记录是同一个
// 反过来的层级：小字说「它是什么」，大字说「这是什么」。
//
// 换过来之后名字是值的**标题**（caption / 500 / `TextSecondary`），值占 emphasis
// （`t.FontSize+1` / 580 / `TextStrong`），实测浅 122 / **202**、深 115 / **198**。
// **只换墨，不换盒子**：仍是 `cardRow` 框架（44px 地板、分隔线、1px 行距、左右两端），
// 值仍是可选中的（用户要能把这条路径复制走），行高与卡片高度逐像素不变。
//
// 为什么不像审批记录那样叠成两行（`factRow`）：这一页的四行（三行事实 + 可点的
// `Project` 链接）共用「左标签 / 右值」这一条语法，叠两行会让第四行成为孤例；
// 而 `rowTitle` 那条路走不通 —— 它把 emphasis 硬编码给了名字。所以这里用 `cardRow`
// 直接画两端，`ui.Center` 让 11px 的名字与 15px 的值落在同一条光轴上（实测两段墨
// 重叠 8/9 与 12/12）。
//
// 名字带 `Ellipsis`：值变宽后标签列更早被挤（640 宽的窗下从 112px 掉到 61px，
// 因为值从 288px 长到 339px），所以窄窗下宁可看到省略号，也不要看到半个字 ——
// 与 `rowValue` 对「程序自己起的名字」用的是同一种截断（见 rowValue 的注释）。
func (a *App) keyValue(c *ui.Context, label, value string) {
	tokens := a.tokens(c)
	if value == "" {
		return
	}
	a.cardRow(c, ui.Center, nil, rowFace{Inert: true}, func() {
		ui.Text(c, value).FontSize(tokens.Body).FontWeight(400).
			TextColor(tokens.TextStrong).Selectable()
	}, func() {
		a.factName(c, label)
	})
}

// fixedRow is the read-only row inside a card of **editable** rows: the
// integration ID the backend minted and the form can only name (R9-3).
//
// P13-do 重定基线（`docs/liquid-glass.md` §6.84）：这一行此前借的是 About 事实表的
// `keyValue`（P13-an §6.11 —— 那张卡上没有一行是按得动的，所以名字退成值的旁注、
// 值占主角）。同一个函数放进一张可编辑的表里，那套层级就反了：标题是 caption
// 9.9/500 /`TextSecondary`，实测 **122** 级（深 **115**），而它下面每一行可编辑的
// 标题是 emphasis 11.8/580 /`TextStrong`，**202**（**198**）—— 同一张卡里差 80 级，
// 第一眼读到的信号是「这一行不属于这张表」；同时 ID 的值是 emphasis/580/strong，
// **202** 级，比它下面每个字段里的字都响。
//
// 现在它按这张表自己的语法画：标题是这张表每一行的标题（`rowTitle` 的 emphasis /
// 580 / `TextStrong`），值是**程序自己起的名**那一档（P13-bt §6.38 `dataRow`：mono
// caption / 500 / `TextMuted` —— 这串标识符和「检测到的程序路径」同类，都是后端写的）。
// 只读的记号只剩结构：这一行没有控件面、没有描边、右边没有可点的槽。
// **只读是一种结构，不是一种墨**（同 §2 对层级的判断）。
//
// 盒子一个像素没动：仍是 44px 地板的 `cardRow`（`rowFace{}`），值仍可选中
// （用户要能把 ID 抄走）。
func (a *App) fixedRow(c *ui.Context, label, value string) {
	tokens := a.tokens(c)
	t := a.cardTheme(c)
	if value == "" {
		return
	}
	a.cardRow(c, ui.Center, nil, rowFace{Inert: true}, func() {
		ui.Row(c).FillHeight().AlignItems(ui.Center).Children(func() {
			ui.Text(c, value).Font(deepLinkValueFont).FontSize(tokens.Caption).
				FontWeight(500).TextColor(t.TextMuted).SingleLine().Selectable()
		})
	}, func() {
		ui.Row(c).FillHeight().AlignItems(ui.Center).Children(func() {
			ui.Text(c, label).FontSize(tokens.Emphasis).FontWeight(580).
				TextColor(tokens.TextStrong).SingleLine().Ellipsis("\u2026")
		})
	})
}

// factName is the name of a read-only fact on a card: the caption that sits over
// its value (P13-ak §1.7's ink order, P13-an for this page).
//
// P13-bs：行的文字列从行内容盒的顶边开始（`cardRow`），而这一行把名字当**旁注**
// ——名字与右边的值读成一行，所以名字要跟着值居中。P13-dj 把这一条从 `keyValue`
// 提出来：身份卡的第四行（`Project` 链接）也要说同一句话，否则它的 caption 会
// 贴在列顶，而三条事实的 caption 在列中心，四行名字差 3.6px。
func (a *App) factName(c *ui.Context, label string) {
	tokens := a.tokens(c)
	ui.Row(c).FillHeight().AlignItems(ui.Center).Children(func() {
		ui.Text(c, label).FontSize(tokens.Caption).FontWeight(500).
			TextColor(tokens.TextSecondary).SingleLine().Ellipsis("\u2026")
	})
}

// runningSessions is what the Sessions page lists.
func (a *App) runningSessions() []Session {
	if a.Sessions == nil {
		return nil
	}
	return a.Sessions()
}

// summonShortcut is the global shortcut the shell registered, or a dash
// while it is unknown (a test build).
func (a *App) summonShortcut() string {
	if a.Shortcut == "" {
		return "-"
	}
	return a.Shortcut
}

// general is the General page: the settings the loader owns, each a real
// control writing straight through the store.
func (a *App) general(c *ui.Context, copy i18n.Settings) {
	s := a.settings()

	a.pageColumn(c, func() {
		a.section(c, copy.GroupAppearance, "", func() {
			a.card(c, func() {
				a.pick(c, copy.Theme, copy.ThemeHint, copy.Themes, s.Theme,
					func(id string) { a.set(func(s *settings.Settings) { s.Theme = id }) })
				a.pick(c, copy.Language, copy.LanguageHint, copy.Languages, s.Language,
					func(id string) { a.set(func(s *settings.Settings) { s.Language = id }) })
				// R7-13c · the interface size sits in Appearance next to
				// theme/language because it is the same kind of choice — how the
				// interface looks — not a window behaviour: it scales the whole
				// UI wherever the window is, and it keeps working when the window
				// never hides. It was in the Window behaviour card, a group it has
				// nothing in common with.
				a.pick(c, copy.Scale, copy.ScaleHint, copy.Scales, s.UIScale,
					func(id string) { a.set(func(s *settings.Settings) { s.UIScale = id }) })
			})
		})

		a.section(c, copy.GroupWindow, "", func() {
			a.card(c, func() {
				a.checkbox(c, copy.LaunchAtStartup, copy.LaunchAtStartupHint, s.LaunchAtStartup,
					func(on bool) { a.set(func(s *settings.Settings) { s.LaunchAtStartup = on }) })
				a.checkbox(c, copy.HideOnBlur, copy.HideOnBlurHint, s.HideOnBlur,
					func(on bool) { a.set(func(s *settings.Settings) { s.HideOnBlur = on }) })
				// R35/R41 · the page-residency window sits beside `hide_on_blur`
				// because the two are read together but answer different
				// questions: the switch decides whether the *window* disappears,
				// this one decides whether the *surface* survives it. The
				// reference draws it before the recent-items switch, as the
				// single row residencyRow builds (`SurfaceResidencyControl`).
				a.residencyRow(c, copy)
				a.checkbox(c, copy.ShowRecentInLauncher, copy.ShowRecentInLauncherHint, settings.ShowRecentInLauncher(s),
					func(on bool) { a.set(func(s *settings.Settings) { s.SetShowRecentInLauncher(on) }) })
			})
		})

		// The menu bar group: the two controls that describe the one icon the
		// user sees in the menu bar / tray — its visibility switch and the
		// light/dark choice for its image. They share a card because they are
		// one residency choice (`settings.group.menuBar`); splitting the icon
		// into Appearance left the two ends of the same decision a screen apart.
		a.section(c, copy.GroupMenuBar, "", func() {
			a.card(c, func() {
				a.checkbox(c, copy.ShowMenubarIcon, copy.ShowMenubarIconHint, settings.ShowMenubarIcon(s),
					func(on bool) { a.set(func(s *settings.Settings) { s.SetShowMenubarIcon(on) }) })
				a.pick(c, copy.AppIcon, copy.AppIconHint, copy.AppIcons, a.appIcon(),
					func(id string) {
						a.set(func(s *settings.Settings) { s.SetExtra("app_icon", id) })
					})
			})
		})

		a.section(c, copy.GroupTerminal, "", func() {
			a.card(c, func() {
				// The family is a picker of the faces this machine actually has
				// (detected from its font files), plus the current value so a
				// hand-set family is never lost.
				families := make([]i18n.Option, 0, len(terminalui.FontFamilyOptions(s.FontFamily)))
				for _, family := range terminalui.FontFamilyOptions(s.FontFamily) {
					families = append(families, i18n.Option{ID: family, Label: family})
				}
				// The card paints the axes the schema puts on this surface
				// (internal/control, R55): the family, the size, the line height
				// and the palette. The padding, cursor shape and blink rows live
				// in the terminal's own appearance drawer, so the page does not
				// grow a second copy of a control the terminal already owns.
				rows := map[control.AppearanceAxis]func(){
					control.AxisFontFamily: func() {
						a.choose(c, copy.FontFamily, "", families, s.FontFamily,
							func(v string) { a.set(func(s *settings.Settings) { s.FontFamily = v }) })
					},
					control.AxisFontSize: func() {
						// The readout is the reference's `<n> px`, and the row carries
						// the card-only hint (`TerminalAppearance.tsx:190-195`): the
						// settings card shows `sublabel: terminalAppearanceHint` on the
						// font-size row, while the terminal's own drawer keeps it out.
						a.slider(c, sliderRow{
							label: copy.FontSize, description: copy.TerminalHint,
							low: copy.ScaleSmall, high: copy.ScaleLarge,
							value: float64(s.FontSize), lo: settings.MinFontSize, hi: settings.MaxFontSize,
							format: func(v float64) string { return fmt.Sprintf("%d px", int(math.Round(v))) },
							apply: func(v float64) {
								a.previewSetting(func(s *settings.Settings) { s.FontSize = int(math.Round(v)) })
							},
						})
					},
					control.AxisLineHeight: func() {
						// `.toFixed(2)` — the step is 0.05, so one decimal dropped the
						// hundredths the reference shows (`TerminalAppearance.tsx:210-215`).
						a.slider(c, sliderRow{
							label: copy.LineHeight, low: copy.ScaleSmall, high: copy.ScaleLarge,
							value: s.TerminalLineHeight,
							lo:    settings.MinTerminalLineHeight, hi: settings.MaxTerminalLineHeight,
							format: func(v float64) string { return fmt.Sprintf("%.2f\u00d7", v) },
							apply: func(v float64) {
								a.previewSetting(func(s *settings.Settings) { s.TerminalLineHeight = v })
							},
						})
					},
					control.AxisPalette: func() {
						a.paletteRow(c, copy, s.TerminalTheme,
							func(id string) { a.set(func(s *settings.Settings) { s.TerminalTheme = id }) })
					},
				}
				for _, axis := range control.SettingsCardAxes() {
					if row, ok := rows[axis]; ok {
						row()
					}
				}
			})
		})

		// The material group is the reference's *last* General-page section
		// (`GeneralPage.tsx:558`, after the terminal appearance section at
		// `:533`): the glass effect on one card and the two transparency sliders
		// on a second, the group's two explanations drawn as footnotes under both
		// (the reference's `.settings-section__hint` at the end of the section)
		// rather than repeated on every row. It is also the reference's one
		// section spaced looser than the rest — `.settings-section--material`
		// (`settings.css:767-772`), which `sectionMaterial` keeps. The old port
		// drew it second, right under Appearance.
		a.sectionMaterial(c, copy.Material, []string{copy.GlassHint, copy.TransparencyHint}, func() {
			a.card(c, func() {
				a.glassPick(c, copy.Glass, "", copy.GlassSteps, s.GlassStep,
					func(id string) { a.set(func(s *settings.Settings) { s.GlassStep = id }) })
			})
			a.cardLabeled(c, copy.GroupTransparency, func() {
				// A window the system gives no material to has nothing for the
				// desktop to show through (shell.windowShowsMaterial paints the
				// card solid there), so both sliders are drawn disabled with the
				// reason rather than left as knobs that move nothing
				// (「滑块整条失效」).
				disabled := ""
				if !glassmap.TransparencyAvailable(runtime.GOOS, c.Vibrancy()) {
					disabled = copy.TransparencyUnavailable
				}
				lo, hi := glassmap.OpacityRange(c.Preferences().HighContrast, false)
				terminalLo, _ := glassmap.OpacityRange(c.Preferences().HighContrast, true)
				a.slider(c, sliderRow{
					label: copy.MainOpacity, low: copy.TransparencyScaleLow, high: copy.TransparencyScaleHigh,
					value: max(lo, min(hi, float64(s.MainOpacity))), lo: lo, hi: hi, opacity: true,
					format:   func(v float64) string { return copy.Percent(clampPercent(v)) },
					apply:    func(v float64) { a.previewSetting(func(s *settings.Settings) { s.MainOpacity = clampPercent(v) }) },
					disabled: disabled,
				})
				a.slider(c, sliderRow{
					label: copy.TerminalOpacity, low: copy.TransparencyScaleLow, high: copy.TransparencyScaleHigh,
					value: max(terminalLo, min(hi, float64(s.TerminalOpacity))), lo: terminalLo, hi: hi, opacity: true, terminal: true,
					format: func(v float64) string { return copy.Percent(clampPercent(v)) },
					apply: func(v float64) {
						a.previewSetting(func(s *settings.Settings) { s.TerminalOpacity = clampPercent(v) })
					},
					disabled: disabled,
				})
			})
		})
	})
}

// pick builds one labeled segmented choice: options[i].Label stands for
// options[i].ID. The reference draws every segmented row stacked
// (`GeneralPage.tsx:340,356,382,516,568` and `TerminalAppearance.tsx:388`), so
// the choice sits on its own full-width line under the label rather than in a
// trailing slot.
func (a *App) pick(c *ui.Context, label, description string, options []i18n.Option, current string, apply func(string)) {
	a.pickWith(c, a.segmented, label, description, options, current, apply)
}

// glassPick shares the short-choice layout with the other settings.
func (a *App) glassPick(c *ui.Context, label, description string, options []i18n.Option, current string, apply func(string)) {
	a.pickWith(c, a.glassSegmented, label, description, options, current, apply)
}

// pickWith is the one body `pick` and `glassPick` share; draw is the segmented
// form that carries the labels (base or glass).
func (a *App) pickWith(c *ui.Context, draw func(*ui.Context, []string, int, func(int)), label, description string, options []i18n.Option, current string, apply func(string)) {
	index := optionIndex(options, current)
	labels := make([]string, len(options))
	for i, option := range options {
		labels[i] = option.Label
	}
	// Allow enough width for every translated label plus the shared control's
	// inset, borders and gaps. The row wraps this whole group when necessary.
	t := c.Theme()
	choiceWidth := float32(2) + t.Space(1) + t.Space(0.5)*float32(max(0, len(labels)-1))
	for _, label := range labels {
		w, _ := c.MeasureText(0, ui.Span{Text: label, Size: a.tokens(c).Body, Weight: 400})
		choiceWidth += float32(math.Ceil(float64(w))) + t.Space(4) + 2
	}
	choiceWidth = max(200, t.Space(55), choiceWidth)
	chosen := ""
	a.rowAligned(c, ui.Center, nil, rowFace{WrapControls: true}, label,
		[]rowLine{{Text: description}}, "", func() {
			ui.Column(c).Width(choiceWidth).Shrink(0).Children(func() {
				draw(c, labels, index, func(i int) {
					if i >= 0 && i < len(options) {
						chosen = options[i].ID
					}
				})
			})
		})
	if chosen != "" {
		apply(chosen)
	}
}

// segmented is the reference's inline segmented control, drawn from the one
// shared implementation (`control.Segmented`) so the terminal's appearance
// drawer cannot drift into a second shape for the same choice. Its callers are
// the stacked rows (the settings picks and the plugin-sheet radio), where the
// reference's control spans the row, so it takes the full-width form.
func (a *App) segmented(c *ui.Context, labels []string, current int, apply func(int)) {
	control.SegmentedFill(c, a.tokens(c), labels, current, apply)
}

// glassSegmented is `segmented` for the material picker: the reference's one
// centered track (`.glass-intensity__segments`).
func (a *App) glassSegmented(c *ui.Context, labels []string, current int, apply func(int)) {
	control.SegmentedGlassFill(c, a.tokens(c), labels, current, apply)
}

// choose builds one labeled drop-down choice, for lists too long to line up
// as segments.
func (a *App) choose(c *ui.Context, label, description string, options []i18n.Option, current string, apply func(string), below ...func()) ui.Element {
	labels := make([]string, len(options))
	values := make([]string, len(options))
	selected := current
	for i, option := range options {
		labels[i] = option.Label
		values[i] = option.ID
	}
	chosen, picked := "", false
	var trigger ui.Element
	a.row(c, label, description, func() {
		e := a.chooseSelect(c, &selected, labels, label, values)
		trigger = e
		if e.Changed() {
			for _, option := range options {
				if option.ID == selected {
					chosen = option.ID
					picked = true
					break
				}
			}
		}
	}, below...)
	// P13-gu：`picked` 取代了 `chosen != ""` 这条守卫。ID 是调用方给的身份，
	// 空串是合法的一个（「不设置」/「off」那一档就是空值），而旧写法把「选了
	// 一个 ID 为空串的选项」当成「没有选」——点击落了地，回调却一次都没发，
	// 下拉框显示新值而设置没变。现在只有「真的选到了某一项」才派发。
	if picked {
		apply(chosen)
	}
	return trigger
}

// chooseSelect builds the drop-down `choose` draws: the framework's Select at
// the surface's own metric. The extension panel's `.extension-config-field
// input, select` share one literal box (`extensions.css:2402-2417`), so inside
// `extensionMetrics` the trigger is pinned to that box and does not follow the
// interface step; on the settings pages, where `cardUnit` is zero, it keeps the
// framework's `--u` metrics and scales, as the reference's own fields did.
//
// Both faces are the reference's *field* rung, not the framework's control
// rung: `.settings-select` (`settings.css:919-940`) and
// `.extension-config-field select` (`extensions.css:2402-2417`) both paint
// `--glass-field` under `--glass-field-shadow`, so the trigger wears
// `fieldFace` rather than the opaque `--glass-control` the framework's own
// Select draws.
func (a *App) chooseSelect(c *ui.Context, selected *string, labels []string, label string, ids ...[]string) ui.Element {
	values := labels
	if len(ids) > 0 {
		values = ids[0]
	}
	enabled := len(values) > 0
	e := valueSelect(c, selected, labels, values, *selected, a.tokens(c), enabled).Label(label).Radius(a.tokens(c).RadiusSM)
	// Keep long font names within the row and let their labels ellipsize.
	e = e.Width(220).MinWidth(0).Shrink(1)
	if a.cardUnit > 0 {
		e = e.MinHeight(36).Padding(7, 12)
	}
	return a.fieldFace(c, e, enabled)
}

// paletteRow is the terminal palette row: the labeled picker, with a
// miniature terminal painted in the chosen palette's own colors under it
// (R43: the user asked a palette to show what it does). The preview is a block
// in the row, never an overlay, and `inherit` follows the app's appearance.
func (a *App) paletteRow(c *ui.Context, copy i18n.Settings, current string, apply func(string)) {
	options := copy.Palettes
	labels := make([]string, len(options))
	values := make([]string, len(options))
	for i, option := range options {
		labels[i] = option.Label
		values[i] = option.ID
	}
	selected, fallback := current, current
	chosen := ""
	// No sublabel: the reference's palette row is `stacked: true` with no
	// hint (the card-only `terminalAppearanceHint` belongs to the font-size
	// row alone, `TerminalAppearance.tsx:194,272-276`). Its control is one
	// full-width line, not a trailing slot: the reference's `.terminal-palette`
	// splits the select and the preview apart (`settings.css:871-878`).
	a.stackedRow(c, copy.Palette, "", func() {
		ui.Row(c).FillWidth().Justify(ui.SpaceBetween).AlignItems(ui.Center).Children(func() {
			// 220 与同卡片上那一枚字体族 picker 同源、同规则（`chooseSelect`，§6.133）：
			// 它是**地板**不是上限。此前这一枚写的是 `Width(220)`，于是同一张卡上
			// 两枚 picker 的宽度来自两个不同的地方——一枚跟着内容长，一枚钉死；
			// 出厂的九个调色板名都装得下，所以两者碰巧画成同一个盒子，靠的是
			// 巧合而不是规则（§6.134）。
			// 地板之上还需要一个天花板（§6.135）：这一行有两个孩子——picker 与
			// 预览块。预览块是 `Shrink(0)` 的固定列（`Space(37)`），picker 此前既不
			// 收缩也不封顶，于是值一长它就一路把预览块顶出卡外（实测 default 台阶
			// 55 字 +5.0、75 字 +124.0，large 台阶 75 字 +186.6；120 字时预览块的盒子
			// 落在 x=808，720 宽的窗口里已经画不出来了）。`Shrink(1)` 让它先借标签列
			// 的地、借完了就在自己的盒子边收口（框架的省略号），预览块一个像素不挪。
			e := a.fieldFace(c, valueSelect(c, &selected, labels, values, fallback, a.tokens(c), len(labels) > 0).
				Label(copy.Palette).MinWidth(220).Shrink(1).Radius(a.tokens(c).RadiusSM), true)
			if e.Changed() {
				chosen = selected
			}
			// The preview follows the picker in the same frame the choice is
			// made, so a click on the select repaints the block immediately.
			shown := current
			if chosen != "" {
				shown = chosen
			}
			a.palettePreview(c, copy, shown)
		})
	})
	if chosen != "" {
		apply(chosen)
	}
}

// palettePreview paints the miniature terminal: three lines of static text in
// the palette's own background and text, the middle line behind its selection
// tint and a block cursor at the end — the reference's
// `.terminal-palette-preview`, which costs no canvas and no PTY. It keeps the
// drawer's own fixed width so the picker and the block share one line.
func (a *App) palettePreview(c *ui.Context, copy i18n.Settings, name string) {
	terminalui.PalettePreview(c, a.tokens(c), name, copy.PalettePreview, c.Theme().Space(37))
}

// sliderRow is one range row's content: its words, its axis, its value, what a
// change does, and — when the row cannot be moved — the sentence that says why.
// It is a struct rather than nine positional arguments because the two
// transparency rows are the only ones that can be disabled, and a bare string
// in the middle of a call is the kind of argument a later reader silently
// shifts.
type sliderRow struct {
	label, description string
	// low and high are the axis' own words at the track's two ends; when both
	// are empty the scale line is not drawn rather than inventing an axis.
	low, high     string
	value, lo, hi float64
	format        func(float64) string
	apply         func(float64)
	// disabled, when set, is why the row cannot be moved: the track is drawn
	// disabled and the sentence is printed under it. It is what a window the
	// system gives no material to shows instead of a knob that moves nothing.
	disabled string
	opacity  bool
	terminal bool
}

// slider builds one stacked row: the label and its live readout on the title
// line, the hint under them, the track at full width, and one word at each end
// of the track naming the axis — the reference's `.settings-slider__head` +
// `SettingsScale` shape (the macOS range row).
func (a *App) slider(c *ui.Context, row sliderRow) {
	tokens := a.tokens(c)
	t := c.Theme()
	inset := a.rowInset(t)
	v := row.value
	chosen := false
	first := a.cardRows == 0
	a.cardRows++
	ui.Column(c).FillWidth().Children(func() {
		if !first {
			ui.Box(c).FillWidth().Height(1).Background(tokens.Hairline).MarginX(inset).Shrink(0)
		}
		// P13-ew（`docs/liquid-glass.md` §6.118）：一个滑块行里有**三对**，此前只有一条缝。
		// 标题与它的提示是一句话（`rowLineGap()`，与 trailing / stacked 行同一条）；轨道与
		// 命名它两端的两个词是**一件东西**（也是 `rowLineGap()`）；只有「那句话 → 轨道」与
		// 「轨道组 → 原因句」这两对，第二件是可以按的面 / 这一行的状态陈述，才吃满 `Space(2)`。
		// 旧账：五件之间全是 `Space(1)`，实测轨道→轴词读 13-14px，比轴词→原因句的 10px 还远
		// ——轴词成了下一段的开头，而不是轨道的两端。
		ui.Column(c).FillWidth().Gap(t.Space(2)).Padding(t.Space(2.25), inset).Children(func() {
			ui.Column(c).FillWidth().Gap(a.rowLineGap()).Children(func() {
				// The title line carries the value, pushed to the far end, as the
				// reference's `.settings-slider__head` does: the number is a readout,
				// not a second control, and a rolling counter is how the motion
				// system shows a value changing in place. Its label is the row's own
				// emphasis step (`.settings-row__label`), the readout the body step
				// (`.terminal-setting-control__value`).
				ui.Row(c).FillWidth().AlignItems(ui.Center).Justify(ui.SpaceBetween).Children(func() {
					ui.Text(c, row.label).FontSize(tokens.Body).FontWeight(400).TextColor(tokens.TextStrong)
					// P13-bf（`docs/liquid-glass.md` §6.25）：这个读数**退了**，但只在
					// 禁用那一档。§1 的「槽」读法是「整块退一半、内线各留一半」——轨道
					// 已经退了（实测浅色 209 → 219、深色 58 → 49），可这个数字与行名
					// 只差 10 级（浅 37 对 27、深 227 对 237），是整行里唯一没退的东西。
					// 一个不会动的读数不该和它的名字一样「活着」。可用行一个像素不动。
					ink := tokens.TextStrong
					if row.disabled != "" {
						ink = tokens.TextSecondary
					}
					ui.Text(c, row.format(v)).FontSize(t.FontSize).TextColor(ink).
						ContentTransition(ui.ContentTransition{Numeric: true})
				})
				if row.description != "" {
					ui.Text(c, row.description).FontSize(tokens.Caption).TextColor(t.TextMuted)
				}
			})
			// The track and the two words that name its ends are one object: the
			// words are the track's own scale, so they sit in the row's tightest
			// seam, not one step away from it.
			ui.Column(c).FillWidth().Gap(a.rowLineGap()).Children(func() {
				track := ui.Slider(c, &v, row.lo, row.hi).FillWidth().Label(row.label)
				if row.opacity {
					track.Step(1)
				}
				if row.disabled != "" {
					track.Disabled(true)
				}
				if track.Changed() {
					if row.opacity && track.Pressed() {
						v = glassmap.SnapOpacity(v, c.Preferences().HighContrast, row.terminal)
					}
					chosen = true
				}
				if row.opacity {
					ui.Row(c).FillWidth().Justify(ui.SpaceBetween).Children(func() {
						for i, stop := range glassmap.OpacityStops(c.Preferences().HighContrast, row.terminal) {
							label := row.format(stop)
							if i == 0 {
								label += " · " + row.low
							}
							if i == 2 {
								label += " · " + row.high
							}
							ink := tokens.TextSecondary
							if v == stop {
								ink = t.Accent
							}
							preset := ui.ButtonBase(c).Label(label).MinHeight(28).Padding(2, 5).
								Radius(tokens.RadiusSM).Disabled(row.disabled != "")
							if preset.Pressed() {
								preset.Background(tokens.ControlPress)
								tokens.LitFace(preset)
							} else if preset.Hovered() || v == stop {
								preset.Background(tokens.Control)
								tokens.LitFace(preset)
							}
							preset.Children(func() { ui.Text(c, label).FontSize(tokens.Caption).TextColor(ink) })
							if preset.Clicked() {
								v, chosen = stop, true
								c.DisableAnimations()
								c.Invalidate()
							}
						}
					})
				} else if row.low != "" || row.high != "" {
					// The axis' words are the ladder's caption step, not "body
					// minus two": at the shipped `small` step that offset was 7.9pt,
					// the smallest ink on any page, and the two words that say what
					// the track's ends mean were the hardest thing to read in the
					// row they belong to.
					ui.Row(c).FillWidth().AlignItems(ui.Center).Justify(ui.SpaceBetween).Children(func() {
						ui.Text(c, row.low).FontSize(tokens.Caption).FontWeight(500).TextColor(t.TextMuted)
						ui.Text(c, row.high).FontSize(tokens.Caption).FontWeight(500).TextColor(t.TextMuted)
					})
				}
			})
			if row.disabled != "" {
				// P13-bf（`docs/liquid-glass.md` §6.25）：这是这一行的**状态陈述**——
				// 「为什么这个滑不动」。它此前是全行最淡的一件（`TextTertiary`，实测
				// 浅 142 / 深 110），比它上面解释功能的提示（128 / 133）还轻 14 / 23
				// 级，与 `emptyState`（P8-b，§4.7）钉死的「陈述压过提示」正好相反。
				// 抬到 `TextSecondary` + 580：与禁用读数同档（一行里的两个事实），
				// 但字重更实（它是一句话，不是一个数）。字阶不动——改字阶=改高度链。
				ui.Text(c, row.disabled).FontSize(tokens.Caption).FontWeight(580).TextColor(tokens.TextSecondary)
			}
		})
	})
	if chosen && row.disabled == "" {
		row.apply(v)
		if row.opacity {
			c.DisableAnimations()
			c.Invalidate()
		}
	}
}

// checkbox builds one self-labeling check box in the form's content column:
// the switch of the old panel, in the control this toolkit makes directly
// clickable by its own text. The description is the row's grey second line,
// as every other row kind draws it.
func (a *App) checkbox(c *ui.Context, label, description string, on bool, apply func(bool)) ui.Element {
	value := on
	changed := false
	var toggle ui.Element
	// The label is the row's own (the reference puts it at the start) and
	// the control is the switch at the end, so the check box here is the
	// switch alone.
	if a.row(c, label, description, func() {
		toggle = a.switchControl(c, &value).Label(label)
		if toggle.Changed() {
			changed = true
		}
	}) {
		// The row's own label is a hit target: clicking it toggles, as the
		// framework's Field does for its control.
		value = !value
		changed = true
	}
	if changed {
		apply(value)
	}
	return toggle
}

// appIcon is the stored app icon, normalized to the two the app ships (dark
// is the default). The rule is `valuedomain.NormalizeAppIcon`, the same one the
// tray reads when it picks the artwork.
func (a *App) appIcon() string {
	value, _ := a.settings().Extra()["app_icon"].(string)
	return valuedomain.NormalizeAppIcon(value)
}

// set writes one settings change through the store. A refused write is not
// silent: the store rolls the change back to its last committed snapshot and
// the banner over the page says the file could not be written.
func (a *App) set(mutate func(*settings.Settings)) {
	// An immediate write also commits anything the debounce is holding, so the
	// two paths cannot disagree about which value is current.
	a.flushSettingsWrites()
	if err := a.Store.Update(mutate); err != nil {
		a.noteSaveFailed()
	}
}

func clampPercent(v float64) uint8 {
	n := uint8(math.Round(v))
	if n < settings.MinWindowOpacity {
		return settings.MinWindowOpacity
	}
	if n > settings.MaxWindowOpacity {
		return settings.MaxWindowOpacity
	}
	return n
}

// parseResidencyDraft reads a typed duration the way the reference's
// `normalizeResidencySeconds(Number(draft))` does: an empty field is zero
// (off), a non-numeric one falls back to the shipped default rather than
// switching the window off, and a real number is clamped onto the domain.
func parseResidencyDraft(text string) uint32 {
	trimmed := strings.TrimSpace(text)
	if trimmed == "" {
		return 0
	}
	n, err := strconv.ParseFloat(trimmed, 64)
	if err != nil || math.IsNaN(n) || math.IsInf(n, 0) {
		return settings.DefaultSurfaceResidencySeconds
	}
	if n == float64(settings.SurfaceResidencyNever) {
		return settings.SurfaceResidencyNever
	}
	return uint32(math.Round(max(0, min(float64(settings.MaxSurfaceResidencySeconds), n))))
}

// residencyPresetSeconds are the select's named steps, the reference's
// `RESIDENCY_PRESET_SECONDS` ladder: every one a value a person says out loud.
// Off and never are separate entries, not members of this list.
var residencyPresetSeconds = []uint32{10, 20, 30, 60, 120}

// residencyCustom is the select's own entry for a duration the presets do not
// name; its value lives in the inline field, committed by the user.
const residencyCustom = "custom"

// residencySelectValue is the select's value for a stored duration: "off", a
// preset's own number as text, "never", or "custom" for anything else — the
// reference's pure mapping (`residencySelectValue`). The select shows this,
// never a second copy of the state.
func residencySelectValue(seconds uint32) string {
	value := settings.NormalizeResidencySeconds(seconds)
	switch value {
	case 0:
		return "off"
	case settings.SurfaceResidencyNever:
		return "never"
	}
	for _, preset := range residencyPresetSeconds {
		if preset == value {
			return strconv.FormatUint(uint64(preset), 10)
		}
	}
	return residencyCustom
}

// residencyFromSelect is the number a choice stands for. ok is false for the
// custom entry (and any id the domain does not know): its value is the inline
// field's, so the caller opens the field rather than writing anything.
func residencyFromSelect(choice string) (uint32, bool) {
	switch choice {
	case "off":
		return 0, true
	case "never":
		return settings.SurfaceResidencyNever, true
	case residencyCustom:
		return 0, false
	}
	n, err := strconv.ParseUint(choice, 10, 32)
	if err != nil {
		return 0, false
	}
	return settings.NormalizeResidencySeconds(uint32(n)), true
}

// residencyCustomSeedSeconds is the number the inline field opens on: a stored
// custom duration seeds the field with itself, so opening "custom" on an
// existing one does not silently reset it; off, a preset and "never" seed the
// shipped default — the least surprising number to edit from
// (`residencyCustomSeedSeconds`). A hand-edited out-of-range value has already
// been clamped by the normalizer, and seeds that clamped number.
func residencyCustomSeedSeconds(seconds uint32) uint32 {
	value := settings.NormalizeResidencySeconds(seconds)
	if value == 0 || value == settings.SurfaceResidencyNever {
		return settings.DefaultSurfaceResidencySeconds
	}
	for _, preset := range residencyPresetSeconds {
		if preset == value {
			return settings.DefaultSurfaceResidencySeconds
		}
	}
	return value
}

// residencyCustomLabel is the custom entry's label: while a custom duration is
// stored the entry echoes it (`Custom (45 s)`), so the select never lies about
// the number in the field; otherwise it is the plain "Custom…".
func residencyCustomLabel(copy i18n.Settings, value uint32, selectValue string) string {
	if selectValue == residencyCustom {
		return copy.SurfaceResidencyCustomValue(value)
	}
	return copy.SurfaceResidencyCustom
}

// residencyRow paints the page-residency control as one row: the select names
// off, the presets, never and custom, and the inline seconds field (with its
// unit and Set button) appears beside it only while "custom" is chosen — the
// reference's `SurfaceResidencyControl` (`GeneralPage.tsx:157-250`). The row
// never grows a second line for the field.
func (a *App) residencyRow(c *ui.Context, copy i18n.Settings) {
	s := a.settings()
	value := settings.NormalizeResidencySeconds(s.SurfaceResidencySeconds)
	selectValue := residencySelectValue(value)

	// The field's own state. The first frame seeds it from what is stored, so
	// a stored custom duration opens the field it came from; afterwards a value
	// written anywhere else re-seeds the draft while the field is closed, and
	// the user's typing is the draft while it is open (the reference's `useState`
	// initializers plus its re-seeding effect).
	if !a.residencyInit {
		a.residencyInit = true
		a.residencyCustomOpen = selectValue == residencyCustom
		a.residencyDraft = strconv.FormatUint(uint64(residencyCustomSeedSeconds(value)), 10)
	}
	if !a.residencyCustomOpen || !a.residencyEditing {
		a.residencyDraft = strconv.FormatUint(uint64(residencyCustomSeedSeconds(value)), 10)
		a.residencyCustomOpen = selectValue == residencyCustom
	}

	labels := []string{copy.SurfaceResidencyOff}
	choices := []string{"off"}
	for _, preset := range residencyPresetSeconds {
		labels = append(labels, copy.SurfaceResidencyValue(preset))
		choices = append(choices, strconv.FormatUint(uint64(preset), 10))
	}
	labels = append(labels, copy.SurfaceResidencyNever, residencyCustomLabel(copy, value, selectValue))
	choices = append(choices, "never", residencyCustom)

	selected := selectValue
	// Custom is an uncommitted UI choice. Keep it selected while its field
	// is open so reselecting the stored preset can actually dismiss it.
	if a.residencyCustomOpen {
		selected = residencyCustom
	}

	t := c.Theme()
	a.row(c, copy.SurfaceResidency, copy.SurfaceResidencyHint, func() {
		e := a.fieldFace(c, valueSelect(c, &selected, labels, choices, selected, a.tokens(c), true, strconv.FormatUint(uint64(value), 10)).
			Label(copy.SurfaceResidency).Width(200).Radius(a.tokens(c).RadiusSM), true)
		if e.Changed() {
			a.residencyChoice(selected, value)
		}
		if !a.residencyCustomOpen {
			return
		}
		input := a.textInput(c, &a.residencyDraft).Label(copy.SurfaceResidencyCustomLabel).
			Placeholder(copy.SurfaceResidencyCustomUnit).Width(90)
		if input.Changed() {
			a.residencyEditing = true
		}
		ui.Text(c, copy.SurfaceResidencyCustomUnit).FontSize(a.tokens(c).Caption).TextColor(t.TextMuted)
		if input.Submitted() || a.pageButton(c, copy.SurfaceResidencyCustomApply).Clicked() {
			a.commitResidencyDraft()
			if !a.residencyCustomOpen {
				e.Focus()
			}
		}
	})
}

// residencyChoice applies one select choice: a concrete duration is written
// through and closes the field; "custom" opens the field on the seed and
// writes nothing until the user commits.
func (a *App) residencyChoice(choice string, stored uint32) {
	next, ok := residencyFromSelect(choice)
	if !ok {
		a.residencyDraft = strconv.FormatUint(uint64(residencyCustomSeedSeconds(stored)), 10)
		a.residencyCustomOpen = true
		a.residencyEditing = true
		return
	}
	a.set(func(s *settings.Settings) { s.SurfaceResidencySeconds = next })
	if a.settings().SurfaceResidencySeconds == next {
		a.residencyCustomOpen = false
		a.residencyEditing = false
	}
}

// commitResidencyDraft writes the inline field's duration: it normalizes the
// typed text, echoes the stored number back into the field, and closes the
// field when that number lands on a named entry — the reference's commitCustom.
func (a *App) commitResidencyDraft() {
	next := parseResidencyDraft(a.residencyDraft)
	a.set(func(s *settings.Settings) { s.SurfaceResidencySeconds = next })
	if a.settings().SurfaceResidencySeconds != next {
		return
	}
	a.residencyDraft = strconv.FormatUint(uint64(next), 10)
	a.residencyCustomOpen = residencySelectValue(next) == residencyCustom
	if !a.residencyCustomOpen {
		a.residencyEditing = false
	}
}

func optionIndex(options []i18n.Option, id string) int {
	for i, option := range options {
		if option.ID == id {
			return i
		}
	}
	return 0
}

// CustomTool is a local tool the user wants to connect: what the form
// collected. The host mints the id and derives the commands.
type CustomTool struct {
	Name string
	// Mode is "executable" for a program on this machine and "script" for a
	// provider the host writes from the editor below.
	Mode string
	// ScriptLanguage and ScriptContent describe a script tool: the language
	// id (see internal/scriptlang) and the script itself.
	ScriptLanguage string
	ScriptContent  string
	Program        string
	Command        string
	Args           string
	VersionArgs    string
	Version        string
	Description    string
	Output         string
	Permissions    []string
	// Platforms limits the connection to the operating systems it names; the
	// form always sends at least one.
	Platforms []string
	// Params are the inputs the connected tool declares.
	Params []extensions.ParamDefinition
}

// localToolSection is the "connect a program on this machine" form: the words
// that name it, the file itself, its arguments, and what it declares. The
// section is folded away until the user asks for it, so the page stays a list
// of what is installed.
func (a *App) localToolSection(c *ui.Context, copy i18n.Settings) {
	if a.Actions.ConnectLocalTool == nil {
		return
	}
	a.integrationLead += "local:"
	if a.toolFormKey == nil {
		a.toolFormKey = new(int)
	}
	form := a.toolFormKey
	c = c.Key(a.toolFormKey)
	a.section(c, copy.LocalToolTitle, copy.LocalToolHint, func() {
		var add ui.Element
		ui.Row(c).Gap(c.Theme().Space(2)).Children(func() {
			add = a.actionButton(c, copy.LocalToolAdd)
			if !a.toolOpen && a.packageInstallBusy["custom"] {
				a.busyActionButton(c, copy.LocalToolConnect, "connect.custom")
			}
		})
		if a.toolReturnToAdd != nil {
			if a.toolReturnToAdd == a.toolFormKey {
				add.Focus()
			}
			a.toolReturnToAdd = nil
		}
		if add.Clicked() {
			a.toolOpen = !a.toolOpen
			a.toolDisclosure++
			// Opening a fresh form clears the previous refusal, so the new one
			// starts quiet; closing keeps nothing either. It also drops the
			// cached toolchain verdicts: the user may have installed the
			// runtime since the last form.
			if a.toolOpen {
				a.clearScriptRuntimeCache()
			}
			a.toolIssue = false
		}
		if !a.toolOpen {
			a.copiedContent, a.copiedContentValue = "", ""
			a.copiedContentUntil = time.Time{}
			return
		}
		if a.toolPermissions == nil {
			a.toolPermissions = map[string]bool{}
		}
		// A failed request can restore this form while another tool owns focus.
		// Describe rendered layout only; editable values must not reclaim scroll.
		a.integrationLead += "local-open:"
		// A fresh form starts limited to this machine's own platform (R7-5).
		// An edit keeps whatever the integration declares, even nothing: the
		// row then says a platform is required rather than silently inventing
		// one the manifest does not name.
		if a.toolPlatforms == nil {
			a.toolPlatforms = map[string]bool{currentPlatform(): true}
		}
		name, program, command := a.toolName, a.toolProgram, a.toolCommand
		args, versionArgs, version := a.toolArgs, a.toolVersionArgs, a.toolVersion
		description := a.toolDescription
		// The kind of tool decides which rows the form shows: a program on
		// this machine, or a script the host writes from the editor below.
		mode := a.toolMode
		language := a.toolLanguage
		if language == "" {
			language = scriptlang.Languages[0].ID
		}
		script := a.toolScript
		interrupted := false
		// The rules the host will apply, read here first: a row that broke one
		// says so under itself rather than a banner bounced back from the
		// backend. The same function gates the submit, so the two cannot drift.
		issues := customIssues(a.customDraft(name, program, command, args, versionArgs, version, description, mode, language, script))
		a.card(c, func() {
			// R9-3 · the id is minted by the backend and immutable, so when
			// an existing integration is being edited the form names it in a
			// read-only row instead of offering an editable field. A fresh
			// connection has no id yet, so the row is absent.
			if a.toolEditing != "" {
				a.integrationLead += "local-edit:" + strconv.Quote(a.toolEditing)
				a.fixedRow(c, copy.LocalToolId, a.toolEditing)
			}
			a.row(c, copy.LocalToolName, "", func() {
				var nameField ui.Element
				outputFocusOutlet(c.Key("local-name-outlet"), func() {
					nameField = a.extensionField(c, &name, customFieldMetrics).Bind(&a.contentFocus(c, "name").source).Label(copy.LocalToolName).Width(240).Grow(1).Placeholder("Ripgrep")
				}, func() bool {
					// A restored editor already has its own reveal path. Do not
					// turn a later frame into a second scroll after the user moves.
					return nameField.FocusVisible()
				})
			}, func() {
				a.toolIssueUnder(c, copy, issues, extensions.CustomFieldName)
			})
			a.row(c, copy.LocalToolMode, "", func() {
				index := 0
				if mode == routeScript {
					index = 1
				}
				programFocus, scriptFocus := a.contentFocus(c, "mode-program"), a.contentFocus(c, "mode-script")
				var picker ui.Element
				outputFocusOutlet(c.Key("local-mode-outlet"), func() {
					picker = a.segmentedControl(c, &index, copy.LocalToolModeProgram, copy.LocalToolModeScript).
						Label(copy.LocalToolMode).Bind(&programFocus.source).Bind(&scriptFocus.source)
				})
				if picker.Changed() {
					if index == 0 {
						mode = ""
					} else {
						mode = routeScript
					}
				}
				if mode == routeScript {
					if programFocus.restore(c) {
						picker.ScrollIntoView()
					}
				} else {
					if scriptFocus.restore(c) {
						picker.ScrollIntoView()
					}
				}
			}, func() {
				a.toolIssueUnder(c, copy, issues, extensions.CustomFieldMode)
			})
			if mode == routeScript {
				a.scriptRows(c, copy, &language, &script, issues)
			} else {
				a.row(c.Key("local-program"), copy.LocalToolProgram, copy.LocalToolProgramHint, func() {
					pickerFocus := a.contentFocus(c, "choose")
					outputFocusOutlet(c.Key("local-program-outlet"), func() {
						a.rememberModeContent(c, false, a.extensionField(c, &program, customFieldMetrics).Bind(&a.contentFocus(c, "plan").source).Label(copy.LocalToolProgram).Width(240).Grow(1).
							Placeholder(copy.LocalToolProgramPlaceholder).Bind(&pickerFocus.source))
					})
					if a.Actions.ChooseProgram != nil {
						var choose ui.Element
						outputFocusOutlet(c.Key("local-choose-outlet"), func() {
							choose = a.rememberModeContent(c, false, a.actionButton(c, copy.LocalToolChoose).Bind(&pickerFocus.button))
						})
						if choose.Clicked() {
							before := a.toolCallbackState()
							picked, err := a.Actions.ChooseProgram()
							if a.toolCallbackState() != before {
								interrupted = true
								return
							}
							if err != nil {
								if a.Actions.NotifyWarning != nil {
									a.Actions.NotifyWarning(copy.LocalToolFailed)
								}
								pickerFocus.restoreVisible(c)
							} else if picked != "" {
								program = picked
								pickerFocus.restoreVisible(c)
							} else {
								pickerFocus.restoreVisible(c)
							}
						}
					} else {
						pickerFocus.restoreVisible(c)
					}
				})
			}
			a.row(c.Key("local-command"), copy.LocalToolCommand, copy.LocalToolCommandHint, func() {
				a.formFeedbackOutlet(c.Key("local-command-outlet"), a.integrationLead, func() {
					a.extensionField(c, &command, customFieldMetrics).Bind(&a.contentFocus(c, "command").source).Label(copy.LocalToolCommand).Width(160).Placeholder("rg")
				})
			}, func() {
				a.toolIssueUnder(c, copy, issues, extensions.CustomFieldCommand)
			})
			if mode != routeScript {
				a.row(c, copy.LocalToolArgs, copy.LocalToolArgsHint, func() {
					outputFocusOutlet(c.Key("local-args-outlet"), func() {
						a.rememberModeContent(c, false, a.extensionField(c, &args, customFieldMetrics).Label(copy.LocalToolArgs).Width(220).Placeholder("--floter"))
					})
				})
				a.row(c, copy.LocalToolVersionArgs, copy.LocalToolVersionArgsHint, func() {
					outputFocusOutlet(c.Key("local-versionargs-outlet"), func() {
						a.rememberModeContent(c, false, a.extensionField(c, &versionArgs, customFieldMetrics).Label(copy.LocalToolVersionArgs).Width(160).Placeholder("--version"))
					})
				})
			}
			a.row(c.Key("local-version"), copy.LocalToolVersion, copy.LocalToolVersionHint, func() {
				a.formFeedbackOutlet(c.Key("local-version-outlet"), a.integrationLead, func() {
					a.extensionField(c, &version, customFieldMetrics).Bind(&a.contentFocus(c, "version").source).Label(copy.LocalToolVersion).Width(120).Placeholder("0.0.1")
				})
			}, func() {
				a.toolIssueUnder(c, copy, issues, extensions.CustomFieldVersion)
			})
			// R158 · the description is executable-only: a script manifest writes
			// its own internal description and never reads this field, so an
			// editable control here would be silently dropped. The value stays in
			// a.toolDescription, so switching back to executable restores it. R159
			// · the placeholder says a blank field means no description, and the
			// backend stores the honest empty rather than a generated sentence.
			if mode != routeScript {
				a.row(c, copy.LocalToolDescription, "", func() {
					outputFocusOutlet(c.Key("local-description-outlet"), func() {
						a.rememberModeContent(c, false, a.extensionField(c, &description, customFieldMetrics).Label(copy.LocalToolDescription).Width(240).Grow(1).
							Placeholder(copy.LocalToolDescriptionPlaceholder))
					})
				})
			}
			// The content actions sit where the reference put them: after the
			// script box and the fields, before the output row
			// (`CustomIntegrationDrawer.tsx:145-146`).
			if !a.toolContentActions(c, copy, mode, command, program, args, script, language) {
				interrupted = true
				return
			}
			a.row(c.Key("local-output"), copy.LocalToolOutput, "", func() {
				index := 0
				if a.toolOutput == routeBackground {
					index = 1
				}
				var output ui.Element
				a.formFeedbackOutlet(c.Key("local-output-outlet"), a.integrationLead, func() {
					output = a.segmentedControl(c, &index, copy.LocalToolTerminal, copy.LocalToolBackground)
				})
				if output.Changed() {
					if index == 0 {
						a.toolOutput = ""
					} else {
						a.toolOutput = routeBackground
					}
				}
			})
			// The connection is limited to the platforms ticked here, and at
			// least one has to stay ticked: an empty list means "every
			// platform", which is not something the user can ask for by
			// unticking everything by accident. The refusal is named under
			// the row (R7-5).
			ticked := make([]bool, len(customPlatforms))
			for i, platform := range customPlatforms {
				ticked[i] = a.toolPlatforms[platform.ID]
			}
			a.row(c.Key("local-platforms"), copy.LocalToolPlatforms, "", func() {
				ui.Row(c).FillWidth().Gap(c.Theme().Space(3)).Wrap().Children(func() {
					for i, platform := range customPlatforms {
						i, platform := i, platform
						checked := ticked[i]
						var choice ui.Element
						a.formFeedbackOutlet(c.Key(platform.ID), a.integrationLead, func() {
							choice = ui.Checkbox(c, &checked, platform.Label)
						})
						if i == 0 {
							choice.Bind(&a.contentFocus(c, "platforms").source)
						}
						if choice.Changed() {
							if checked {
								a.toolPlatforms[platform.ID] = true
							} else {
								delete(a.toolPlatforms, platform.ID)
							}
						}
					}
				})
			}, func() {
				if len(a.toolPlatforms) == 0 {
					a.integrationLead += "local-platform-required:"
					a.issueUnder(c, copy.LocalToolPlatformRequired)
				}
			})
			// The declaration and audit switches sit behind an "Advanced"
			// disclosure, closed by default: a brand-new integration should not
			// open on a ceremonial list of permission checkboxes, and the note
			// inside says plainly that they isolate nothing (R161). Nothing is
			// unmounted — the ticks live in a.toolPermissions and are read at
			// connect time — so folding changes nothing about what is
			// submitted, and an author who already declared permissions can
			// open the section and edit them.
			var advanced ui.Element
			opened := a.row(c.Key("local-advanced"), copy.LocalToolAdvanced, copy.LocalToolAdvancedPermissions, func() {
				outputFocusOutlet(c.Key("local-advanced-outlet"), func() {
					advanced = a.actionButton(c, copy.LocalToolAdvanced)
				})
				if advanced.Clicked() {
					a.toolAdvanced = !a.toolAdvanced
				}
			}, func() { a.toolPermissionFields(c, copy) })
			if opened {
				a.toolAdvanced = !a.toolAdvanced
				// The row label activates the same disclosure as its button.
				// Keep a keyboard outlet when its permission controls disappear.
				advanced.Focus()
			}
		})
		// A native picker or content callback may have opened another tool
		// while this frame still holds the old field values in local variables.
		if interrupted || a.toolFormKey != form || !a.toolOpen {
			return
		}
		a.toolParamsEditor(c, copy)
		action := copy.LocalToolConnect
		if a.toolEditing != "" {
			action = copy.LocalToolSave
		}
		var submit ui.Element
		a.formFeedbackOutlet(c.Key("local-submit-outlet"), a.integrationLead, func() {
			if a.toolEditing == "" && a.packageInstallBusy["custom"] {
				submit = a.busyActionButton(c, action, "connect.custom")
			} else {
				submit = a.actionButton(c, action)
			}
		})
		requested := submit.Clicked()
		a.toolName, a.toolProgram, a.toolCommand = name, program, command
		a.toolArgs, a.toolVersionArgs, a.toolVersion = args, versionArgs, version
		a.toolDescription = description
		a.toolMode, a.toolLanguage, a.toolScript = mode, language, script
		tool := a.customDraft(name, program, command, args, versionArgs, version, description, mode, language, script)
		if requested {
			// A row that still needs something must not reach the backend: the
			// editor already prints the reason under that row, so the save
			// refuses here rather than bouncing back an error to re-explain it.
			if issues := extensions.ParamRowIssues(a.editorParams()); len(issues) > 0 {
				a.toolIssue = true
				a.focusParamRefusal(c, issues)
				return
			}
			// The same shape rules the host will apply, read before the host
			// sees them: name, command, version, platforms, mode, script.
			if issues := customIssues(tool); len(issues) > 0 {
				a.toolIssue = true
				// Return only on a refused submission, never on background
				// validation while the user is editing another field.
				switch issues[0].Field {
				case extensions.CustomFieldName:
					c.Resolve(a.contentFocus(c, "name").source).Focus().ScrollIntoView()
				case extensions.CustomFieldCommand:
					c.Resolve(a.contentFocus(c, "command").source).Focus().ScrollIntoView()
				case extensions.CustomFieldVersion:
					c.Resolve(a.contentFocus(c, "version").source).Focus().ScrollIntoView()
				case extensions.CustomFieldScript:
					c.Resolve(a.contentFocus(c, "script").source).Focus().ScrollIntoView()
				case extensions.CustomFieldPlatforms:
					c.Resolve(a.contentFocus(c, "platforms").source).Focus().ScrollIntoView()
				case extensions.CustomFieldMode, extensions.CustomFieldLanguage:
					c.Resolve(a.contentFocus(c, "mode-program").source).Focus().ScrollIntoView()
				}
				return
			}
			// The program row has no localization key of its own: it refuses
			// silently, the same way the old form disabled its submit button.
			if tool.Mode != routeScript && tool.Program == "" {
				c.Resolve(a.contentFocus(c, "plan").source).Focus().ScrollIntoView()
				return
			}
			// A missing toolchain does not block the save — the user may install
			// the runtime and come back — but it warns once, so the integration
			// is not silently dead on arrival. The old form awaited the probe
			// before saving so the sentence reflects the machine rather than a
			// race; `scriptRuntimeVerdict` waits for a probe still in flight (it
			// normally already landed) and stays quiet when no probe is wired.
			if tool.Mode == routeScript && a.Actions.NotifyWarning != nil {
				if check, ok := a.scriptRuntimeVerdict(tool.ScriptLanguage); ok &&
					scriptlang.StatusOf(tool.ScriptLanguage, check).State == scriptlang.Missing {
					a.Actions.NotifyWarning(copy.LocalToolRuntimeSaveWarning(scriptlang.Lookup(tool.ScriptLanguage).Label))
				}
			}
			var retired *int
			if a.toolEditing != "" {
				a.Actions.EditCustomTool(a.toolEditing, tool)
			} else {
				a.toolRecover, retired = a.localToolRecovery()
				a.Actions.ConnectLocalTool(tool)
				a.toolRecover = nil
			}
			// The completed submission may have opened the next editor. Only
			// retire the form that actually dispatched this submission.
			if a.toolFormKey != form {
				return
			}
			a.toolOpen = false
			a.toolIssue = false
			a.endEdit()
			if retired != nil {
				a.toolFormKey = retired
				if submit.FocusWithin() {
					a.toolReturnToAdd = retired
				}
			}
		}
	})
}

// customDraft is the form as the draft connection it would submit: one place
// that decides what each field means, so the pre-check and the host's request
// cannot disagree. A non-script carries no language — the field belongs to the
// script runtime, and the form's language state outlives a switch back to the
// program kind (R7-5's old host refused exactly this).
func (a *App) customDraft(name, program, command, args, versionArgs, version, description, mode, language, script string) CustomTool {
	platforms := make([]string, 0, len(customPlatforms))
	for _, platform := range customPlatforms {
		if a.toolPlatforms[platform.ID] {
			platforms = append(platforms, platform.ID)
		}
	}
	permissions := []string{}
	for _, permission := range extensions.AllPermissions {
		if a.toolPermissions[permission] {
			permissions = append(permissions, permission)
		}
	}
	draft := CustomTool{
		Name:        strings.TrimSpace(name),
		Mode:        mode,
		Program:     strings.TrimSpace(program),
		Command:     strings.TrimSpace(command),
		Args:        strings.TrimSpace(args),
		VersionArgs: strings.TrimSpace(versionArgs),
		Version:     strings.TrimSpace(version),
		Description: strings.TrimSpace(description),
		Output:      a.toolOutput,
		Permissions: permissions,
		Platforms:   platforms,
		Params:      a.declaredParams(),
	}
	if mode == routeScript {
		draft.ScriptLanguage = language
		draft.ScriptContent = script
	}
	return draft
}

// customIssues is the backend's own rules, read on the draft as it would be
// submitted: the form shows the same sentences the host would refuse with.
func customIssues(tool CustomTool) []extensions.CustomIssue {
	return extensions.CustomIssues(extensions.CustomRequest{
		Name:           tool.Name,
		Mode:           tool.Mode,
		Command:        tool.Command,
		Version:        tool.Version,
		Platforms:      tool.Platforms,
		ScriptLanguage: tool.ScriptLanguage,
		ScriptContent:  tool.ScriptContent,
	})
}

// toolIssueUnder prints the form's own translation of the first issue that
// belongs to one row, once the user has asked to submit. A field with no issue
// draws nothing.
func (a *App) toolIssueUnder(c *ui.Context, copy i18n.Settings, issues []extensions.CustomIssue, field extensions.CustomField) {
	if !a.toolIssue {
		return
	}
	for _, issue := range issues {
		if issue.Field == field {
			a.integrationLead += "local-issue:" + strconv.Quote(customIssueMessage(copy, issue.Key))
			a.issueUnder(c, customIssueMessage(copy, issue.Key))
			return
		}
	}
}

// toolContentActions draws the form's content actions, the reference's
// `.extension-custom-form__actions` row (`CustomIntegrationDrawer.tsx:145-146`):
// in script mode one "Copy script" and the "Export script" button that writes
// the same text to a file, in program mode "Copy command" and "Copy execution
// plan". Each copy button confirms on itself for 1.6s, because a clipboard
// write is otherwise silent. The value copied is read at press time from the
// form's current draft, so it is what the user sees now rather than what the
// form opened with.
func (a *App) toolContentActions(c *ui.Context, copy i18n.Settings, mode, command, program, args, script, language string) bool {
	// A confirmation ends with its operation group. Returning to the other
	// kind of tool must not revive a copy from before the switch.
	if (mode == routeScript && a.copiedContent != "script") || (mode != routeScript && a.copiedContent == "script") {
		a.copiedContent, a.copiedContentValue = "", ""
		a.copiedContentUntil = time.Time{}
	}
	t := a.cardTheme(c)
	current := true
	a.actionRow(c, func() {
		ui.Row(c).Gap(t.Space(1)).AlignItems(ui.Center).Children(func() {
			if mode == routeScript {
				current = a.contentAction(c, "script", copy.LocalToolCopyScript, copy.LocalToolScriptCopied, script)
				if current {
					current = a.exportScriptAction(c, copy, command, script, language)
				}
				return
			}
			current = a.contentAction(c, "command", copy.LocalToolCopyCommand, copy.LocalToolCommandCopied, strings.TrimSpace(command))
			if current {
				current = a.contentAction(c, "plan", copy.LocalToolCopyPlan, copy.LocalToolPlanCopied,
					executionPlanJSON(program, args))
			}
		})
	})
	return current
}

// exportScriptAction draws the reference's "Export script" button: the second
// half of the script-mode action row, which writes the editor's text to a file
// the user picks (`ExtensionsPanel.tsx:1951-1964`). It is absent when the host
// wired no exporter, and inert while the script is blank — the reference
// mounted it always but the write would have produced an empty file.
func (a *App) exportScriptAction(c *ui.Context, copy i18n.Settings, command, script, language string) bool {
	focus := a.contentFocus(c, "export")
	if a.toolExportDone != nil {
		select {
		case <-a.toolExportDone:
			a.toolExportDone = nil
		default:
		}
	}
	if (a.Actions.ExportScript == nil && a.Actions.ExportScriptAsync == nil) || strings.TrimSpace(script) == "" {
		focus.restoreVisible(c)
		return true
	}
	if a.toolExportDone != nil {
		a.disabledActionButton(c, copy.LocalToolExportScript)
		return true
	}
	if a.rememberModeContent(c, true, a.actionButton(c, copy.LocalToolExportScript).Bind(&focus.button)).Clicked() {
		before := a.toolCallbackState()
		name := scriptExportName(a.toolEditing, command, language)
		if a.Actions.ExportScriptAsync != nil {
			done := make(chan struct{})
			a.toolExportDone = done
			invalidate := a.Actions.Invalidate
			a.Actions.ExportScriptAsync(name, script, func() {
				close(done)
				if invalidate != nil {
					invalidate()
				}
			})
		} else {
			a.Actions.ExportScript(name, script)
		}
		current := a.toolCallbackState() == before
		if current {
			focus.restoreVisible(c)
		}
		return current
	}
	return true
}

// scriptExportName is the file name the save dialog offers for a script: the
// reference's `{id}-script.{extension}`, where the id is the integration being
// edited and, for a connection that has no id yet, the command word the user
// typed (`ExtensionsPanel.tsx:1955-1958`: `editingCustomId ?? customIntegration
// .command`). The extension comes from the language table, the same value the
// file filter shows.
func scriptExportName(id, command, language string) string {
	stem := strings.TrimSpace(id)
	if stem == "" {
		stem = strings.TrimSpace(command)
	}
	if stem == "" {
		stem = "floter-provider"
	}
	return stem + "-script." + scriptlang.Extension(language)
}

// contentAction draws one copy button: its label, or its confirmation while
// the window holds, and the press that puts action's value on the clipboard.
// An empty value copies nothing and confirms nothing, the same way the
// reference's buttons disabled on a missing value.
//
// P13-dn（`docs/liquid-glass.md` §6.83）：确认语比静息语长（`Copy script` 11 字
// → `Script copied` 13 字），胶囊的宽度由孩子撑开，所以**按下的一瞬间**右边那颗
// `Export script` 被推开：实测 720 帧、两套外观一致 —— label 墨宽 62、确认语 72，
// 导出胶囊 x=305.0 → 315.0（10px）。一次状态反馈不许改动这一行的布局。
// 现在胶囊的地板取两句里**更宽**的那一句（`MeasureText` 画的同一支画笔、同一档
// 字号与字重），确认语换上时盒子一个像素都不动。
func (a *App) contentAction(c *ui.Context, action, label, done, value string) bool {
	// A sibling may disappear when its value is blank. Its position is not
	// this operation's identity: focus and Enter must keep their own action.
	c = c.Key(action)
	focus := a.contentFocus(c, action)
	if a.Actions.CopyText == nil || strings.TrimSpace(value) == "" {
		focus.restoreVisible(c)
	}
	if a.Actions.CopyText == nil || (a.copiedContent == action && a.copiedContentValue != value) {
		a.copiedContent, a.copiedContentValue = "", ""
	}
	if strings.TrimSpace(value) == "" {
		return true
	}
	copied := a.contentCopied(action, c.Now())
	if copied {
		c.After(a.copiedContentUntil.Sub(c.Now()))
	}
	floor := a.contentActionFloor(c, label, done)
	if a.Actions.CopyText == nil {
		a.disabledActionButton(c, label).MinWidth(floor)
		return true
	}
	if copied {
		label = done
	}
	button := a.actionButton(c, label).MinWidth(floor).Bind(&focus.button)
	a.rememberModeContent(c, action == "script", button)
	if button.Clicked() {
		if a.Actions.CopyText != nil {
			before := a.toolCallbackState()
			a.Actions.CopyText(value)
			// A clipboard callback can open another tool before returning.
			// Its success belongs to the form that supplied these bytes.
			if a.toolCallbackState() != before || a.Actions.CopyText == nil {
				return false
			}
			a.copiedContent, a.copiedContentUntil = action, c.Now().Add(copiedContentDuration)
			a.copiedContentValue = value
		}
	}
	return true
}

// contentActionFloor is the width a copy pill keeps across its two states: the
// wider of the resting label and the confirmation, plus the button’s 14u of
// side padding on each side (`.extensions-action-button`, `extensions.css:1313`).
// Measured rather than guessed, because both strings are localized and the pair
// order flips between languages ("Copy script"/"Script copied" is 11/13, the
// Chinese pair is 6/5).
func (a *App) contentActionFloor(c *ui.Context, labels ...string) float32 {
	t := a.cardTheme(c)
	body := a.tokens(c).Body
	widest := float32(0)
	for _, label := range labels {
		w, _ := c.MeasureText(0, ui.Span{Text: label, Size: body, Weight: 600})
		if w > widest {
			widest = w
		}
	}
	// Two pixels of ceiling: the painter's own sub-pixel advance rounds up when
	// the glyphs land (`MeasureText` says 71.x for a run that lays out 72 wide),
	// and a floor one hair under the wider word would let the row move again by
	// that hair — measured: +1 still moved the export pill by exactly 1px.
	return float32(math.Ceil(float64(widest))) + 2*t.Space(3.5) + 2
}

// copiedContentDuration is how long a content action's button keeps its
// confirmation: the old build's own 1600ms (`showSuccess` then reset), the same
// window the deep-link copy used.
const copiedContentDuration = 1600 * time.Millisecond

// contentCopied reports whether the content action should show its
// confirmation, clearing the state once its window has passed (the reference's
// `customContentOperation` reset in the action's `finally`).
func (a *App) contentCopied(action string, now time.Time) bool {
	if a.copiedContent == "" || a.copiedContent != action {
		return false
	}
	if !now.Before(a.copiedContentUntil) {
		a.copiedContent = ""
		return false
	}
	return true
}

// executionPlanJSON is the plan the reference's `copyExecutionPlan` put on the
// clipboard: the program, its default arguments, and the run mode, pretty-
// printed (`src/ExtensionsPanel.tsx:1947-1950`). It is a preview of what will
// run, never a shell string — the argv is built by the host from these same
// fields (`customRequest`), so the plan can only describe them.
func executionPlanJSON(program, args string) string {
	plan := struct {
		Program string   `json:"program"`
		Args    []string `json:"args"`
		Mode    string   `json:"mode"`
	}{Program: strings.TrimSpace(program), Args: splitPlanArgs(args), Mode: "pty"}
	encoded, err := json.MarshalIndent(plan, "", "  ")
	if err != nil {
		return ""
	}
	return string(encoded)
}

// splitPlanArgs is the plan's own read of the arguments field: the same
// whitespace split the host applies when it builds the argv, but an absent
// field reads as an empty list rather than a null one (the reference spread an
// always-present array into its plan).
func splitPlanArgs(args string) []string {
	fields := strings.Fields(args)
	if fields == nil {
		return []string{}
	}
	return fields
}

// customIssueMessage is the one sentence for one rule, in the stored language.
func customIssueMessage(copy i18n.Settings, key extensions.CustomIssueKey) string {
	switch key {
	case extensions.CustomIssueNameLength:
		return copy.LocalToolNameLength
	case extensions.CustomIssueCommandShape:
		return copy.LocalToolCommandShape
	case extensions.CustomIssueVersionShape:
		return copy.LocalToolVersionShape
	case extensions.CustomIssuePlatformRequired:
		return copy.LocalToolPlatformRequired
	case extensions.CustomIssueModeInvalid:
		return copy.LocalToolModeInvalid
	case extensions.CustomIssueScriptEmpty:
		return copy.LocalToolScriptEmpty
	case extensions.CustomIssueScriptLanguageInvalid:
		return copy.LocalToolScriptLanguageInvalid
	}
	return ""
}

// toolPermissionFields are the form's declaration switches and the boundary
// note above them, drawn only while the Advanced disclosure is open. The note
// is the honest half of the disclosure: the switches record intent and drive
// the audit, they do not sandbox anything — local code runs as the user either
// way (`settings.extensions.permissionBoundary`).
func (a *App) toolPermissionFields(c *ui.Context, copy i18n.Settings) {
	if !a.toolAdvanced {
		return
	}
	a.integrationLead += "local-permissions:"
	if a.toolPermissions == nil {
		a.toolPermissions = map[string]bool{}
	}
	// The note is the honest half of the disclosure: the switches record intent
	// and drive the audit, they do not sandbox anything — local code runs as the
	// user either way (`settings.extensions.permissionBoundary`). It is prose, so
	// it takes the card's prose line (P13-dl): a wrapped sentence at the hint
	// rung, not a settings row with an empty label above it.
	a.cardProse(c, copy.PermissionBoundary)
	// One row per permission, the host's own two marked as the checks they are
	// (see the permission tiers).
	for _, permission := range extensions.AllPermissions {
		permission := permission
		on := a.toolPermissions[permission]
		label := i18n.PermissionLabel(a.settings().Language, permission)
		labelClicked := a.row(c, label, "", func() {
			a.formFeedbackOutlet(c.Key("permission-outlet"), a.integrationLead, func() {
				if a.switchControl(c, &on).Label(label).Changed() {
					a.toolPermissions[permission] = on
				}
			})
		})
		if labelClicked {
			a.toolPermissions[permission] = !on
		}
	}
}

// scriptRows are the rows a script tool shows in place of the program row: the
// language it is written in (with the line saying whether this machine has its
// toolchain), and the editor the script is typed into.
func (a *App) scriptRows(c *ui.Context, copy i18n.Settings, language *string, script *string, issues []extensions.CustomIssue) {
	options := make([]i18n.Option, 0, len(scriptlang.Languages))
	for _, option := range scriptlang.Languages {
		options = append(options, i18n.Option{ID: option.ID, Label: option.Label})
	}
	var languagePicker ui.Element
	outputFocusOutlet(c.Key("local-language-outlet"), func() {
		languagePicker = a.choose(c.Key("local-language"), copy.LocalToolLanguage, copy.LocalToolLanguageHint, options, *language, func(id string) {
			// The editor owns the text now: switching language only names the new
			// one. The template swap for an untouched draft happens in the
			// editor's own sync (see scriptEditorView), against the buffer it
			// holds — including a switch away from a written script, which keeps
			// it as the old form did.
			*language = id
		}, func() {
			a.scriptRuntimeNote(c, a.scriptRuntimeLine(*language))
		})
	})
	a.rememberModeContent(c, true, languagePicker)
	// The editor is a stacked row: a script wants the row's full width and
	// more than one line, so the label and the status sit above it. The box is
	// mygo's code editor (line numbers, syntax highlighting) rather than a bare
	// TextArea; scriptEditorView keeps its state across frames.
	a.stackedRow(c.Key("local-script"), copy.LocalToolScript, copy.LocalToolScriptHint, func() {
		outputFocusOutlet(c.Key("local-script-outlet"), func() {
			a.rememberModeContent(c, true, a.scriptEditorView(c, copy, language, script).
				Bind(&a.contentFocus(c, "script").source).
				Bind(&a.contentFocus(c, "export").source))
		})
		a.toolIssueUnder(c, copy, issues, extensions.CustomFieldScript)
	})
}

// copy is the settings surface's words in the stored language.
func (a *App) copy() i18n.Settings {
	return i18n.For(a.settings().Language).Settings
}

// settings is this frame's settings value, copied once per change rather than
// once per reader (see `App.settingsMemo` and `settings.Memo`). Draw-time
// readers go through it; an event handler that must see the store as it is
// right now may still read `Store.Snapshot`.
func (a *App) settings() settings.Settings {
	return a.settingsMemo.Get(a.Store)
}

// runtimeProbe is one language's toolchain probe, off the render thread:
// `done` closes when the probe has landed, and `check` is the verdict it
// found. A probe that has not landed yet is the render's "checking" state —
// the old panel's `null` — never a verdict.
type runtimeProbe struct {
	done  chan struct{}
	check scriptlang.Check
}

// scriptRuntimeStart returns the probe for a language, starting one on a
// goroutine the first time the form asks for it. Probes are deduplicated: a
// redraw while one is in flight — or a save that arrives mid-flight — joins
// the request already running rather than firing a second PATH scan.
func (a *App) scriptRuntimeStart(language string) *runtimeProbe {
	a.scriptRuntimeMu.Lock()
	defer a.scriptRuntimeMu.Unlock()
	if a.scriptRuntime == nil {
		a.scriptRuntime = map[string]*runtimeProbe{}
	}
	if probe, ok := a.scriptRuntime[language]; ok {
		return probe
	}
	probe := &runtimeProbe{done: make(chan struct{})}
	a.scriptRuntime[language] = probe
	epoch := a.scriptRuntimeEpoch
	probeFn := a.Actions.ScriptRuntime
	invalidate := a.Actions.Invalidate
	go func() {
		check := probeFn(language)
		a.scriptRuntimeMu.Lock()
		// A form that closed and reopened while this ran must not inherit the
		// verdict: the machine may have changed (the drawer's `epoch` guard).
		if epoch == a.scriptRuntimeEpoch {
			probe.check = check
		}
		a.scriptRuntimeMu.Unlock()
		close(probe.done)
		if invalidate != nil {
			invalidate()
		}
	}()
	return probe
}

// scriptRuntimeCheck is the muted line's own read of the probe: a landed
// verdict, or nil while one is in flight (or before the form has asked). The
// second result is false when the host wired no probe at all, so the line
// falls back to the toolchain's name alone.
func (a *App) scriptRuntimeCheck(language string) (*scriptlang.Check, bool) {
	if a.Actions.ScriptRuntime == nil {
		return nil, false
	}
	probe := a.scriptRuntimeStart(language)
	select {
	case <-probe.done:
		check := probe.check
		return &check, true
	default:
		return nil, true
	}
}

// scriptRuntimeVerdict is the probe's verdict for a language, waiting for a
// probe that is still in flight. The old form awaited the probe before saving
// so the missing-toolchain warning reflects the machine rather than a race;
// the wait is short because the form opened a frame earlier and the probe has
// almost always landed. A stale (epoch-dropped) probe answers with the zero
// Check, which reads as "not asked" and so raises no warning.
func (a *App) scriptRuntimeVerdict(language string) (scriptlang.Check, bool) {
	if a.Actions.ScriptRuntime == nil {
		return scriptlang.Check{}, false
	}
	probe := a.scriptRuntimeStart(language)
	<-probe.done
	return probe.check, true
}

// clearScriptRuntimeCache drops the verdicts and bumps the epoch: a fresh form
// gets a fresh toolchain check, the same reset the old panel's epoch did. A
// user who installed the runtime since the last form is told to reopen it, so
// reopening is exactly when the cache must not survive — and any probe still
// in flight from the closed form is dropped rather than cached.
func (a *App) clearScriptRuntimeCache() {
	a.scriptRuntimeMu.Lock()
	a.scriptRuntimeEpoch++
	a.scriptRuntime = nil
	a.scriptRuntimeMu.Unlock()
}

// scriptRuntimeNote draws the toolchain line under the language picker: the
// picker's own second line, at the caption rung the reference gave machine
// facts (`.session-manager__meta`, `settings.css:1280-1286`), one step under
// the static hint above it.
//
// P13-dm（`docs/liquid-glass.md` §6.82）：这一行此前是 `a.row(c, 同一个 “Language”
// 标签, "", 句子)` —— 一句话挂在一行设置项的**控制槽**里，于是它右对齐贴到卡片
// 右沿（720 帧：盒子 x=628.8 / 宽 61，卡片文字列到 457.8），与它解释的那个选择器
// 隔着 470px；而且判词一变长，控制槽反手把文字列压窄（缺工具链的判词把槽撞到
// 331px 宽），同一行的高度随一句话的长短变。它是一句话，不是一个设置项：现在占
// 整列宽、跟着选择器走、按句子折行，行的标签也不再念第二遍。
func (a *App) scriptRuntimeNote(c *ui.Context, text string) {
	if text == "" {
		return
	}
	a.integrationLead += "local-runtime:" + strconv.Quote(text)
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	ui.Row(c).FillWidth().Padding(t.Space(2.25), 0).Children(func() {
		ui.Text(c, text).FontSize(tokens.Caption).FontWeight(500).TextColor(t.TextMuted)
	})
}

// scriptRuntimeLine is the one muted line under the language picker: what this
// machine has for the language. An absent toolchain is deliberately not an
// error — a user may install Python and come back — so it is a sentence, never
// a red banner.
func (a *App) scriptRuntimeLine(language string) string {
	copy := a.copy()
	option := scriptlang.Lookup(language)
	check, wired := a.scriptRuntimeCheck(language)
	if !wired {
		// No probe wired is not a verdict: the toolchain's name is all the form
		// can honestly say.
		return option.Toolchain
	}
	if check == nil {
		// Asked, still in flight (or not asked a frame ago): the old panel's
		// `check === null`, painted as "checking", never as "missing".
		return copy.LocalToolRuntimeChecking
	}
	switch status := scriptlang.StatusOf(language, *check); status.State {
	case scriptlang.Available:
		line := copy.LocalToolRuntimeReady(status.Name, status.Version)
		if status.Compiled {
			line += "  ·  " + copy.LocalToolRuntimeCompiled
		}
		return line
	case scriptlang.Missing:
		return copy.LocalToolRuntimeMissing(strings.Join(status.Names, ", "))
	default:
		// A landed check with no observation cannot claim the toolchain is
		// missing: the toolchain's name is all we can honestly say.
		return option.Toolchain
	}
}

// isTemplate reports whether a script is still one of the shipped templates,
// so a language switch may replace it.
func isTemplate(script string) bool {
	for _, template := range scriptlang.Templates() {
		if script == template {
			return true
		}
	}
	return false
}

// routeBackground is the manifest's own spelling for a command whose output
// the launcher shows instead of the terminal, and routeScript the form's
// spelling for a tool the host writes rather than one it finds.
const (
	routeBackground = "background"
	routeScript     = "script"
)

// customPlatforms are the operating systems a connected tool can be limited
// to, in the order the old form lists them: the id is what the manifest stores
// and the runtime checks, the label is what the row shows.
var customPlatforms = []struct{ ID, Label string }{
	{"darwin", "macOS"},
	{"linux", "Linux"},
	{"windows", "Windows"},
}

// currentPlatform is the platform a fresh form ticks: this machine's own, with
// anything the manifest vocabulary does not name falling back to linux, as the
// old build's CURRENT_PLATFORM did.
func currentPlatform() string {
	for _, platform := range customPlatforms {
		if platform.ID == runtime.GOOS {
			return platform.ID
		}
	}
	return "linux"
}

// CurrentPlatform is the platform a connection request built without the form
// supports: this machine's own, in the manifest vocabulary. The form ticks it
// for a fresh tool, and the shell's detected/register flows — which skip the
// form — need the same default, or the request is refused with
// `platformRequired` before anything is written.
func CurrentPlatform() string { return currentPlatform() }

// freshnessOf reads what is known about an integration's command list, for
// the card's own row. Nothing is shown for an integration nothing has probed.
func (a *App) freshnessOf(integration Integration) (extensions.Freshness, bool) {
	freshness := a.Actions.Freshness
	if freshness == nil {
		return extensions.Freshness{}, false
	}
	value, ok := freshness(integration.ID)
	if !ok {
		return extensions.Freshness{}, false
	}
	return value, true
}

// freshnessState is the row's trailing word: how the last derivation went.
func freshnessState(copy i18n.Settings, freshness extensions.Freshness) string {
	switch freshness.Result {
	case extensions.FreshnessRunning:
		return copy.FreshnessResultRunning
	case extensions.FreshnessSuccess:
		return copy.FreshnessResultSuccess
	case extensions.FreshnessDegraded:
		return copy.FreshnessResultDegraded
	case extensions.FreshnessFailed:
		return copy.FreshnessResultFailed
	default:
		return copy.FreshnessResultUnknown
	}
}

// freshnessResultInk is the Result cell's own register (P13-fg, §6.128). The
// five words are not one vocabulary: `Succeeded` is the answer, `Succeeded with
// warnings` / `Failed` are answers that have to be read, and `Probing…` /
// `Unknown` are placeholders where an answer would be.
//
// The two steps it spends are the neutral ladder's, not `Warning`: on this same
// card the semantic colour is already spent twice — `stateMark`'s broken chip
// (the integration itself is broken) and `healthDetail`'s failure cards /
// `statusInk`'s `error`. §6.108 (P13-em) settled that one fact gets one alarm,
// and a derivation that failed is *this cell's answer*, not a second alarm.
func freshnessResultInk(freshness extensions.Freshness, tokens theme.Tokens, t *ui.Theme) ui.Color {
	switch freshness.Result {
	case extensions.FreshnessDegraded, extensions.FreshnessFailed:
		return tokens.TextStrong
	case extensions.FreshnessRunning, extensions.FreshnessUnknown:
		return t.TextMuted
	default:
		return tokens.TextSecondary
	}
}

// freshnessWhenInk is the Last probe cell's register: a probe that never ran is
// the reference's own `Never probed` placeholder, and a placeholder is not an
// answer (`freshnessResultInk`'s quiet step, the one `freshnessDeltaInk` already
// uses for "nothing to report").
func freshnessWhenInk(freshness extensions.Freshness, tokens theme.Tokens, t *ui.Theme) ui.Color {
	if freshness.AtSeconds == 0 {
		return t.TextMuted
	}
	return tokens.TextSecondary
}

// freshnessDot is the one-word mark beside an integration's name: the same
// projection the freshness row below uses, so a user scanning the cards sees a
// list move without reading every row's timeline. Only a change earns warmth;
// a synced list is a quiet secondary dot and an unknown one is muted.
func (a *App) freshnessDot(c *ui.Context, copy i18n.Settings, freshness extensions.Freshness) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	dot := freshness.DotState()
	color := t.TextMuted
	switch dot {
	case extensions.FreshnessDotSynced:
		color = tokens.TextSecondary
	case extensions.FreshnessDotChanged:
		color = t.Warning
	}
	// The mark is its own label: the tooltip and the accessible name are the
	// same sentence, and the state word inside it comes from a switch over the
	// same value the colour does.
	label := freshnessDotLabel(copy, dot)
	mark := ui.Box(c).Size(t.Space(2), t.Space(2)).Radius(t.Space(1)).Shrink(0).
		Background(color).Label(label)
	// P13-az：同一个句子的无障碍名与提示（§6.20 20-3）。
	tokens.Tip(c, mark, label)
}

// freshnessDotLabel is the mark's whole sentence: the state's own word inside
// the shared "Command status: {state}" frame, so a state added to the
// vocabulary without a word cannot print an empty string.
func freshnessDotLabel(copy i18n.Settings, dot extensions.FreshnessDot) string {
	word := copy.FreshnessDotUnknown
	switch dot {
	case extensions.FreshnessDotSynced:
		word = copy.FreshnessDotSynced
	case extensions.FreshnessDotChanged:
		word = copy.FreshnessDotChanged
	}
	return copy.FreshnessDot(word)
}

// freshnessSection draws the drawer's freshness block at the reference's own
// faces (`ExtensionsPanel.tsx:3076-3176`, `extensions.css:1997-2119`): a block
// label, a two-cell metadata grid, the command-count line, and the secondary
// health-source note. What it replaces was one ruled card row whose grey
// subline carried every fact in the row's own register.
func (a *App) freshnessSection(c *ui.Context, copy i18n.Settings, integration Integration, freshness extensions.Freshness) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	// P13-cx（`docs/liquid-glass.md` §6.67）：整块此前被画成卡体列的直接子元素，于是它的
	// 左端从卡面第一像素开始（实测 x=192，而行标签 `Health` 在 x=200），右端（`Result` 的
	// 值）顶到卡框 701——这是 P13-cw 给 `healthDetail` 修过的同一个 bug，`freshnessSection`
	// 是同一张卡上漏网的第二块。参考里整块住在 `.extension-detail-block` 里，和它自己的
	// `h4` 共用同一个 padding（`floter-main:src/styles/extensions.css:1997-2002`），而本仓
	// 那个 `h4` 就是 `Freshness` 这一行。只加水平内缩：块内四行的纵向节奏（`Gap(0)`，
	// 与做兄弟时同一个间隔）一个像素都不动。
	block := ui.Column(c).FillWidth().Gap(0).Padding(0, a.rowInset(t))
	block.Children(func() {
		// The section is the extension drawer's block label: the reference's
		// `.extension-detail-block h4` — sentence case at the *secondary* ink,
		// caption 620 (`extensions.css:2008-2013`). It is one voice with the
		// metadata grid's own `dt` labels one line below, not the uppercase 650 in
		// tertiary grey the port had reached for.
		ui.Row(c).FillWidth().Children(func() {
			ui.Text(c, copy.Freshness).FontSize(tokens.Caption).FontWeight(620).
				TextColor(tokens.TextSecondary)
		})
		// The when/result line: the reference's two-column `.extension-metadata` grid
		// (`extensions.css:2022-2050`) — a `dt` label at the *tertiary* caption step
		// and its `dd` value at the *body* step in `--text-secondary`, two cells to a
		// row with an 8u/16u gap pair. The port had flattened the pair into one
		// ruled card row whose grey subline carried both facts in the row's register.
		// P13-fg（§6.128）：两格的值墨不再由 `metadataCell` 写死。这块格子同时装着
		// **答案**（`Succeeded`、`3 min. ago`）与**占位**（`Probing…`、`Unknown`、
		// `Never probed`），此前两者同穿 `TextSecondary`：实测五个结果词与两种时间值
		// 一条墨（0-3 级离档），于是「失败了」与「成功了」同重、「还没探测」与「探测过了」
		// 同重。格子自己的阶梯很宽（`secondary → strong` 83-86 级、`secondary → muted`
		// 18-23 级），所以只要把词挂回它自己的档，一眼就分得开。
		meta := ui.Row(c).FillWidth().GapX(t.Space(3)).GapY(0)
		meta.Children(func() {
			a.metadataCell(c, copy.FreshnessLastProbe, freshnessWhenValue(copy, freshness),
				freshnessWhenInk(freshness, tokens, t))
			a.metadataCell(c, copy.FreshnessResult, freshnessState(copy, freshness),
				freshnessResultInk(freshness, tokens, t))
		})
		// The command-count line: a flex row, not a metadata cell — the reference's
		// `.extension-freshness__commands` (`extensions.css:2077-2111`) puts a
		// tertiary caption label and the count at the row's own *body* step side by
		// side with an 8u gap, then the muted `·` and the caption delta word; the
		// port had folded both facts into the subline's prose.
		count := copy.FreshnessCommandsUnknown
		if freshness.CommandCount != nil {
			count = strconv.Itoa(*freshness.CommandCount)
		}
		line := ui.Row(c).FillWidth().Gap(t.Space(2)).AlignItems(ui.Center)
		line.Children(func() {
			ui.Text(c, copy.FreshnessCommands).FontSize(tokens.Caption).
				TextColor(tokens.TextTertiary)
			ui.Text(c, count).FontSize(t.FontSize).FontWeight(600).
				TextColor(tokens.TextStrong)
			// The separator is the reference's own muted `·` between the count and the
			// delta word (`extensions.css:2096-2103`); the delta word itself steps up
			// one register — `--text-secondary` — only when the list actually moved,
			// because a real movement is information and "no change" is not
			// (`:2105-2111`).
			ui.Text(c, "\u00b7").FontSize(tokens.Caption).TextColor(t.TextMuted)
			ui.Text(c, freshnessDeltaWord(copy, freshness)).FontSize(tokens.Caption).
				TextColor(freshnessDeltaInk(freshness, tokens, t)).SingleLine()
		})
		// The health report is the source of the time, not of the count: the
		// reference states that once, as a *secondary* `.extension-detail-note` — one
		// muted caption line with no pane, no rule and no border
		// (`extensions.css:2006-2011,2114-2119`).
		if freshness.Source == extensions.FreshnessHealth {
			ui.Text(c, copy.FreshnessHealthSource).FontSize(tokens.Caption).
				TextColor(t.TextMuted).Wrap()
		}
	})
}

// metadataCell is one `.extension-metadata` cell: its `dt` at the tertiary
// caption step and its `dd` at the body step in the secondary ink
// (`extensions.css:2033-2050`). The reference sized the value one step above
// its own label, which is what keeps the pair from reading as two rows of the
// same register.
//
// P13-fg（§6.128）：值那一档由调用方给。格子的一对（标签 / 值）说的是「这一格叫什么」
// 与「它是什么」，而「它是什么」本身还有两种：**答案**与**占位**。把后者也写死成
// 答案的墨，就等于让格子对「这一格到底有没有答案」保持沉默。标签仍固定 tertiary。
func (a *App) metadataCell(c *ui.Context, label, value string, ink ui.Color) {
	tokens := a.tokens(c)
	t := a.cardTheme(c)
	ui.Column(c).Grow(1).MinWidth(0).Children(func() {
		ui.Text(c, label).FontSize(tokens.Caption).TextColor(tokens.TextTertiary)
		ui.Text(c, value).FontSize(t.FontSize).TextColor(ink).SingleLine()
	})
}

// freshnessWhenValue is the metadata grid's "last probe" value: how long ago
// the list was derived, or the reference's "Never probed" word when nothing
// ever did (`ExtensionsPanel.tsx:3136-3145`).
func freshnessWhenValue(copy i18n.Settings, freshness extensions.Freshness) string {
	if freshness.AtSeconds == 0 {
		return copy.FreshnessNever
	}
	return freshnessWhen(copy, time.Since(time.Unix(freshness.AtSeconds, 0)))
}

// freshnessDeltaWord is the reference's `.extension-freshness__delta-text`
// (`extensions.css:2100-2111`): the one sentence the count moved by, one per
// kind. The count rides the copy's own formatter, so a locale words it itself.
func freshnessDeltaWord(copy i18n.Settings, freshness extensions.Freshness) string {
	switch freshness.Delta {
	case extensions.DeltaIncrease:
		return copy.FreshnessDeltaIncrease(freshness.DeltaCount())
	case extensions.DeltaDecrease:
		return copy.FreshnessDeltaDecrease(freshness.DeltaCount())
	case extensions.DeltaUnchanged:
		return copy.FreshnessDeltaUnchanged
	default:
		return copy.FreshnessDeltaUnknown
	}
}

// freshnessDeltaInk is the delta word's register: `--text-secondary` once the
// list actually moved, `--text-muted` otherwise (`extensions.css:2096-2111`).
func freshnessDeltaInk(freshness extensions.Freshness, tokens theme.Tokens, t *ui.Theme) ui.Color {
	switch freshness.Delta {
	case extensions.DeltaIncrease, extensions.DeltaDecrease:
		return tokens.TextSecondary
	default:
		return t.TextMuted
	}
}

// freshnessWhen renders how long ago a probe ran. Under 45 seconds it is the
// caller's own "just now" word — every locale words that differently enough
// that a table of our own would be worse than one key — and past it the
// localized relative time ("3 min. ago" / "3分钟前").
func freshnessWhen(copy i18n.Settings, age time.Duration) string {
	if age < 45*time.Second {
		return copy.FreshnessJustNow
	}
	value, unit := relativeAge(age)
	return copy.FreshnessRelative(value, unit)
}

// relativeAge picks the largest unit whose threshold the age is under and
// rounds to nearest, exactly the thresholds the old build's `relativeTime`
// used: minutes under an hour, hours under a day, then days, months and
// years. The rounding is what turns 50s into "1 min." and 25h into
// "yesterday".
func relativeAge(age time.Duration) (int, i18n.RelativeUnit) {
	seconds := age.Seconds()
	switch {
	case seconds < 3600:
		return int(math.Round(seconds / 60)), i18n.RelativeMinute
	case seconds < 86400:
		return int(math.Round(seconds / 3600)), i18n.RelativeHour
	case seconds < 2592000:
		return int(math.Round(seconds / 86400)), i18n.RelativeDay
	case seconds < 31536000:
		return int(math.Round(seconds / 2592000)), i18n.RelativeMonth
	default:
		return int(math.Round(seconds / 31536000)), i18n.RelativeYear
	}
}

// DetectedTool is one program the machine has that is not yet connected.
type DetectedTool struct {
	// Name is what the user calls it and Path where it lives.
	Name        string
	Path        string
	Description string
	// VersionArgs is how the tool reports its version, when the caller knows
	// better than the default.
	VersionArgs string
	// RuntimeAvailable reports whether the program is runnable right now: the
	// reference's `runtimeAvailable`, which decides between Connect and the two
	// install arms (`src/extensions/ExtensionRow.tsx:296-302`).
	RuntimeAvailable bool
	// InstallCommand is the recipe command that would install this tool with a
	// package manager the machine has, empty when the catalog does not know the
	// tool or has no recipe for this platform (`src/extensions/tool-rows.ts`'s
	// `installCommandForId`).
	InstallCommand string
}

// detectedSection lists the programs this machine has that nothing has
// connected yet, each with the one press that connects it: discovery is the
// first link of the same loop the install and invoke rows close, so a tool
// the machine already has does not need its path typed by hand.
func (a *App) detectedSection(c *ui.Context, copy i18n.Settings) {
	if a.Actions.Detected == nil || a.Actions.ConnectDetected == nil {
		return
	}
	tools := a.Actions.Detected()
	if len(tools) == 0 {
		return
	}
	a.integrationLead += "detected:"
	for _, tool := range tools {
		a.integrationLead += strconv.Quote(tool.Name) + strconv.Quote(tool.Description) + strconv.Quote(tool.Path)
	}
	a.extensionSection(c, copy.DetectedTitle, len(tools), func() {
		a.extensionHint(c, copy.DetectedHint)
		a.card(c, func() {
			for _, tool := range tools {
				tool := tool
				a.iconRow(c, true, tool.Name, tool.Description, func() {
					a.detectedAction(c, copy, tool)
				}, func() {
					a.dataRow(c, tool.Path)
				})
			}
		})
	})
}

// detectedActionKind is which of the reference's three arms a detected row's
// one button takes: the program is runnable and connects, it is not runnable
// but a recipe exists and opens the install command in a terminal, or floter
// has nothing and the button says so disabled
// (`src/extensions/ExtensionRow.tsx:296-302`).
type detectedActionKind int

const (
	detectedConnect detectedActionKind = iota
	detectedInstallInTerminal
	detectedInstallFirst
)

// detectedActionFor picks the arm from the row's own facts. RuntimeAvailable
// wins: a runnable program is connected, never reinstalled.
func detectedActionFor(tool DetectedTool) (kind detectedActionKind, disabled bool) {
	switch {
	case tool.RuntimeAvailable:
		return detectedConnect, false
	case tool.InstallCommand != "":
		return detectedInstallInTerminal, false
	default:
		return detectedInstallFirst, true
	}
}

// detectedLabel words the arm: the reference put the same three words on the
// button's visible label and its accessible name.
func detectedLabel(copy i18n.Settings, kind detectedActionKind) string {
	switch kind {
	case detectedInstallInTerminal:
		return copy.IntegrationsInstallInTerminal
	case detectedInstallFirst:
		return copy.IntegrationsInstallTool
	default:
		return copy.IntegrationsConnect
	}
}

// detectedAction draws the row's button and runs the arm it chose. A row with
// nothing to offer still draws its word, disabled, rather than vanishing — the
// reference's disabled button was the only sign there was nothing to press.
func (a *App) detectedAction(c *ui.Context, copy i18n.Settings, tool DetectedTool) {
	kind, disabled := detectedActionFor(tool)
	if kind == detectedInstallInTerminal && a.Actions.InstallDetected == nil {
		disabled = true
	}
	var button ui.Element
	if disabled {
		// P13-ba: a row with nothing to offer keeps the button (it is the only
		// sign there is nothing to press) but loses the lit edge.
		button = a.disabledActionButton(c, detectedLabel(copy, kind))
	} else {
		button = a.actionButton(c, detectedLabel(copy, kind))
	}
	if !button.Clicked() {
		return
	}
	switch kind {
	case detectedInstallInTerminal:
		a.Actions.InstallDetected(tool.InstallCommand)
	case detectedConnect:
		a.Actions.ConnectDetected(tool)
	}
}

// requestDisable opens the confirmation for turning an integration off.
// A fresh ask starts clean: the last attempt's failure was about a question
// the user already dismissed, so it must not replace this one's sentence.
func (a *App) requestDisable(id string) {
	if a.disableConfirm == nil {
		a.disableConfirm = map[string]bool{}
	}
	if a.disableConfirmAt == nil {
		a.disableConfirmAt = map[string]time.Time{}
	}
	delete(a.disableError, id)
	a.disableConfirm[id] = true
	a.disableConfirmAt[id] = a.now()
}

// barButton is the compact inline button the reference drew inside a notice
// band (`.extension-discard-bar .extensions-action-button`,
// `src/styles/extensions.css:2473-2481`): the panel's 30px pill is overridden
// to a 24px ladder step — height 24px, padding 0 8px, caption font, the
// radius-xs corner — so the answers read as part of the band rather than as
// floating controls. Hover lifts the plane to the control-hover step; the
// hairline stays the neutral `ControlEdge` (P8-d: it used to rise to the accent
// keyline, which §5 forbids on hover). A disabled button keeps
// its resting face and ignores the press.
// barButton is the reference's inline action button inside a notice band
// (`extensions.css:1313-1385`): a 24px pill with 8px of side padding, a
// hairline border, the control plane and no fill — the same shape every
// discard bar's answers share. The danger variant is the ink alone
// (`--text-warning`), not a red plane: the reference's destructive action is
// quieter than the framework's filled Button. Hover lifts the plane to
// `--glass-control-hover`, and the ink
// moves to `--text-primary` for both the neutral and the danger button — the
// reference's own `:hover` rule applies to `--danger` too. The icon, when
// one is passed, leads the word: the reference's confirm buttons are
// `<Trash2 size={14} />` / `<Unplug size={14} />` / `<PowerOff size={14} />`
// before their label, so the mark a destructive confirm is recognized by
// comes before the word it confirms.
func (a *App) barButton(c *ui.Context, label string, danger, disabled bool, icon *ui.SVG, run func()) ui.Element {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	ink := tokens.TextStrong
	edge := tokens.ControlEdge
	plane := tokens.Control
	if danger {
		ink = t.Warning
	}
	if disabled && !danger {
		ink = tokens.Disabled
	}
	button := ui.ButtonBase(c).
		Height(t.Space(6)).
		Padding(0, t.Space(2)).
		Radius(tokens.RadiusXS).
		Gap(t.Space(1.25)).
		Background(plane).Border(1, edge)
	if !disabled {
		if button.Hovered() {
			// P8-d 重定基线（§5 禁止侧「行 hover/按下」）：hover 边曾是
			// `tokens.AccentEdge`。这是同族的最后一处尾巴（`rows.go` 的
			// `extensionActionFace`、`uninstall.go` 的两个 pill 与本条是同一
			// 个 `.extensions-action-button` hover 规则）——accent 不能回答
			// 「指针在这条上」，边保持 `ControlEdge`，只抬面与墨。
			plane = tokens.ControlHover
			edge = tokens.ControlEdge
			ink = t.Text
			button = button.Background(plane).Border(1, edge)
		}
	}
	// `.extensions-action-button:active:not(:disabled) { transform: scale(0.97) }`
	// (`extensions.css:138-140`): the press sinks the pill a hair, over the
	// same `--dur-2` transform transition. The disabled pill keeps its resting
	// shape, exactly as the dialog's own action pill does.
	if !disabled && button.Pressed() {
		// P13-q：`barButton` 此前只有几何、没有面（`.extensions-action-button`
		// 的第三档只在 `:active` 的 `scale(0.97)` 上），同族的 `extensionActionFace`
		// 补上按下档之后，这一处也要把 `--glass-control-press` 的面画出来，
		// 否则同一个类在同一个应用里有两种按下。
		button = button.Background(tokens.ControlPress)
		button.Scale(0.97, 0.97)
	}
	// `.extension-discard-bar .extensions-action-button` only overrides the
	// size, padding, radius and font; the rest is the shared
	// `.extensions-action-button` face (`extensions.css:1313-1385`): the
	// `--elev-0` lens, the 5px `--extensions-inline-gap`, 600 weight at
	// `line-height: 1`, and the `--dur-2` colour transition. The 24px button
	// was a flat tint without them.
	// `.extensions-action-button` transitions only its colours and its
	// `transform` (`extensions.css:1331`: `background-color`, `border-color`,
	// `color`, `transform`), never its place in the parent. The old port also
	// asked for a position transition, which made a newly built pill slide
	// from where its predecessor stood — the disable band's pills drifted up
	// under a sentence that had already settled, so a press aimed at the pill
	// could miss it mid-flight.
	button.Transition(ui.ElementTransition{Colors: true, Duration: theme.ColorStep})
	// E1: the pill keeps its own `Border(1, edge)` and wears the lit pair inside
	// it (`theme.Tokens.LitFace`), not the four-layer lens — its ring was the
	// same edge painted twice, and it buried the 0.09 rim under `ControlEdge`.
	// P13-u：禁用的那一臂换 `DimFace`（底对侧还在、受光边熄了）——与同页的
	// `extensionActionFace`（P13-s）同一个材质，同一个理由：受光边是「这块面
	// 可以被碰」的记号（§3），不能碰的面不戴它。
	if disabled {
		tokens.DimFace(button)
	} else {
		tokens.LitFace(button)
	}
	button.Children(func() {
		if icon != nil {
			ui.Icon(c, icon).Size(t.Space(3.5), t.Space(3.5)).TextColor(ink)
		}
		ui.Text(c, label).FontSize(tokens.Caption).FontWeight(600).TextColor(ink).LineHeight(1)
	})
	if disabled {
		// `:disabled { opacity: 0.4; cursor: default; pointer-events: none }`:
		// the framework's flag carries the pointer half and the cursor is the
		// other one it does not paint. P13-u：那个 `.4` 不再叠上去——框架已经给
		// `Disabled` 的子树乘了 0.5（`ui/paint.go:257-259`），两道乘起来是有效
		// 0.2：面离地面只剩 4 级、底对侧归零（实测浅色 243 / 243 / 243）。
		button = lockedControl(button)
	}
	if !disabled && button.Clicked() {
		run()
	}
	return button
}

// noticeBand is the reference's inline confirmation band — the one shape
// `.extensions-notice .extension-discard-bar` gave every question asked in
// place (`src/styles/extensions.css:146-172,2455-2458`): a leading alert mark,
// then a single sentence that takes the free space, then the answers on the
// same row. Both inline questions are this band, and only the ink differs: a
// removal is a loss, so it wears the error tint — `extensions-notice--error`
// keeps the same control pane but paints the ink and the keyline in
// `--text-warning`, and its danger button is warning-coloured
// (`.extensions-action-button--danger`). The band used to be a stacked card
// here — bold title over a muted body with the buttons below — which is not a
// shape the reference ever drew.
//
// The band's own spacing is the reference's: an 8px gap between the mark, the
// sentence and the answers (`.extensions-notice { gap: 8px }`), and a 1.45
// line-height on the sentence (`.extensions-notice { line-height: 1.45 }`) —
// the air a single line of body text carries in every notice the reference
// draws.
//
// It returns the Cancel button so the caller can focus it — the reference's
// own `useEffect` put focus on the Cancel button the moment the band appeared
// (`RemovalConfirmation.tsx:17-18`), so the first press of Enter or Escape
// answers the question without the pointer moving.
func (a *App) noticeBand(c *ui.Context, danger bool, sentence string, answers func(*ui.Element)) ui.Element {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	ink := tokens.TextSecondary
	if danger {
		ink = t.Warning
	}
	var cancel ui.Element
	// Stretch uses the available width after margins; 100% plus margins
	// extended the right edge into the parent's clipping boundary.
	band := ui.Row(c).AlignSelf(ui.Stretch).Gap(t.Space(2)).AlignItems(ui.Center).
		Padding(t.Space(2), t.Space(2.5)).Margin(0, t.Space(3)).
		Radius(tokens.RadiusSM).Background(tokens.Control).Border(1, tokens.ControlEdge)
	// `.extensions-notice--error` keeps the band's `--ext-border` and layers
	// the warning as its own inset keyline (`extensions.css:174-178`), rather
	// than recolouring the border: the error band is the neutral pane with an
	// amber ring, not a second edge.
	if danger {
		band.InsetShadow(0, 0, 0, 1, t.Warning)
	} else {
		// P13-l（§6.2b 第 9-14 行）：同一个组件两条臂，此前只有 `danger` 那条说
		// 了话（一圈警告环），非危险那条只剩发丝——`disableConfirmation` 的带子
		// 因此比它坐着的分组卡还平。E1 的一对面补在这里。
		//
		// `danger` 臂**故意不加**：`InsetShadow(0,0,0,1,…)` 的环占 padding 第一行，
		// 与 `LitFace` 的 `y=1` 受光边是同一行——加了会把那条环顶边洗淡 9% 白、
		// 底边压暗 6%（实测浅色 `156,31,24` → 顶 `165,51,45` / 底 `147,29,23`），
		// 一圈同色的环就不成立了，而这个面只能说一句话（同 §6.2b 9-11、§6.4 4-4）。
		tokens.LitFace(band)
	}
	band.Children(func() {
		ui.Icon(c, mustGlyph("alert")).Size(t.Space(3.75), t.Space(3.75)).
			TextColor(ink)
		// The question is one flowing sentence, not a bold title over a
		// muted body: the band speaks in one ink throughout.
		ui.Text(c, sentence).FontSize(t.FontSize).TextColor(ink).Grow(1).
			LineHeight(1.45)
		answers(&cancel)
	})
	return cancel
}

// disableConfirmation is the notice under an integration's switch: stopping it
// is a mark, not a delete — the files and data stay, and it can be turned back
// on whenever the user likes — but whatever it is running stops at once, so
// the question is asked rather than assumed. It is the reference's own
// horizontal band, not a stacked card (`DisableConfirmation.tsx:60-68`): a
// leading alert mark, then one sentence holding the title and the consequence
// together (`{disableTitle} {disableDescription}`), then Cancel and the Disable
// action on the same row.
//
// The confirm pill carries the reference's own `disabled={busy}`
// (`DisableConfirmation.tsx:67`) while its Cancel key never does (`:65`):
// pressing Disable marks the band in flight and the band stays up until the
// shell reports back, so a slow or failed write is visible rather than assumed,
// but the question can still be answered with "no" at any time. The reference
// awaited `runMutation` and only then cleared `disableTarget`
// (`src/ExtensionsPanel.tsx:1274-1283`); here the same hand-off is the `done`
// callback the shell calls on the main thread.
func (a *App) disableConfirmation(c *ui.Context, copy i18n.Settings, integration Integration) {
	id := integration.ID
	focus := a.noticeFocus(c, id, "disable")
	busy := a.disableBusy[id]
	sentence := copy.DisableTitle(integration.Name) + " " + copy.DisableDescription
	if message := a.disableError[id]; message != "" {
		// A failed write stays on the band, in the family's own error register:
		// the reference reached the user through `showError` while the band it
		// kept mounted said nothing (`src/ExtensionsPanel.tsx:1274-1283`).
		sentence = message
	}
	cancel := a.noticeBand(c, a.disableError[id] != "", sentence, func(cancel *ui.Element) {
		*cancel = a.barButton(c, copy.IntegrationsCancel, false, false, nil, func() {
			a.disableConfirm[id] = false
		}).Bind(&focus.cancel)
		a.barButton(c, copy.DisableConfirm, false, busy, mustGlyph("power"), func() {
			if a.Actions.SetIntegrationEnabled == nil {
				a.disableConfirm[id] = false
				return
			}
			a.markDisableBusy(id)
			a.Actions.SetIntegrationEnabled(id, false, func(err error) {
				a.finishDisableConfirmation(id, err)
			})
		}).Bind(&focus.confirm)
	})
	// The reference's useEffect focuses the Cancel button on open, so the
	// first Enter or Escape answers the question without the pointer moving.
	// A zero-value Element's Focus is a no-op, so no nil check is needed.
	cancel.AutoFocus()
}

// markDisableBusy records that a disable is in flight and drops the last
// failure, so the band's busy face speaks for the new attempt rather than the
// old one.
func (a *App) markDisableBusy(id string) {
	if a.disableBusy == nil {
		a.disableBusy = map[string]bool{}
	}
	if a.disableError != nil {
		delete(a.disableError, id)
	}
	a.disableBusy[id] = true
}

// finishDisableConfirmation settles the disable band after the shell reports
// back. A nil error is the reference's success arm: the band closes (the
// reference dropped `disableTarget` only after the await). A non-nil error
// keeps the band up with the failure on it and the answer pill usable again —
// the reference's `runMutation` cleared `busy` in `finally`, but only a
// successful write dismissed the band (`src/ExtensionsPanel.tsx:1274-1283`).
func (a *App) finishDisableConfirmation(id string, err error) {
	if a.disableBusy != nil {
		delete(a.disableBusy, id)
	}
	if err != nil {
		// The result is a new answer to read. A slow write must not spend
		// its retry window while the confirmation was still busy.
		if a.disableConfirm[id] {
			if a.disableConfirmAt == nil {
				a.disableConfirmAt = map[string]time.Time{}
			}
			a.disableConfirmAt[id] = a.now()
		}
		if a.disableError == nil {
			a.disableError = map[string]string{}
		}
		a.disableError[id] = err.Error()
	} else {
		if a.disableError != nil {
			delete(a.disableError, id)
		}
		if a.disableConfirm == nil {
			a.disableConfirm = map[string]bool{}
		}
		a.disableConfirm[id] = false
	}
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// requestRemove opens the confirmation for deleting an integration. Like the
// disable bar, a fresh ask starts clean: a failure that belonged to the
// previous question does not stand in for this one's.
func (a *App) requestRemove(id string) {
	if a.removeConfirm == nil {
		a.removeConfirm = map[string]bool{}
	}
	if a.removeConfirmAt == nil {
		a.removeConfirmAt = map[string]time.Time{}
	}
	delete(a.removeError, id)
	a.removeConfirm[id] = true
	a.removeConfirmAt[id] = a.now()
}

// confirmWindow is how long an inline confirmation waits for its answer: the
// reference armed both bars with `useTimedReset(removalTarget, …)` /
// `useTimedReset(disableTarget, …)` and its default timeout of 3000 ms
// (`src/hooks/useTimedReset.ts:3`, `src/ExtensionsPanel.tsx:864-865`). An ask
// one moment is not still armed on a later glance.
const confirmWindow = 3 * time.Second

// expireConfirmations withdraws any inline question that has waited longer than
// its window, and arms one wake at the earliest of their deadlines while any is
// live, so a still page reaches it exactly as it does with a hand on it (P11-bq:
// the frames used to be rebuilds of the whole page, one per refresh, for three
// questions that only change once). A band whose answer is already in flight is
// left alone: the reference's timer was cleared on unmount, but its own `busy`
// face outlives a press that has not landed yet — and the shell's report back
// is what wakes the page when it lands.
func (a *App) expireConfirmations(c *ui.Context) {
	now := a.now()
	var next time.Time
	consider := func(at time.Time) {
		if next.IsZero() || at.Before(next) {
			next = at
		}
	}
	for id, at := range a.disableConfirmAt {
		if !a.disableConfirm[id] {
			delete(a.disableConfirmAt, id)
			continue
		}
		// The result wakes a busy question. Its expired ask-time must not
		// hide a later, unanswered question's deadline (P13-hw).
		if a.disableBusy[id] {
			continue
		}
		if now.Sub(at) > confirmWindow {
			a.disableConfirm[id] = false
			delete(a.disableConfirmAt, id)
			continue
		}
		consider(at.Add(confirmWindow))
	}
	for id, at := range a.removeConfirmAt {
		if !a.removeConfirm[id] {
			delete(a.removeConfirmAt, id)
			continue
		}
		if a.removeBusy[id] {
			continue
		}
		if now.Sub(at) > confirmWindow {
			a.removeConfirm[id] = false
			delete(a.removeConfirmAt, id)
			continue
		}
		consider(at.Add(confirmWindow))
	}
	// The configuration form's fold-away question carries the same clock: the
	// reference armed it with the identical `useTimedReset` and 3000 ms default
	// (`ExtensionsPanel.tsx:866`).
	for id, at := range a.configDiscardAt {
		if !a.configDiscard[id] {
			delete(a.configDiscardAt, id)
			continue
		}
		if now.Sub(at) > confirmWindow {
			delete(a.configDiscard, id)
			delete(a.configDiscardAt, id)
			continue
		}
		consider(at.Add(confirmWindow))
	}
	if !next.IsZero() {
		deadline.Wake(c, next.Sub(now))
	}
}

// sessionCloseWindow is how long a session's close question waits for its
// answer: the reference armed it with `KILL_CONFIRM_TIMEOUT = 3000`
// (`src/settings/SessionsPage.tsx:10`) and its `armKill` timer cleared the
// question when the window passed. An ask one moment is not still armed on a
// later glance.
const sessionCloseWindow = 3 * time.Second

// anySessionArmed reports whether a session's two-step close is waiting for
// its answer, and disarmSessionClose answers it with "keep" — Escape's job
// there, as the reference's SessionsPage capture listener did (`disarmKill`):
// the key backs out of the question rather than the page.
func (a *App) anySessionArmed() bool {
	return a.armedSession != 0
}

// armSessionClose asks a session's close question and starts its clock. It is
// keyed on the session's stable ID, not its position, so a session that moved
// while the question was up is still the one the answer ends. The reference's
// `armKill` reset the pending timer on every arm, so arming one session drops
// any other (see `sessionCloseWindow`).
func (a *App) armSessionClose(id uint64) {
	a.armedSession, a.armedSessionAt = id, a.now()
}

// sessionInList reports whether any listed session carries the given identity:
// the row that owns an armed question must still be there to show it.
func sessionInList(sessions []Session, id uint64) bool {
	for i := range sessions {
		if sessions[i].ID == id {
			return true
		}
	}
	return false
}

// disarmSessionClose drops the question and its clock in one place, so the two
// can never drift apart.
func (a *App) disarmSessionClose() {
	a.armedSession, a.armedSessionAt = 0, time.Time{}
}

// expireSessionClose drops a question that has waited longer than its window,
// and keeps the frames coming while one is live so the deadline is reached on
// a still page exactly as it is with a hand on it.
func (a *App) expireSessionClose(c *ui.Context) {
	if a.armedSessionAt.IsZero() {
		return
	}
	if a.now().Sub(a.armedSessionAt) > sessionCloseWindow {
		a.disarmSessionClose()
		return
	}
	// The session's close question: a deadline like the other inline ones, so
	// the page wakes once when it runs out rather than on every refresh
	// (P11-bq).
	deadline.Wake(c, sessionCloseWindow-a.now().Sub(a.armedSessionAt))
}

// anyConfirmOpen reports whether a disable or removal bar is up anywhere on
// the page, and cancelConfirmations answers them all with "no" — Escape's
// job while a question is open (the reference's document-level listener with
// `stopImmediatePropagation`): the key cancels the question, it does not
// leave the page too.
func (a *App) anyConfirmOpen() bool {
	for _, open := range a.configDiscard {
		if open {
			return true
		}
	}
	for _, open := range a.disableConfirm {
		if open {
			return true
		}
	}
	for _, open := range a.removeConfirm {
		if open {
			return true
		}
	}
	for _, open := range a.uninstallOpen {
		if open {
			return true
		}
	}
	return false
}

// cancelConfirmations closes every open confirmation without acting on it.
func (a *App) cancelConfirmations() {
	for id := range a.configDiscard {
		a.disarmConfigDiscard(id)
	}
	for id := range a.disableConfirm {
		a.disableConfirm[id] = false
	}
	for id := range a.removeConfirm {
		a.removeConfirm[id] = false
	}
	for id := range a.uninstallOpen {
		a.uninstallOpen[id] = false
	}
}

// removeConfirmation is the bar under an integration whose destructive button
// was pressed: deleting files is not a mark — the package is gone from the
// machine — so it is asked, in the same inline band the disable bar uses
// (`RemovalConfirmation.tsx:38-44`), wearing the error tint and ending in the
// kind's own danger button. The question is the kind's own: the reference read
// its title through the same per-kind `removalTextKey` that named the menu item
// (`ExtensionsPanel.tsx:2140-2151`), and the confirm button is that kind's verb
// too — a system card that says "Disconnect" asks "Disconnect?", never
// "Uninstall?".
func (a *App) removeConfirmation(c *ui.Context, copy i18n.Settings, integration Integration) {
	id := integration.ID
	focus := a.noticeFocus(c, id, "remove")
	// The reference's confirm button leads with the kind's own mark: a system
	// integration is unplugged (`<Unplug size={14} />`), every other kind is
	// trashed (`<Trash2 size={14} />`) — `RemovalConfirmation.tsx:47`.
	confirmIcon := mustGlyph("trash")
	if integration.removalKind() == RemovalSystem {
		confirmIcon = mustGlyph("unplug")
	}
	// The componentized door is the reference's fork, not a failure: it opens
	// the dialog without marking this band busy, because the answer to the
	// question the band asked has already landed. The reference's own bar only
	// ever ran `disabled={busy}` when it ran the mutation itself
	// (`RemovalConfirmation.tsx:44`), and its Cancel key never carried the flag
	// at all (`:43`) — a question you cannot cancel while it is being answered
	// is a different question.
	componentized := integration.componentizedRemoval() && a.Actions.UninstallComponents != nil
	// A refreshed kind cannot unlock an already dispatched plain removal.
	busy := a.removeBusy[id]
	sentence := integration.removalSentence(copy)
	if message := a.removeError[id]; message != "" {
		// A failed removal stays on the band, in the family's own error
		// register; the reference reached the user through `showError` while
		// the band it kept mounted said nothing
		// (`src/ExtensionsPanel.tsx:1296-1304`).
		sentence = message
	}
	cancel := a.noticeBand(c, true, sentence, func(cancel *ui.Element) {
		*cancel = a.barButton(c, copy.IntegrationsCancel, false, false, nil, func() {
			a.removeConfirm[id] = false
		}).Bind(&focus.cancel)
		a.barButton(c, integration.removalLabel(copy), true, busy, confirmIcon, func() {
			// The reference's confirm branches by kind
			// (`src/ExtensionsPanel.tsx:1286-1304`): npm and custom go on to
			// the componentized dialog, which asks which data to keep before
			// anything moves; a system-owned built-in and a linked local
			// package have nothing of floter's to pick over, so their confirm
			// runs the plain removal.
			if componentized {
				a.removeConfirm[id] = false
				if a.uninstallOpen == nil {
					a.uninstallOpen = map[string]bool{}
				}
				// A fresh ask starts clean: last time's failure does not ride the
				// new dialog (`uninstallError` is only about the open one).
				if a.uninstallError != nil {
					delete(a.uninstallError, id)
				}
				a.uninstallOpen[id] = true
				return
			}
			if a.Actions.UninstallIntegration == nil {
				a.removeConfirm[id] = false
				return
			}
			a.markRemoveBusy(id)
			a.Actions.UninstallIntegration(id, integration.Name, integration.removalKind(), func(err error) {
				a.finishRemoveConfirmation(id, err)
			})
		}).Bind(&focus.confirm)
	})
	// The reference's useEffect focuses the Cancel button on open, so the
	// first Enter or Escape answers the question without the pointer moving.
	// A zero-value Element's Focus is a no-op, so no nil check is needed.
	cancel.AutoFocus()
}

// markRemoveBusy records that a plain removal is in flight and drops the last
// failure, so the band's busy face speaks for the new attempt rather than the
// old one.
func (a *App) markRemoveBusy(id string) {
	if a.removeBusy == nil {
		a.removeBusy = map[string]bool{}
	}
	if a.removeError != nil {
		delete(a.removeError, id)
	}
	a.removeBusy[id] = true
}

// finishRemoveConfirmation settles the removal band after the shell reports
// back. A nil error is the reference's success arm: the band closes. A
// non-nil error keeps the band up with the failure on it and the answer pill
// usable again (`src/ExtensionsPanel.tsx:1296-1304`).
func (a *App) finishRemoveConfirmation(id string, err error) {
	if a.removeBusy != nil {
		delete(a.removeBusy, id)
	}
	if err != nil {
		// Keep the existing three-second answer window, starting when the
		// failure arrives; a question already cancelled stays cancelled.
		if a.removeConfirm[id] {
			if a.removeConfirmAt == nil {
				a.removeConfirmAt = map[string]time.Time{}
			}
			a.removeConfirmAt[id] = a.now()
		}
		if a.removeError == nil {
			a.removeError = map[string]string{}
		}
		a.removeError[id] = err.Error()
	} else {
		if a.removeError != nil {
			delete(a.removeError, id)
		}
		if a.removeConfirm == nil {
			a.removeConfirm = map[string]bool{}
		}
		a.removeConfirm[id] = false
	}
	if a.Actions.Invalidate != nil {
		a.Actions.Invalidate()
	}
}

// installFolderRow installs a package directory the user points at: the same
// local install every other tool goes through, with the permission review
// intact. It is the package form's door, where the local-tool form is the
// program's.
func (a *App) installFolderRow(c *ui.Context, copy i18n.Settings) {
	if a.Actions.InstallFromFolder == nil || a.Actions.ChooseFolder == nil {
		return
	}
	a.card(c, func() {
		a.row(c, copy.InstallFolderLabel, copy.InstallFolderHint, func() {
			var button ui.Element
			a.formFeedbackOutlet(c.Key("folder-install-outlet"), a.integrationLead, func() {
				if a.packageInstallBusy["folder"] {
					a.restoreNotice(c, "folder-install", "install", false, ui.Element{})
					button = a.busyActionButton(c, copy.InstallFolderChoose, "install.folder")
				} else {
					button = a.actionButton(c, copy.InstallFolderChoose)
					a.rememberOperationFocus(c, "folder-install", "install", button)
					if button.Clicked() {
						dir, err := a.Actions.ChooseFolder()
						if err != nil {
							if a.Actions.NotifyWarning != nil {
								a.Actions.NotifyWarning(copy.LocalToolFailed)
							}
						} else if dir != "" {
							a.Actions.InstallFromFolder(dir)
						}
					}
				}
			}, func() bool { return button.FocusVisible() })
		})
	})
}

// RunResult is one background run's captured output, kept for the
// integration's row: the two streams as they were captured (the block joins
// them without a separator, the same concatenation the old panel rendered),
// whether a stream hit the retention cap, and whether the run completed
// successfully.
type RunResult struct {
	Stdout    string
	Stderr    string
	Truncated bool
	Success   bool
}

// Text is the captured output as the block reads it: standard output and
// standard error in the order they were captured, joined as-is.
func (r RunResult) Text() string { return r.Stdout + r.Stderr }

// HasOutput reports whether the run said anything at all, which is what the
// block's empty state and the completion toast both key off.
func (r RunResult) HasOutput() bool { return r.Stdout != "" || r.Stderr != "" }

// SetRunResult records an integration's last background run for its row's
// output block. A run that completed records the output and leaves the block
// folded; one that failed unfolds it, so the reason is one glance away rather
// than behind a click (the old panel's run handler did the same).
func (a *App) SetRunResult(id string, result RunResult) {
	if a.runOutputs == nil {
		a.runOutputs = map[string]RunResult{}
	}
	a.runOutputs[id] = result
	if a.outputKeys == nil {
		a.outputKeys = map[string]*int{}
	}
	a.outputKeys[id] = new(int)
	// A result is a new document. Repaints and disclosure toggles retain the
	// reading position; replacing this integration's capture starts at its head.
	if scroll := a.outputScroll[id]; scroll != nil {
		*scroll = ui.ScrollState{}
	}
	if !result.Success {
		a.setRunOutputOpen(id, true)
	}
}

// LastRun is an integration's recorded run and whether there is one, for a
// caller outside the panel (the shell's own tests and diagnostics).
func (a *App) LastRun(id string) (RunResult, bool) {
	result, ok := a.runOutputs[id]
	return result, ok
}

// setRunOutputOpen opens or closes one integration's output block, keeping the
// two maps in step so the block and its toggle can never disagree.
func (a *App) setRunOutputOpen(id string, open bool) {
	if a.outputOpen == nil {
		a.outputOpen = map[string]bool{}
	}
	a.outputOpen[id] = open
}

// runOutputScroll is the fixed-height output scroller's own offset for one
// integration, created on first use.
func (a *App) runOutputScroll(id string) *ui.ScrollState {
	if a.outputScroll == nil {
		a.outputScroll = map[string]*ui.ScrollState{}
	}
	state, ok := a.outputScroll[id]
	if !ok {
		state = &ui.ScrollState{}
		a.outputScroll[id] = state
	}
	return state
}

// runForm is the run-time parameter form for an integration that declares its
// inputs: one control per parameter, the values collected here, and the Run
// button. No value is ever turned into a command string here — the map goes to
// the shell, which builds the argv — so a value with a space or a quote
// reaches the tool exactly as typed.
type runRefusal struct {
	param      string
	value      string
	definition extensions.ParamDefinition
	failure    extensions.ParamFailure
	// A backend may name a parameter absent from the submitted manifest.
	// Such feedback belongs to the whole submission, not a nonexistent row.
	parameters []extensions.ParamDefinition
	answers    map[string]string
}

// A new kind gets a new widget (and undo history), but a focused parameter
// remains the keyboard destination when that widget is replaced.
type runParamFocus struct {
	kind    string
	control ui.Handle
}

// A manifest may refresh synchronously inside RunWithParams. Compare semantic
// input constraints by ID, allowing labels and ordering to change freely.
func runParametersMatch(submitted []extensions.ParamDefinition, current []Param) bool {
	if len(submitted) != len(current) {
		return false
	}
	for _, old := range submitted {
		found := false
		for _, param := range current {
			if param.ID == old.ID {
				found = param.Kind == old.Kind && param.Required == old.Required && param.Default == old.Default && param.Flag == old.Flag && slices.Equal(param.Options, old.Options)
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

func (a *App) runForm(c *ui.Context, copy i18n.Settings, integration Integration) {
	if a.Actions.RunWithParams == nil || len(integration.Params) == 0 {
		// Retire feedback with the form, but preserve its session answers.
		delete(a.runError, integration.ID)
		delete(a.runRefusals, integration.ID)
		return
	}
	// The form is not resident: the row's Run button unfolds it (the
	// reference's `runFormOpen`), so an integration with inputs does not wear
	// a form until the user asks to run it.
	if !a.runOpen[integration.ID] {
		return
	}
	locked := a.rowBusy(integration.ID)
	params := make([]extensions.ParamDefinition, 0, len(integration.Params))
	for _, param := range integration.Params {
		params = append(params, extensions.ParamDefinition{
			ID: param.ID, Label: param.Label, Kind: param.Kind,
			Default: param.Default, Required: param.Required,
			Placeholder: param.Placeholder, Options: slices.Clone(param.Options), Flag: param.Flag,
		})
	}
	if a.runValues == nil {
		a.runValues = map[string]map[string]string{}
	}
	values, ok := a.runValues[integration.ID]
	if !ok {
		values = extensions.ParamDefaults(params)
		a.runValues[integration.ID] = values
	}
	// Manifest refreshes can add or retire inputs while the form is open.
	// Keep answers for surviving parameters, seed new ones, and never send
	// the backend keys that the current form no longer lets the user edit.
	current := make(map[string]bool, len(params))
	for _, param := range params {
		current[param.ID] = true
	}
	for key, value := range extensions.ParamDefaults(params) {
		if _, exists := values[key]; !exists {
			values[key] = value
		}
	}
	for key := range values {
		if !current[key] {
			delete(values, key)
		}
	}
	// The form's own validation, recomputed every frame: the reasons are shown
	// under the inputs that caused them, and the Run button is disabled while
	// any remains — the old form's live `paramValueIssues`, so a typo is never
	// a round-trip to the backend to be explained.
	issues := extensions.ParamIssues(params, values)
	issueByIndex := make(map[int]extensions.ParamValueIssue, len(issues))
	for _, issue := range issues {
		issueByIndex[issue.Index] = issue
	}
	theme := a.cardTheme(c)
	// The form is a `below` block of the Run row, drawn on the card's content
	// column: it carries the row's own inset so the heading, the input rows'
	// card and the Run actions all start on the row labels' column instead of
	// flush against the card's edge (the reference's `.extension-run-params`
	// box, `extensions.css:1224-1236`, sits inside the row's own padding).
	inset := a.rowInset(theme)
	form := ui.Column(c.Key("settings.runform."+integration.ID)).FillWidth().Padding(0, inset, 0, inset)
	a.rememberOperationFocus(c, integration.ID, "run", form)
	fieldFocus := ui.Local(form, "focused-parameter", func() ui.Handle { return ui.Handle{} })
	hadFieldFocus := fieldFocus.FocusWithin(c)
	submitFocus := ui.Local(form, "submit-focus", func() ui.Handle { return ui.Handle{} })
	hadSubmitFocus := submitFocus.Focused(c)
	form.Children(func() {
		// The form's own frame: the heading and hint the reference drew above the
		// inputs (`RunParamForm.tsx`: `.extension-run-params__head` +
		// `customRunValuesHint`), so a user meets the form as a named block rather
		// than as rows that appear under the commands.
		ui.Column(c).FillWidth().Gap(theme.Space(0.5)).Children(func() {
			ui.Text(c, copy.RunValues).FontSize(a.tokens(c).Emphasis).FontWeight(600).
				TextColor(a.tokens(c).TextStrong)
			ui.Text(c, copy.RunValuesHint).FontSize(a.tokens(c).Caption).TextColor(theme.TextMuted)
		})
		feedback := strconv.Quote(integration.Error) + strconv.Quote(integration.Description)
		// Capture report contents, not its pointer: a refreshed probe can move
		// an active field even when the viewport and diagnostics stay unchanged.
		healthFeedback := fmt.Sprintf("%#v", integration.HealthReport)
		a.runParamsBox(c, func() {
			occurrences := map[string]int{}
			for index, param := range integration.Params {
				index, param := index, param
				occurrence := occurrences[param.ID]
				occurrences[param.ID]++
				focus := ui.Local(form, struct {
					param      string
					occurrence int
				}{param.ID, occurrence}, func() runParamFocus { return runParamFocus{} })
				refocus := focus.kind != param.Kind && focus.control.FocusWithin(c)
				focus.kind = param.Kind
				bindFocus := func(control ui.Element) {
					control.Bind(&focus.control)
					if refocus && !locked {
						control.Focus().ScrollIntoView()
					}
					if control.FocusWithin() {
						control.Bind(fieldFocus)
					}
				}
				label := param.Label
				if label == "" {
					label = param.ID
				}
				// The row's second line is the parameter's *kind* (the reference's
				// `customParamType.*` `<small>`), with the required marker beside it;
				// the placeholder belongs to the input, where the reference put it.
				sublabel := runParamKindLabel(copy, param.Kind)
				if param.Required {
					sublabel = strings.TrimSpace(sublabel + "  ·  " + copy.RunRequired)
				}
				// The row's own reason, printed under it inside the card.
				below := []func(){}
				feedback += strconv.Quote(label) + strconv.Quote(sublabel)
				if issue, ok := issueByIndex[index]; ok {
					feedback += strconv.Quote(paramValueIssueMessage(copy, issue))
					below = append(below, func() {
						ui.Text(c, paramValueIssueMessage(copy, issue)).
							FontSize(a.tokens(c).Caption).TextColor(theme.Danger).
							Margin(theme.Space(1), theme.Space(3.5))
					})
				}
				// Keep focus and the editor's state on this parameter when a
				// refreshed manifest changes its position in the form.
				c.Key(param.ID + "\x00" + param.Kind)
				switch param.Kind {
				case extensions.ParamBoolean:
					on := truthyValue(values[param.ID])
					labelClicked := a.rowAligned(c, ui.Center, nil, rowFace{Inert: locked}, label, []rowLine{{Text: sublabel}}, "", func() {
						var sw ui.Element
						a.formFeedbackOutlet(c.Key("run-switch-outlet"), a.integrationLead+feedback+healthFeedback+a.permissionFeedback(integration)+catalogFeedback(integration), func() {
							sw = a.switchControl(c, &on).Label(label)
							bindFocus(sw)
						})
						if locked {
							lockedControl(sw)
						}
						if sw.Changed() && !locked {
							values[param.ID] = boolValue(on)
						}
					}, below...)
					if labelClicked && !locked {
						values[param.ID] = boolValue(!on)
					}
				case extensions.ParamSelect:
					index := 0
					keys := make([]string, len(param.Options))
					seen := map[string]int{}
					for i, option := range param.Options {
						// Duplicate option values are valid legacy declarations.
						// Keep each occurrence distinct without using its position.
						keys[i] = strconv.Itoa(seen[option]) + "\x00" + option
						seen[option]++
						if option == values[param.ID] {
							index = i
						}
					}
					a.rowAligned(c, ui.Center, nil, rowFace{Inert: locked}, label, []rowLine{{Text: sublabel}}, "", func() {
						var picker ui.Element
						a.formFeedbackOutlet(c.Key("run-select-outlet"), a.integrationLead+feedback+healthFeedback+a.permissionFeedback(integration)+catalogFeedback(integration), func() {
							picker = a.segmentedControlKeyed(c, &index, param.Options, keys)
							bindFocus(picker)
						})
						if locked {
							lockedControl(picker)
						}
						if picker.Changed() && !locked &&
							index >= 0 && index < len(param.Options) {
							values[param.ID] = param.Options[index]
						}
					}, below...)
				default:
					value := values[param.ID]
					a.rowAligned(c, ui.Center, nil, rowFace{Inert: locked}, label, []rowLine{{Text: sublabel}}, "", func() {
						draw := func() {
							input := a.extensionFieldLit(c, &value, configFieldMetrics, !locked).Label(label).Width(220).Placeholder(param.Placeholder)
							bindFocus(input)
							if locked {
								lockedControl(input.TextColor(a.tokens(c).Disabled))
							}
						}
						a.formFeedbackOutlet(c.Key("run-input-outlet"), a.integrationLead+feedback+healthFeedback+a.permissionFeedback(integration)+catalogFeedback(integration), draw)
					}, below...)
					if !locked {
						values[param.ID] = value
					}
				}
			}
		})
		// The form's footnote: the injection note (values are argv, never a shell
		// line) and the route the manifest already declares, stated before the Run
		// button so the user knows where the output lands — the reference's
		// `customParamInjectionNote` and its `customRunOutputHint*` pair.
		ui.Text(c, copy.RunInjectionNote).FontSize(a.tokens(c).Caption).TextColor(theme.TextMuted)
		outputHint := copy.RunOutputHintBackground
		if integration.OutputMode == extensions.RouteTerminal {
			outputHint = copy.RunOutputHintTerminal
		}
		ui.Text(c, outputHint).FontSize(a.tokens(c).Caption).TextColor(theme.TextMuted)
		// The reference's `.extension-run-params__actions` is a right-aligned
		// flex row (justify-content: flex-end, a 8px gap) with Cancel first and
		// the accent-filled Run last (`RunParamForm.tsx:129-145`;
		// `extensions.css:1300-1305`) — the affirmative action ends the line,
		// not begins it.
		ui.Row(c).FillWidth().Gap(theme.Space(2)).AlignItems(ui.Center).Justify(ui.End).Children(func() {
			// Cancel folds the form away without running (the reference's
			// `customRunCancel`). The answers stay in `runValues`, so reopening the
			// form keeps the user's in-progress edits — the reference's
			// `runParamMemory`, session memory seeded only on a fresh open.
			var cancel ui.Element
			a.formFeedbackOutlet(c.Key("run-cancel-outlet"), a.integrationLead+feedback+healthFeedback+a.permissionFeedback(integration)+catalogFeedback(integration), func() { cancel = a.actionButton(c, copy.RunCancel) })
			if hadFieldFocus && !c.Resolve(*fieldFocus).Valid() {
				cancel.Focus().ScrollIntoView()
			}
			if cancel.Clicked() {
				a.runOpen[integration.ID] = false
				delete(a.runError, integration.ID)
			}
			runDisabled := len(issues) > 0 || locked || !integration.Running || integration.Broken || integration.Orphan
			var run ui.Element
			a.formFeedbackOutlet(c.Key("run-submit-outlet"), a.integrationLead+feedback+healthFeedback+a.permissionFeedback(integration)+catalogFeedback(integration), func() { run = a.extensionPrimaryButton(c, copy.RunLabel, runDisabled).Bind(submitFocus) })
			if runDisabled && hadSubmitFocus {
				cancel.Focus().ScrollIntoView()
			}
			if run.Clicked() && !runDisabled {
				delete(a.runError, integration.ID)
				// A run owns the answers at the instant of submission. Further
				// editing or host-side normalization must not mutate the other map.
				submitted := make(map[string]string, len(values))
				answers := make(map[string]string, len(values))
				for key, value := range values {
					submitted[key] = value
					answers[key] = value
				}
				if failure := a.Actions.RunWithParams(integration.ID, submitted); failure != nil {
					// Closing the form or replacing its inputs retires this result
					// before it can flash under the old controls for one frame.
					if !a.runOpen[integration.ID] || a.Actions.RunWithParams == nil {
						return
					}
					if a.Integrations != nil {
						current, exists := a.integrationByID(integration.ID)
						if !exists || !runParametersMatch(params, current.Params) {
							return
						}
					}
					if a.runError == nil {
						a.runError = map[string]string{}
					}
					a.runError[integration.ID] = paramFailureMessage(copy, params, failure)
					if a.runRefusals == nil {
						a.runRefusals = map[string]runRefusal{}
					}
					a.runRefusals[integration.ID] = runRefusal{failure: *failure, parameters: params, answers: answers}
					for _, param := range params {
						if param.ID == failure.Param {
							// Both the definition and answer predate the callback;
							// neither its argument nor the live form owns this snapshot.
							a.runRefusals[integration.ID] = runRefusal{param: param.ID, value: answers[param.ID], definition: param, failure: *failure}
							break
						}
					}
				}
			}
		})
		// A field refusal describes one submitted answer. Once that answer or
		// its field is gone, it must not keep accusing the current form.
		if refusal, ok := a.runRefusals[integration.ID]; ok {
			valid := a.runError[integration.ID] != ""
			if refusal.parameters != nil {
				valid = valid && runParametersMatch(refusal.parameters, integration.Params) && maps.Equal(values, refusal.answers)
			} else {
				for _, param := range params {
					if param.ID == refusal.param {
						old := refusal.definition
						valid = valid && param.Kind == old.Kind && param.Required == old.Required && param.Default == old.Default && param.Flag == old.Flag && slices.Equal(param.Options, old.Options)
						break
					}
				}
				value, exists := values[refusal.param]
				valid = valid && exists && value == refusal.value
			}
			if !valid {
				delete(a.runError, integration.ID)
				delete(a.runRefusals, integration.ID)
			} else {
				// Names and language are presentation: keep the refusal but
				// explain it using the current field instead of a stale string.
				a.runError[integration.ID] = paramFailureMessage(copy, params, &refusal.failure)
			}
		}
		if runError := a.runError[integration.ID]; runError != "" {
			ui.Text(c, runError).FontSize(a.tokens(c).Caption).TextColor(theme.Danger)
		}
	})
}

// runParamKindLabel is one parameter kind's own word, the reference's
// `customParamType.*` labels (`RunParamForm.tsx`'s `kindLabelKey`). It is the
// run form's second line and the same five words the parameter editor's picker
// offers, so the two surfaces never disagree about what a kind is called.
func runParamKindLabel(copy i18n.Settings, kind string) string {
	switch kind {
	case extensions.ParamNumber:
		return copy.ParamsKindNumber
	case extensions.ParamBoolean:
		return copy.ParamsKindBoolean
	case extensions.ParamSelect:
		return copy.ParamsKindSelect
	case extensions.ParamPath:
		return copy.ParamsKindPath
	default:
		return copy.ParamsKindText
	}
}

// paramValueIssueMessage words the form's own refusal for one answer: the
// sentence printed under the input that caused it. A required value that is
// missing and a value that does not match its kind are the form's two rules;
// the label is the parameter's own display name (or its id).
func paramValueIssueMessage(copy i18n.Settings, issue extensions.ParamValueIssue) string {
	switch issue.Key {
	case extensions.ParamIssueRequiredMissing:
		return copy.RunParamRequired(issue.Label)
	default:
		return copy.RunParamInvalid(issue.Label)
	}
}

// paramFailureMessage words a refused run: the backend's `run_param_*` key
// names the parameter, and the label the user sees (or the id when there is
// none) is what the sentence interpolates — the old form's
// `paramRunErrorMessage`. The id is never shown when a label exists.
func paramFailureMessage(copy i18n.Settings, params []extensions.ParamDefinition, failure *extensions.ParamFailure) string {
	label := failure.Param
	for _, param := range params {
		if param.ID != failure.Param {
			continue
		}
		if trimmed := strings.TrimSpace(param.Label); trimmed != "" {
			label = trimmed
		}
		break
	}
	switch failure.Key {
	case extensions.RunErrorParamRequired:
		return copy.RunParamRequired(label)
	case extensions.RunErrorParamInvalid:
		return copy.RunParamInvalid(label)
	case extensions.RunErrorParamUnknown:
		return copy.RunParamUnknown(label)
	case extensions.RunErrorParamWindowsUnsafe:
		return copy.RunParamWindowsUnsafe(label)
	default:
		return failure.Error()
	}
}

// The run-output block: one integration's last background run, drawn in its
// row — a folded "View output" line, and the block itself when open, a
// fixed-height scroller in the row's own column rather than an overlay, because
// routine feedback does not deserve a dialog. The reference's
// `.extension-row__output` (`extensions.css:1199-1267`) is the shape; see
// `runoutput_test.go` for the pins.
//
// runOutputFont is the captured-output block's own type: the reference set
// `.extension-row__output-body` in the terminal's monospace stack
// (`extensions.css:1210-1221`) because the text it holds is a program's own
// output, not a sentence.
const runOutputFont = "SF Mono, Menlo, Monaco, Consolas, monospace"

// runOutputFace is the block's own fill: the reference's `--surface-sunken`
// recess (`extensions.css:1199-1205`) — the same shell the run form's box
// wears — never the card's raised `--glass-control` plane the port gave it.
// Named here rather than inlined so the one fact has one home and a test can
// read it without guessing at a composite.
func runOutputFace(tokens theme.Tokens) ui.Color { return tokens.Sunken }

// runOutputEdgeFace retains the alpha of the output surface.
func runOutputEdgeFace(tokens theme.Tokens, t *ui.Theme) ui.Color {
	return runOutputFace(tokens)
}

// runOutput is the last background run's captured output, drawn as the
// reference's `.extension-row__output` block (`extensions.css:1199-1223`, the
// markup at `ExtensionRow.tsx:478-512`).
func (a *App) runOutput(c *ui.Context, copy i18n.Settings, integration Integration) {
	result, ok := a.runOutputs[integration.ID]
	if !ok || integration.Orphan {
		a.noticeFocus(c, integration.ID, "output").restore(c, false, c.Resolve(*noticeExit(c)))
		return
	}
	if !a.outputOpen[integration.ID] {
		// The folded affordance is not a settings row with an action pill: the
		// reference's `.extension-row__output-toggle` is a **text control** that
		// names what it opens — a 12px ChevronRight then the word — on its own
		// line so it cannot be mistaken for one of the row's icon actions
		// (`ExtensionRow.tsx:516-527`, `extensions.css:1243-1256`). The port
		// drew a whole ruled row whose whole label was the pill.
		a.runOutputToggle(c, copy, integration.ID)
		return
	}
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	// The block is the row's own full-width line, exactly as the run form's box
	// is: it spans the row's *content column* (the inset every row's label
	// carries), not the card's frame — the reference draws it inside
	// `.extension-row__open`'s `main` cell, one row padding in from the card
	// (`extensions.css:1199`, `ExtensionRow.tsx:478-490`). The port let it span
	// the card, where it read as a second card rather than as the row's own
	// block.
	inset := a.rowInset(t)
	ui.Column(c).FillWidth().Padding(0, inset, 0, inset).Children(func() {
		ui.Column(c).FillWidth().Gap(t.Space(1)).Padding(t.Space(1.5), t.Space(2)).
			Bind(&a.noticeFocus(c, integration.ID, "output").panel).
			// The block wears the reference's own surface: `.extension-row__output` is a
			// `--surface-sunken` recess under a `--glass-control-edge` hairline with the
			// `--ext-radius` corner — the same shell the run form's box wears, so the two
			// inline blocks read as one family (and neither as a raised card).
			Border(1, tokens.ControlEdge).Radius(tokens.RadiusSM).Background(runOutputFace(tokens)).Clip().
			Children(func() {
				// The head: the block's own name in the caption register at 600 in
				// `--text-tertiary`, the truncation mark as an unstyled aside beside it,
				// and the close chevron at the row's end (`extensions.css:1226-1235`).
				ui.Row(c).FillWidth().Gap(t.Space(2)).AlignItems(ui.Center).Children(func() {
					ui.Text(c, copy.RunLastOutput).FontSize(tokens.Caption).FontWeight(600).
						TextColor(tokens.TextTertiary)
					if result.Truncated {
						ui.Text(c, copy.RunOutputTruncated).FontSize(tokens.Caption).
							TextColor(tokens.TextTertiary)
					}
					ui.Row(c).Grow(1)
					outputFocusOutlet(c.Key("run-output-close-outlet"), func() {
						close := a.extensionIconButton(c.Key("run-output-close"), "chevron-down", copy.RunHideOutput, false)
						focus := a.noticeFocus(c, integration.ID, "output")
						close.Bind(&focus.confirm)
						if focus.cancel.Focused(c) {
							close.Focus().ScrollIntoView()
						}
						if close.Clicked() {
							a.setRunOutputOpen(integration.ID, false)
						}
					})
				})
				// The captured text itself: the monospace stack at the caption step, 1.45
				// line height and the strong ink, selectable because a reader copies out
				// of it (`extensions.css:1238-1258`). The empty state keeps the same line
				// box, in muted italics rather than as a blank sliver (`:1259-1267`).
				// P13-at（`docs/liquid-glass.md` §6.17）：这块凹槽的上下两条边原是**平刀切**——
				// 内容在视口第一行与最后一行像素上被水平切断（实测滚到一半时，第一行的墨
				// 展开 193 对最内的 202，浅色 96%；深色 180 对 188，同样 96%），框外一行
				// 立刻归 0，说明切是 `.Clip()` 造成的，不是内容自己淡出。它和设置页的滚动体
				// 是同一族表面，只是更小（180px 的凹槽），所以边上也走 `glass.ScrollEdge`。
				//
				// 与设置页那处有一处**故意不同**：那块面板的边是自门控的（边高落在它预留的
				// 4u padding 上，滚到底时下面没有内容可淡），这里没有、也不能加 padding——
				// `MaxHeight(45u)` 是固定的，加 padding 等于从视口里偷掉两行字。于是这两道边
				// 按**滚动位置**开关：停在开头时第一行、滚到底时最后一行，都是用户正在读的
				// 那一行，不许被淡；中间任意位置，两头都淡。
				//
				// 底色是凹槽自己的面（`runOutputFace`），不是 `t.Background`：P13-as 仍待 2
				// 记的就是「边淡向错的底色会在静止帧留一道痕」，这里不重犯。边高取 3u(12px)，
				// 小于一个行盒（caption 11px × 1.45 ≈ 16px），所以最多软化一行的边缘，
				// 不会整行吞掉。
				scrolled := a.runOutputScroll(integration.ID)
				edge := t.Space(3)
				ui.Column(c).FillWidth().Children(func() {
					ui.Scroll(c.Key("settings.runoutput." + integration.ID)).TrackScroll(scrolled).
						FillWidth().MaxHeight(t.Space(45)).Children(func() {
						view := launcher.OutputView{Text: ansi.Plain(result.Text()), Spans: ansi.Parse(result.Text())}
						reader := a.noticeFocus(c, integration.ID, "output-text")
						reading := reader.panel.Focused(c)
						if view.Text == "" {
							if reader.panel.Focused(c) {
								c.Resolve(a.noticeFocus(c, integration.ID, "output").confirm).Focus().ScrollIntoView()
							}
							a.runOutputAside(c, tokens, copy.RunNoOutput, false)
							return
						}
						text := ui.RichText(c.Key(a.outputKeys[integration.ID]), view.TextSpans(tokens.Appearance, tokens.TextStrong, tokens.Caption)...).
							Bind(&reader.panel).
							Font(runOutputFont).FontSize(tokens.Caption).
							TextColor(tokens.TextStrong).LineHeight(1.45).Wrap().Selectable()
						if reading && !text.Focused() {
							text.Focus()
						}
					})
					// 底色是**不透明**的合成面：`runOutputFace` 是 `Sunken`，一枚跟着透明度滑块走
					// 的薄罩（`ui.Color.Alpha` 是**乘**，所以把薄罩直接交给 `ScrollEdge`，0.85 会
					// 被它自己的 0.12 乘成 0.10——实测第一行仍读到最内那一带的 90%，淡了个寂寞）。
					// `theme.FaceOver(Control, Sunken)` 先把它压成不透明的面，淡的权才是它自己的。
					// P13-as 仍待 2 记的是另一头（边淡向错的底色）；这两条一起才叫「边是一座面
					// 的语言」，不是叠在上面的另一层罩。
					face := runOutputEdgeFace(tokens, t)
					if scrolled.Y > 0 {
						ui.Box(c).Absolute().Top(0).Left(0).Right(0).Height(edge).PassThrough().
							Material(glass.ScrollEdge{Background: face})
					}
					if scrolled.Y < scrolled.MaxY {
						ui.Box(c).Absolute().Bottom(0).Left(0).Right(0).Height(edge).PassThrough().
							Material(glass.ScrollEdge{Bottom: true, Background: face})
					}
				})
				// The truncation mark at the *end* of the text: the place a reader
				// reaches when the output stops, which the head's own mark cannot say
				// once they have scrolled (`ExtensionRow.tsx:503-511`).
				if result.Truncated {
					a.runOutputAside(c, tokens, copy.RunOutputTruncatedTail, true)
				}
			})
	})
}

// runOutputAside draws one of the block's two aside lines: the empty capture's
// placeholder and the truncation mark under the text.
//
// P13-bh（`docs/liquid-glass.md` §6.27）：这两行此前是全仓**最后两处** `.Italic()`
// ——而且两处压的都是中文。中文没有斜体字形（苹方 / 思源 / 微软雅黑都只有正体），
// `font-style: italic` 只能落到引擎的**伪合成斜切**（pango `pangoStyleItalic`、
// DirectWrite `fontStyleItalic`、CoreText `syntheticItalic`）：11px 的笔画被重采样
// 一次再横向拉伸约 15°，用户读到的就是「糊」——这正是用户偏好账本 P-1（硬禁令：
// 界面排版禁用斜体，中文尤其）与 `chinese-typography.md` §三「中文禁斜体（无斜体
// 字形设计，强制倾斜=笔画变形）」在全仓的最后两处违反。
//
// 参考的载体在中文里不存在，所以「这一行不是程序的输出，是一句旁白」改由两件事说：
//
//  1. **字体寄存器**——真输出是 `runOutputFont` 的等宽栈（`extensions.css:1210-1221`），
//     因为它是程序自己的字节；这两行是系统字体，读起来不是字节。
//  2. **文案本身**——占位被**全角圆括号**包住（`（无输出）`）、尾行以**省略号**开头
//     （`……输出已截断（上限 64KB）`）：两种形状都不会出现在程序的输出里，而且都是
//     参考自己的词（`extensions.css:1259-1267` / `:1268-1280`）。
//
// 墨档不动：占位是 `--text-muted`、尾行是 `--text-tertiary`（参考自己的两档）。
// 实测离凹槽面的距离（`runOutputEdgeFace` 的不透明合成面）：浅 **96 / 89**、
// 深 **91 / 75**——浅色那 7 级确实薄，记账而不抬档：把占位抬上去，会让这块**空**
// 凹槽的声音比它自己的标题还响。
//
// 这两行因此有了一个家：census 与像素 pin 都读这一个调用点（`noitalic_test.go`）。
func (a *App) runOutputAside(c *ui.Context, tokens theme.Tokens, line string, tail bool) {
	ui.Text(c, line).FontSize(tokens.Caption).TextColor(runOutputAsideInk(tokens, tail))
}

// runOutputAsideInk is the one home for the two asides' inks: the placeholder
// takes `--text-muted` and the truncation mark `--text-tertiary`, which is what
// the reference's own two rules say (`extensions.css:1259-1267` /
// `:1268-1280`). It lives here rather than at the call sites so the ladder the
// pin measures cannot be a reconstruction of it — a caller that passed the
// wrong colour would be a caller that could pass any colour.
func runOutputAsideInk(tokens theme.Tokens, tail bool) ui.Color {
	if tail {
		return tokens.TextTertiary
	}
	return tokens.Theme.TextMuted
}

// runOutputToggle is the folded output block's own affordance: the reference's
// `.extension-row__output-toggle` (`extensions.css:1243-1256`,
// `ExtensionRow.tsx:516-527`) — a 12px ChevronRight then the word, on the row's
// own line, transparent at rest and lifting to the hover fill under the
// pointer. It is a text control, not an icon button, which is what keeps it
// from reading as one of the row's four action pills.
func (a *App) runOutputToggle(c *ui.Context, copy i18n.Settings, id string) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	// The affordance is the row's own full-width line, like the block it opens:
	// it carries the row's content-column inset, so its chevron and word start
	// where the opened block's head does rather than at the card's frame.
	inset := a.rowInset(t)
	ui.Column(c).FillWidth().Padding(0, inset, 0, inset).Children(func() {
		outputFocusOutlet(c.Key("run-output-toggle-outlet"), func() {
			ink := tokens.TextTertiary
			button := ui.ButtonBase(c.Key("run-output-toggle")).Label(copy.RunViewOutput).FillWidth().
				MinHeight(max(28, t.Space(8))).Gap(t.Space(1)).Padding(0, t.Space(2)).
				AlignItems(ui.Center).Justify(ui.Start).
				Border(0, ui.Transparent).Radius(tokens.RadiusXS).
				Background(ui.Transparent).
				// P13-gv（§6.169）：这一行也有三档面，而它此前一帧跳过去。
				Transition(ui.ElementTransition{Colors: true, Duration: theme.ColorStep})
			// P13-cn（`docs/liquid-glass.md` §6.57）：这枚折叠行此前**只有两档**——
			// 静息透明、悬停 `ControlHover`，而按住不放的那一帧与悬停帧**逐像素相同**
			// （同 P13-q / P13-al / P13-bv / P13-bw / P13-bx 那一族，这是这一族的最后
			// 两处之一）。第三档是控制阶梯的**回退**：`ControlPress`（深 0.05 / 浅 0.032）
			// 沉到悬停面之下、静息之上，指针按住时这块面「被压回去」而不是「更亮」。
			//
			// 顺带补一条普查漏账：旧写法把状态读进变量（`hovered := button.Hovered()`），
			// 而 `internal/ci/litarm_contract_test.go` 的臂级普查只认 `case X.Hovered():`
			// / `if X.Hovered() {`——这个函数对普查**完全隐形**，于是悬停那块
			// `ControlHover` 面一直没有一对线（§2 判据 1 的 E1 缺件）也没人发现。
			// 写成 `switch` 三档之后它进入普查视野，面的一对线按普查逃生口 ② 由
			// 下面那句 `if plane.A > 0` 统一给（与 `savealert.go`、`launcher/power.go`
			// 同一个形状：一份面，所有状态共用一对线）。
			//
			// 几何一个像素不动：参考的 `:active` 变换是给胶囊的
			// （`.extensions-action-button:active { scale(.97) }`），而这一行是**整宽的
			// 文字控制**（`extensions.css:1243-1256`，chevron + 一个词）；整宽收缩会把
			// chevron 从行首往里挪，那是布局，不是墨。
			plane := ui.Transparent
			switch {
			case button.Pressed():
				plane = tokens.ControlPress
			case button.Hovered():
				plane = tokens.ControlHover
			}
			button.Background(plane)
			if plane.A > 0 {
				ink = t.Text
				tokens.LitFace(button)
			}
			button.Children(func() {
				ui.Icon(c, mustGlyph("chevron-right")).Size(t.Space(3), t.Space(3)).TextColor(ink)
				ui.Text(c, copy.RunViewOutput).FontSize(tokens.Caption).TextColor(ink)
			})
			focus := a.noticeFocus(c, id, "output")
			button.Bind(&focus.cancel)
			if focus.confirm.Focused(c) || focus.panel.FocusWithin(c) {
				button.Focus().ScrollIntoView()
			}
			if button.Clicked() {
				a.setRunOutputOpen(id, true)
			}
		})
	})
}

// truthyValue and boolValue are a parameter's own two spellings.
func truthyValue(value string) bool {
	switch strings.ToLower(value) {
	case "1", "true", "yes", "on":
		return true
	default:
		return false
	}
}

func boolValue(on bool) string {
	if on {
		return "true"
	}
	return "false"
}

// toolParam is one declared input the connect form is editing.
type toolParam struct {
	// Draft identity survives edits to ID and shifts in the parameter slice.
	key         *int
	ID          string
	Label       string
	Kind        string
	Placeholder string
	Default     string
	Flag        string
	Required    bool
	Options     string
}

// paramKinds are the kinds the editor offers, in the schema's order.
var paramKinds = []string{
	extensions.ParamText, extensions.ParamNumber, extensions.ParamBoolean,
	extensions.ParamSelect, extensions.ParamPath,
}

// issueUnder prints one row's own validation line: what the row still needs,
// under the row that caused it — the old build's `paramIssues`, whose errors
// rendered where they happened so a save never had to bounce back from the
// backend to explain a typo. A muted warning line, not a red banner.
func (a *App) issueUnder(c *ui.Context, message string) {
	t := a.cardTheme(c)
	tokens := a.tokens(c)
	ui.Text(c, message).FontSize(tokens.Caption).TextColor(t.Warning).
		Padding(0, t.Space(3.5)).SingleLine()
}

// paramKindLabels are the kind picker's words.
func paramKindLabels(copy i18n.Settings) []string {
	return []string{
		copy.ParamsKindText, copy.ParamsKindNumber, copy.ParamsKindBoolean,
		copy.ParamsKindSelect, copy.ParamsKindPath,
	}
}

// editorParams is every row of the declared-input editor as a declaration,
// one for one with the editor's own rows, so a validation issue's index names
// the row it belongs to. A blank id survives (declaredParams drops it from
// the request) because the validator is exactly what has to name it.
func (a *App) editorParams() []extensions.ParamDefinition {
	params := make([]extensions.ParamDefinition, 0, len(a.toolParams))
	for _, param := range a.toolParams {
		definition := extensions.ParamDefinition{
			ID:          strings.TrimSpace(param.ID),
			Label:       strings.TrimSpace(param.Label),
			Kind:        param.Kind,
			Placeholder: strings.TrimSpace(param.Placeholder),
			Default:     strings.TrimSpace(param.Default),
			Flag:        strings.TrimSpace(param.Flag),
			Required:    param.Required,
		}
		for _, option := range textlines.Split(param.Options) {
			if trimmed := strings.TrimSpace(option); trimmed != "" {
				definition.Options = append(definition.Options, trimmed)
			}
		}
		params = append(params, definition)
	}
	return params
}

// declaredParams turns the editor's rows into the declarations a request
// carries: a row with no id is skipped rather than refused, because a row
// being typed is not yet a declaration.
func (a *App) declaredParams() []extensions.ParamDefinition {
	var params []extensions.ParamDefinition
	for _, definition := range a.editorParams() {
		if definition.ID == "" {
			continue
		}
		params = append(params, definition)
	}
	return params
}

// paramIssueMessage is a row's validation line in the reader's language.
func paramIssueMessage(copy i18n.Settings, issue extensions.ParamRowIssue) string {
	switch issue {
	case extensions.ParamIssueID:
		return copy.ParamInvalidID
	case extensions.ParamIssueDuplicate:
		return copy.ParamDuplicateID
	case extensions.ParamIssueOptions:
		return copy.ParamNeedsOptions
	case extensions.ParamIssueFlag:
		return copy.ParamNeedsFlag
	case extensions.ParamIssueBadFlag:
		return copy.ParamInvalidFlag
	case extensions.ParamIssueDefault:
		return copy.RunParamInvalid(copy.ParamsDefault)
	}
	return ""
}

// beginEdit fills the local-tool form from what an integration declares and
// remembers that the form is editing it rather than connecting something new.
func (a *App) beginEdit(id string, tool CustomTool) {
	a.integrationNav.tab, a.integrationNav.addMethod = 1, 1
	a.integrationNav.detail = nil
	a.Body.Y = 0
	a.toolOpen = true
	a.toolFormKey = new(int)
	a.scriptEditor = nil
	a.copiedContent, a.copiedContentUntil = "", time.Time{}
	a.copiedContentValue = ""
	// Editing fills a fresh form, so it gets a fresh toolchain verdict too.
	a.clearScriptRuntimeCache()
	a.toolEditing = id
	a.toolAdvanced = false
	a.toolIssue = false
	a.toolMode = tool.Mode
	a.toolLanguage = tool.ScriptLanguage
	a.toolScript = tool.ScriptContent
	a.toolName = tool.Name
	a.toolProgram = tool.Program
	a.toolCommand = tool.Command
	a.toolArgs = tool.Args
	a.toolVersionArgs = tool.VersionArgs
	a.toolVersion = tool.Version
	a.toolDescription = tool.Description
	a.toolOutput = tool.Output
	a.toolPlatforms = map[string]bool{}
	for _, platform := range tool.Platforms {
		a.toolPlatforms[platform] = true
	}
	a.toolPermissions = map[string]bool{}
	for _, permission := range tool.Permissions {
		a.toolPermissions[permission] = true
	}
	a.toolParams = nil
	for _, param := range tool.Params {
		a.toolParams = append(a.toolParams, toolParam{
			ID: param.ID, Label: param.Label, Kind: param.Kind, Flag: param.Flag,
			Placeholder: param.Placeholder, Default: param.Default,
			Required: param.Required, Options: strings.Join(param.Options, "\n"),
		})
	}
}

// endEdit clears the edit state, so the next connection starts a new package.
func (a *App) endEdit() {
	a.clearScriptRuntimeCache()
	a.toolFormKey = new(int)
	a.scriptEditor = nil
	a.copiedContent, a.copiedContentUntil = "", time.Time{}
	a.copiedContentValue = ""
	a.toolOutput = ""
	a.toolEditing = ""
	a.toolAdvanced = false
	a.toolIssue = false
	a.toolMode, a.toolLanguage, a.toolScript = "", "", ""
	a.toolName, a.toolProgram, a.toolCommand = "", "", ""
	a.toolArgs, a.toolVersionArgs, a.toolVersion, a.toolDescription = "", "", "", ""
	a.toolPlatforms = nil
	a.toolParams = nil
	a.toolPermissions = map[string]bool{}
}
